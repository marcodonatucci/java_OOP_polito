package compagnieaeree;

public class Segmento {
	
	String siglaVolo;
	String data; 
	String classe; 
	double tariffa; 
	double tasse;
	
	public Segmento(String siglaVolo, String data, String classe, double tariffa, double tasse) {
		this.siglaVolo = siglaVolo;
		this.data = data;
		this.classe = classe;
		this.tariffa = tariffa;
		this.tasse = tasse;
	}
	
	

}
