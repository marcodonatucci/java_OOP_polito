package compagnieaeree;

import java.util.Comparator;

public class ComparatoreDataOra implements Comparator<Volo> {
	
	@Override
	public int compare(Volo o1, Volo o2) {
		if(o1.dataPartenza.compareTo(o2.dataPartenza)==0)
			return o1.oraPartenza.compareTo(o2.oraPartenza);
		else if (o1.dataPartenza.compareTo(o2.dataPartenza)==0 && o1.oraPartenza.compareTo(o2.oraPartenza)==0)
			return o1.sigla.compareTo(o2.sigla);
		else
			return o1.dataPartenza.compareTo(o2.dataPartenza);
	}
	

}
