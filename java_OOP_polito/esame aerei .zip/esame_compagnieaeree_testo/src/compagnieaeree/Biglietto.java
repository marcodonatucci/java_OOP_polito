package compagnieaeree;

import java.util.LinkedList;

public class Biglietto {
	
	int numeroBiglietto;
	String nome;
	String cognome;
	char sesso;
	String numeroFrequentFlyer;
	LinkedList<Segmento> segmenti = new LinkedList<Segmento>();

	public Biglietto(int numeroBiglietto, String nome, String cognome, char sesso, String numeroFrequentFlyer) {
		this.numeroBiglietto = numeroBiglietto;
		this.nome = nome;
		this.cognome = cognome;
		this.sesso = sesso;
		this.numeroFrequentFlyer = numeroFrequentFlyer;
	}
	
	public Biglietto(int numeroBiglietto, String nome, String cognome, char sesso) {
		this.numeroBiglietto = numeroBiglietto;
		this.nome = nome;
		this.cognome = cognome;
		this.sesso = sesso;
	}

	public int getNumeroBiglietto() {
		return this.numeroBiglietto;
	}

	public String getNome(){
		return this.nome;
	}
	
	public String getCognome(){
		return this.cognome;
	}
	
	public char getSesso(){
		return this.sesso;
	}
	
	public String getNumeroFrequentFlyer() {
		return this.numeroFrequentFlyer;
	}

}



