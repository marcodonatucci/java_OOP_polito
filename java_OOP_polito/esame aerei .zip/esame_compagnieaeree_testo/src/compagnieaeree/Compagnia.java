package compagnieaeree;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Compagnia {
	
	String nome;
	String sede;
	String web;
	String codiceIata;
	TreeMap<String, Aeroporto> aeroporti;
	TreeMap<String, Aeromobile> aeromobili;
	LinkedList<Volo> voli;
	int codiceBiglietto;
	TreeMap<Integer, Biglietto> biglietti;

	public Compagnia(String nome, String sede, String web, String codiceIata) {
		this.nome = nome;
		this.sede = sede;
		this.web = web;
		this.codiceIata = codiceIata;
		this.aeroporti = new TreeMap<String, Aeroporto>();
		this.aeromobili = new TreeMap<String, Aeromobile>();
		this.voli = new LinkedList<Volo>();
		this.codiceBiglietto = 100000;
		this.biglietti = new TreeMap<Integer, Biglietto>();
	}

	public String getNome() {
		return this.nome;
	}

	public String getSede() {
		return this.sede;
	}

	public String getWeb() {
		return this.web;
	}

	public String getCodiceIata() {
		return this.codiceIata;
	}

	public Aeroporto nuovoAeroporto(String sigla, String nome, String citta, String nazione){
		if(aeroporti.containsValue(cercaAeroporto(sigla))) 
			return aeroporti.get(cercaAeroporto(sigla).nome);
		
		Aeroporto a = new Aeroporto(sigla, nome, citta, nazione);
		aeroporti.put(nome, a);
		return a;
	}

	public Collection<Aeroporto> elencoAeroporti(){
		return aeroporti.values();
	}
	
	public Collection<Aeroporto> elencoAeroporti(String nazione){
		LinkedList<Aeroporto> copia = new LinkedList<Aeroporto>();
		for(Aeroporto a: aeroporti.values()) {
			if(a.nazione.equals(nazione))
				copia.add(a);
		}
		return copia;
	}
	
	public void nuovoAeromobile(String siglaModello, int quantita, int autonomia, int numPostiBusiness, int numPostiEconomy){
		if(cercaAeromobile(siglaModello)!=null)
			cercaAeromobile(siglaModello).quantita+=quantita;
		else {
			Aeromobile a = new Aeromobile(siglaModello, quantita, autonomia, numPostiBusiness, numPostiEconomy);
			aeromobili.put(siglaModello, a);
		}
	}
	
	public Aeromobile cercaAeromobile(String siglaModello){
		if(aeromobili.containsKey(siglaModello))
			return aeromobili.get(siglaModello);
		return null;
	}
	
	public Collection<Aeromobile> elencoAeromobili(){
		LinkedList<Aeromobile> copia = new LinkedList<Aeromobile>(aeromobili.values());
		Collections.sort(copia);
		return copia;
	}
	
	public Volo nuovoVolo(String sigla, String siglaAeroportoPartenza, String siglaAeroportoArrivo, String dataPartenza, String oraPartenza, String dataArrivo, String oraArrivo, String siglaModelloAeromobile) throws EccezioneOrarioInconsistente{
		if(dataArrivo.compareTo(dataPartenza)<0 || dataPartenza.equals(dataArrivo) && oraArrivo.compareTo(oraPartenza)<0) {
			throw new EccezioneOrarioInconsistente();
		}
		Volo v = new Volo(sigla, cercaAeroporto(siglaAeroportoPartenza), cercaAeroporto(siglaAeroportoArrivo), dataPartenza, oraPartenza, dataArrivo, oraArrivo, cercaAeromobile(siglaModelloAeromobile));
		if(voli.contains(cercaVolo(sigla, dataPartenza))) {
			voli.remove(cercaVolo(sigla, dataPartenza));
			voli.add(v);
			return v;
		}
		voli.add(v);
		return v;
	}
	
	public void registraDecollo(String siglaVolo, String dataPartenza, String dataPartenzaEffettiva, String oraPartenzaEffettiva){
		Volo v = cercaVolo(siglaVolo, dataPartenza);
		if(v != null) {
			v.dataPartenzaEff = dataPartenzaEffettiva;
			v.oraPartenzaEff = oraPartenzaEffettiva;
		}
	}

	public void registraAtterraggio(String siglaVolo, String dataPartenza, String dataArrivoEffettiva, String oraArrivoEffettiva){
		Volo v = cercaVolo(siglaVolo, dataPartenza);
		if(v != null) {
			v.dataArrivoEff = dataArrivoEffettiva;
			v.oraArrivoEff = oraArrivoEffettiva;
		}
	}
	
	public String orario(){
		String s = "";
		LinkedList<Volo> copia = new LinkedList<Volo>(voli);
		Collections.sort(copia, new ComparatoreDataOra());
		for(Volo v: copia) {
			s += v.sigla + " " + v.aeroportoPartenza.sigla + " " + v.dataPartenza + " " + v.oraPartenza + " " + v.aeroportoArrivo.sigla + " " + v.dataArrivo + " " + v.oraArrivo + "\n";
		}
		if(s.length()>0)
			return s.substring(0, s.length()-1);
		return s;
	}
	
	public double calcolaRitardo(String siglaVolo, String data){
		Volo v = cercaVolo(siglaVolo, data);
		double ritardo=0.0;
		if(v != null) {
			if(v.oraArrivoEff==null)
				return 0;
			int differenzaGiorni = Integer.parseInt(v.dataArrivoEff) -Integer.parseInt(v.dataArrivo);
			int arrivoPrevistoInMinuti = Integer.parseInt(v.oraArrivo.split(":")[0])*60+Integer.parseInt(v.oraArrivo.split(":")[1]);
			int arrivoEffettivoInMinuti = Integer.parseInt(v.oraArrivoEff.split(":")[0])*60 + Integer.parseInt(v.oraArrivoEff.split(":")[1]);	
			if(arrivoEffettivoInMinuti>arrivoPrevistoInMinuti)	
				ritardo = differenzaGiorni*1440+(arrivoEffettivoInMinuti-arrivoPrevistoInMinuti);
			else
				ritardo= differenzaGiorni*1440-arrivoPrevistoInMinuti+arrivoEffettivoInMinuti;
			v.ritardo = ritardo;
			return ritardo;
		}
		return -1;
	}

	
	public double calcolaRitardoMedio(String siglaVolo){
		double ritardo = 0.0;
		int vTemp = 0;
		for(Volo v: voli) {
			if(v.sigla.equals(siglaVolo)){
				ritardo += v.ritardo;
				vTemp++;
			}
		}
		return (ritardo/vTemp);
	}	
	
	public String partenze(String siglaAeroportoPartenza){
		String s = "";
		LinkedList<Volo> copia = new LinkedList<Volo>(voli);
		Collections.sort(copia, new ComparatoreDataOra());
		for(Volo v: copia) {
			if(v.aeroportoPartenza.sigla.equals(siglaAeroportoPartenza)) {
				if(v.oraArrivoEff!=null)
					s += v.sigla + " " + v.aeroportoPartenza.sigla + " " + v.dataPartenza + " " + v.oraPartenza + " " + v.aeroportoArrivo.sigla + " " + v.dataArrivo + " " + v.oraArrivo + " " + "atterrato" + "\n";
				else if(v.oraPartenzaEff!=null && v.oraArrivoEff==null)
					s += v.sigla + " " + v.aeroportoPartenza.sigla + " " + v.dataPartenza + " " + v.oraPartenza + " " + v.aeroportoArrivo.sigla + " " + v.dataArrivo + " " + v.oraArrivo + " " + "partito" + "\n";
				else if (v.oraPartenzaEff==null)
					s += v.sigla + " " + v.aeroportoPartenza.sigla + " " + v.dataPartenza + " " + v.oraPartenza + " " + v.aeroportoArrivo.sigla + " " + v.dataArrivo + " " + v.oraArrivo + " " + "non decollato" + "\n";
			}
		}
		if(s.length()>0)
			return s.substring(0, s.length()-1);
		return s;
	}
	
	public int nuovoBiglietto(String nome, String cognome, char sesso, String numeroFrequentFlyer){
		if(numeroFrequentFlyer != null) {
			Biglietto b = new Biglietto(codiceBiglietto, nome, cognome, sesso, numeroFrequentFlyer);
			biglietti.put(codiceBiglietto, b);
			return codiceBiglietto++;
		}
		Biglietto b = new Biglietto(codiceBiglietto, nome, cognome, sesso);
		biglietti.put(codiceBiglietto, b);
		return codiceBiglietto++;
	}

	public void aggiungiSegmento(int numeroBiglietto, String siglaVolo, String data, String classe, double tariffa, double tasse) throws EccezionePostiNonDisponibili{
		Biglietto biglietto = cercaBiglietto(numeroBiglietto);
		int i = 0;
		for(Biglietto b: biglietti.values()) {
			for(Segmento s: b.segmenti) {
				if(s.siglaVolo.equals(siglaVolo) && s.data.equals(data) && s.classe.equals(classe))
					i++;
			}
		}
		if(i==cercaVolo(siglaVolo, data).modelloAeromobile.numeroPostiPerClasse(classe)) {
			biglietti.remove(numeroBiglietto);
			throw new EccezionePostiNonDisponibili();
		}
		Segmento sTemp = new Segmento(siglaVolo, data, classe, tariffa, tasse);
		biglietto.segmenti.add(sTemp);
	}
	
	public Biglietto cercaBiglietto(int numeroBiglietto){
		if(codiceBiglietto>numeroBiglietto)
			return biglietti.get(numeroBiglietto);
		return null;
	}

	public String itinerarioBiglietto(int numeroBiglietto){
		String s = "";
		Biglietto b = cercaBiglietto(numeroBiglietto);
		for(Segmento seg: b.segmenti) {
			int durata = 0;
			Volo v = cercaVolo(seg.siglaVolo, seg.data);
			int differenzaGiorni = Integer.parseInt(v.dataArrivo) -Integer.parseInt(v.dataPartenza);
			int arrivoPrevistoInMinuti = Integer.parseInt(v.oraArrivo.split(":")[0])*60+Integer.parseInt(v.oraArrivo.split(":")[1]);
			if(differenzaGiorni>0) {
				durata = differenzaGiorni*1440-(arrivoPrevistoInMinuti);
			}
			else {
				durata = differenzaGiorni*1440+(arrivoPrevistoInMinuti);
			}
			s += seg.siglaVolo +" "+ seg.data + " "+ seg.classe+ " " + durata + "\n";
		}
		if(s.length()>0)
			return s.substring(0, s.length()-1);
		return s;
	}

    public void leggiFile(String file){
		FileReader fr;
		try {
			fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String riga;
			while((riga= br.readLine())!=null) {
				String campi[]=riga.split(",");
				String sigla = campi[0];
				String aeroportoPartenza = campi[1];
				String aeroportoArrivo = campi[2];
				String dataPartenza = campi[3];
				String oraPartenza = campi[4];
				String dataArrivo = campi[5];
				String oraArrivo = campi[6];
				String aeromobile = campi[7];
				try {
					nuovoVolo(sigla, aeroportoPartenza, aeroportoArrivo, dataPartenza, oraPartenza, dataArrivo, oraArrivo, aeromobile);
				}catch(EccezioneOrarioInconsistente e){
					e.printStackTrace();
				}
			}
			br.close();
			fr.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }		
	
    public Aeroporto cercaAeroporto(String sigla) {
    	for(Aeroporto a: aeroporti.values()) {
    		if(a.sigla.equals(sigla))
    			return a;
    	}
    	return null;
    }
    
    public Volo cercaVolo(String sigla, String dataPartenza) {
    	for(Volo v: voli) {
    		if(v.sigla.equals(sigla) && v.dataPartenza.equals(dataPartenza))
    			return v;
    	}
    	return null;
    }
}
