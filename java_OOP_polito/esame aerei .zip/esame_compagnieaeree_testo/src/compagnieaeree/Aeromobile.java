package compagnieaeree;

public class Aeromobile implements Comparable<Aeromobile>{
	
	String siglaModello;
	int quantita;
	int autonomia;
	int numPostiBusiness;
	int numPostiEconomy;

	public Aeromobile(String siglaModello, int quantita, int autonomia, int numPostiBusiness, int numPostiEconomy) {
		this.siglaModello = siglaModello;
		this.quantita = quantita;
		this.autonomia = autonomia;
		this.numPostiBusiness = numPostiBusiness;
		this.numPostiEconomy = numPostiEconomy;
	}

	public String getSiglaModello() {
		return this.siglaModello;
	}

	public int getQuantita() {
		return this.quantita;
	}

	public int getAutonomia() {
		return this.autonomia;
	}

	public int numeroPostiPerClasse(String classe) {
		if(classe.equals("Business"))
			return this.numPostiBusiness;
		return this.numPostiEconomy;
	}

	@Override
	public int compareTo(Aeromobile o) {
		int posti1 = this.numPostiBusiness + this.numPostiEconomy;
		int posti2 = o.numPostiBusiness + o.numPostiEconomy;
		return posti2-posti1;
	}

}
