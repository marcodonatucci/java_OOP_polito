package compagnieaeree;

public class Volo {
	
	String sigla;
	Aeroporto aeroportoPartenza;
	Aeroporto aeroportoArrivo;
	String dataPartenza;
	String oraPartenza;
	String dataArrivo; 
	String oraArrivo;
	Aeromobile modelloAeromobile;
	String oraPartenzaEff;
	String dataPartenzaEff;
	String oraArrivoEff;
	String dataArrivoEff;
	double ritardo;

	public Volo(String sigla, Aeroporto aeroportoPartenza, Aeroporto aeroportoArrivo, String dataPartenza,
			String oraPartenza, String dataArrivo, String oraArrivo, Aeromobile modelloAeromobile) {
		this.sigla = sigla;
		this.aeroportoPartenza = aeroportoPartenza;
		this.aeroportoArrivo = aeroportoArrivo;
		this.dataPartenza = dataPartenza;
		this.oraPartenza = oraPartenza;
		this.dataArrivo = dataArrivo;
		this.oraArrivo = oraArrivo;
		this.modelloAeromobile = modelloAeromobile;
	}

	public String getSigla() {
		return this.sigla;
	}

	public Aeroporto getAeroportoPartenza() {
		return this.aeroportoPartenza;
	}

	public Aeroporto getAeroportoArrivo() {
		return this.aeroportoArrivo;
	}

	public String getDataPartenza() {
		return this.dataPartenza;
	}

	public String getOraPartenza() {
		return this.oraPartenza;
	}

	public String getDataArrivo() {
		return this.dataArrivo;
	}

	public String getOraArrivo() {
		return this.oraArrivo;
	}

	public Aeromobile getAeromobile() {
		return this.modelloAeromobile;
	}

}
