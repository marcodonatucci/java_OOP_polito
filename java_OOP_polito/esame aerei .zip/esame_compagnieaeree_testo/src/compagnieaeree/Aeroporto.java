package compagnieaeree;

public class Aeroporto {
	
	String sigla;
	String nome;
	String citta;
	String nazione;
	
	public Aeroporto(String sigla, String nome, String citta, String nazione) {
		this.sigla = sigla;
		this.nome = nome;
		this.citta = citta;
		this.nazione = nazione;
	}

	public String getSigla() {
		return this.sigla;
	}

	public String getNome() {
		return this.nome;
	}

	public String getCitta() {
		return this.citta;
	}

	public String getNazione() {
		return this.nazione;
	}
	
}

