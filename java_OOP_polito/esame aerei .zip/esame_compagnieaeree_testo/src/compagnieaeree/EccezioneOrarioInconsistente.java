package compagnieaeree;

@SuppressWarnings("serial")
public class EccezioneOrarioInconsistente extends Exception{

}
