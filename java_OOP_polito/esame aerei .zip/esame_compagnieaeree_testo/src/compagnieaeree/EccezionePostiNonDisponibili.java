package compagnieaeree;

@SuppressWarnings("serial")
public class EccezionePostiNonDisponibili extends Exception {
	
}
