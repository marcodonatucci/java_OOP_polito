import java.util.*;

import compagnieaeree.*;

public class Esempio {

	public static void main(String[] args) throws EccezioneOrarioInconsistente, EccezionePostiNonDisponibili {

		System.out.println("#######################################");
		System.out.println("#     R1. Aeroporti ed aeromobili     #");
		System.out.println("#######################################\n");

		System.out.println("Definita nuova compagnia");
		Compagnia compagnia = new Compagnia("Lufthansa", "Colonia, Germania", "www.lufthansa.com", "LH");

	    System.out.println(" Nome: "+compagnia.getNome());
	    System.out.println(" Sede: "+compagnia.getSede());
	    System.out.println(" Sito:  "+compagnia.getWeb());
	    System.out.println(" IATA: "+compagnia.getCodiceIata());
	    
		System.out.println("\nDefinito nuovo aeroporto gestito");
	    
	    Aeroporto aeroporto = compagnia.nuovoAeroporto("TRN", "Sandro Pertini - Caselle","Torino", "Italia");
        
	    System.out.println(" Sigla:   "+aeroporto.getSigla());
	    System.out.println(" Nome:    "+aeroporto.getNome());
	    System.out.println(" Citta:   "+aeroporto.getCitta());
	    System.out.println(" Nazione: "+aeroporto.getNazione());

		System.out.println("\nDefiniti altri aeroporti");
	    
	    compagnia.nuovoAeroporto("FRA", "Rhein - Main","Francoforte", "Germania");
        compagnia.nuovoAeroporto("FCO", "Leonardo da Vinci - Fiumicino","Roma", "Italia");

	    System.out.println("\nElenco aeroporti: ");
	    LinkedList<Aeroporto> aeroporti = new LinkedList<Aeroporto>(compagnia.elencoAeroporti());
	    for(Aeroporto a : aeroporti)
	    	System.out.println(" "+a.getSigla()+", "+a.getNome()+", "+a.getCitta()+", "+a.getNazione());
	    
	    System.out.println("\nElenco aeroporti in Italia: ");
	    aeroporti = new LinkedList<Aeroporto>(compagnia.elencoAeroporti("Italia"));
	    for(Aeroporto a : aeroporti)
	    	System.out.println(" "+a.getSigla()+", "+a.getNome()+", "+a.getCitta()+", "+a.getNazione());
	    
		System.out.println("\nDefinito nuovo aeromobile modello A319");
	    compagnia.nuovoAeromobile("A319", 1, 3750, 32, 90);
	    
	    System.out.println("\nCerca aeromobile A319 ");
	    Aeromobile aeromobile = compagnia.cercaAeromobile("A319");
	    System.out.println(" Modello: "+aeromobile.getSiglaModello());
	    System.out.println(" Autono.:  "+aeromobile.getAutonomia()+" miglia");
	    System.out.println(" Econom.:  "+aeromobile.numeroPostiPerClasse("Economy")+" posti");
	    System.out.println(" Busine.:  "+aeromobile.numeroPostiPerClasse("Business")+" posti");

		System.out.println("\nDefiniti altri modelli di aeromobile");
	    compagnia.nuovoAeromobile("A320", 2, 5200, 40, 120);
	    compagnia.nuovoAeromobile("B777", 1, 7000, 60, 230);
	    
	    System.out.println("\nElenco aeromobili: ");
	    LinkedList<Aeromobile> aeromobili = new LinkedList<Aeromobile>(compagnia.elencoAeromobili());
	    for(Aeromobile a : aeromobili)
	    	System.out.println(" "+a.getSiglaModello()+" "+a.getQuantita()+" "+a.getAutonomia()+" "+a.numeroPostiPerClasse("Business")+" "+a.numeroPostiPerClasse("Economy")+" ("+(int)(a.numeroPostiPerClasse("Business")+a.numeroPostiPerClasse("Economy"))+")");
	    
	    
		System.out.println("\n\n#######################################");
		System.out.println("#          R2. Voli ed orario         #");
		System.out.println("#######################################\n");
		
		System.out.println("Definito nuovo volo");
	    
	    Volo volo = compagnia.nuovoVolo("LH301", "TRN", "FRA", "20160222", "14:25", "20160222", "15:45","A319");
	    System.out.println(" Sigla:  "+volo.getSigla());
	    System.out.println(" Part.:  "+volo.getAeroportoPartenza().getSigla() +" il "+volo.getDataPartenza()+" alle "+volo.getOraPartenza());
	    System.out.println(" Arr. :  "+volo.getAeroportoArrivo().getSigla() +" il "+volo.getDataArrivo()+" alle "+volo.getOraArrivo());
	    System.out.println(" Aerom.: "+volo.getAeromobile().getSiglaModello());

		System.out.println("\nDefiniti altri voli");
	    compagnia.nuovoVolo("LH118", "TRN", "FCO", "20160221", "11:40", "20160221", "12:50","A320");
	    compagnia.nuovoVolo("LH118", "TRN", "FCO", "20160222", "11:40", "20160222", "12:50","A320");
	    compagnia.nuovoVolo("LH303", "FRA", "TRN", "20160222", "16:30", "20160222", "18:10","A319");
	    compagnia.nuovoVolo("LH305", "TRN", "FRA", "20160222", "19:15", "20160222", "20:15","A319");
	    compagnia.nuovoVolo("LH239", "FCO", "FRA", "20160222", "00:45", "20160222", "02:45","A320");
	    
	    System.out.println("\nOrario: ");
	    System.out.println(compagnia.orario());

		System.out.println("\n\n#######################################");
		System.out.println("#  R3. Decolli, atterraggi e ritardi  #");
		System.out.println("#######################################\n");

		System.out.println("Registrati decolli ed atterraggi");

	    compagnia.registraDecollo("LH118", "20160221", "20160221", "11:40");
	    compagnia.registraAtterraggio("LH118", "20160221", "20160221", "12:50");

	    compagnia.registraDecollo("LH118", "20160222", "20160222", "11:47");
	    compagnia.registraAtterraggio("LH118", "20160222", "20160222", "12:59");
	    compagnia.registraDecollo("LH301", "20160222", "20160222", "14:25");
	    

	    System.out.println("\nRitardo per il volo LH118 del 20160221:");
	    System.out.println(" "+compagnia.calcolaRitardo("LH118", "20160221")+" minuti");

	    System.out.println("\nRitardo per il volo LH118 del 20160222:");
	    System.out.println(" "+compagnia.calcolaRitardo("LH118", "20160222")+" minuti");
	    
	    System.out.println("\nRitardo medio per il volo LH118:");
	    System.out.println(" "+compagnia.calcolaRitardoMedio("LH118")+" minuti");
	    
		System.out.println("\nPartenze da TRN:");
		System.out.println(compagnia.partenze("TRN"));
	    
	    
		System.out.println("\n\n#######################################");
		System.out.println("#             R4. Biglietti           #");
		System.out.println("#######################################\n");

		System.out.println("Nuovo biglietto");

		int numeroBiglietto = compagnia.nuovoBiglietto("Mario", "Rossi", 'M', "0123456789");

		System.out.println("\nDefiniti segmenti di volo per il biglietto");

		compagnia.aggiungiSegmento(numeroBiglietto, "LH301", "20160222", "Economy", 200.0, 90.0);
	    compagnia.aggiungiSegmento(numeroBiglietto, "LH303", "20160222", "Business", 600.0, 250.0);

	    System.out.println("\nRicerca biglietto "+numeroBiglietto);
	    
	    Biglietto biglietto = compagnia.cercaBiglietto(numeroBiglietto);
	    
	    System.out.println(" Nome:    "+biglietto.getNome());
	    System.out.println(" Cognome: "+biglietto.getCognome());
	    System.out.println(" Sesso:   "+biglietto.getSesso());
	    System.out.println(" F.Flyer: "+biglietto.getNumeroFrequentFlyer());
	    
	    System.out.println("\nItinerario per biglietto "+numeroBiglietto);
	    System.out.println(compagnia.itinerarioBiglietto(numeroBiglietto));
	    
	}

}






