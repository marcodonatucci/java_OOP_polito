
import universita.Universita;

public class Principale {
		
	public static void main(String[] args) {

		String nomeUniversita = "Politecnico di Torino";
		String indirizzoUniversita = "Corso Duca degli Abruzzi 24";
		String capUniversita = "10129";
		String cittaUniversita = "Torino";
		
		Universita universita = new Universita(nomeUniversita, indirizzoUniversita, capUniversita, cittaUniversita);
		
		universita.definisciRettore("Guido", "Saracco");
		
		System.out.println("Università " + universita.getNome() + " con sede in "+ universita.getIndirizzo()+ ", cap "+universita.getCap()+", citta' "+universita.getCitta());
		System.out.println("Rettore: " + universita.rettore());	
		
		
		System.out.println("\nAggiunti studenti");

		int sA = universita.aggiungiStudente("Mario", "Blu", 23.93);
		int sB = universita.aggiungiStudente("Carla", "Neri", 29.85);
		
		System.out.println("\nStudenti aggiunti: ");
		System.out.println(sA);
		System.out.println(sB);
		
		System.out.println();
		System.out.println("Primo studente aggiunto:\n" + universita.studente(sA));

		System.out.println("\nAggiunti corsi");

		int cX = universita.aggiungiCorso("Programmazione a Oggetti", "Questo insegnamento intende completare la preparazione degli studenti nello sviluppo del software presentando le tecniche basate sul paradigma a oggetti e il loro uso tramite il linguaggio Java", "Lamberti", 80);
		int cY = universita.aggiungiCorso("Chimica", "Il corso si propone di fornire le basi necessarie per l'interpretazione di fenomeni chimici, per la conoscenza della struttura e delle proprietà dei solidi cristallini e per la comprensione ed il calcolo dei fenomeni energetici relativi a sistemi chimici ed elettrochimici.", "Gatti", 100);
		int cZ = universita.aggiungiCorso("Machine learning for vision and multimedia", "Il corso si pone l’obiettivo di fornire allo studente una preparazione pratico-teorica sull’applicazione delle tecniche di machine e deep learning nell’ambito della visione artificiale, dell’elaborazione di informazioni multimediali e nella creazione di contenuti digitali e grafica tridimensionale", "Lamberti", 45);

		System.out.println("\nPrimo corso aggiunto:");
		System.out.println(universita.corso(cX));
		
		universita.assegna(sA, cX);
		universita.assegna(sB, cY);
		universita.assegna(sB, cZ);
		
		System.out.println();
		System.out.println("Elenco studenti per il corso "+cX+":");
		System.out.println(universita.elencoStudenti(cX));
		
		System.out.println();
		System.out.println("Elenco corsi assegnati a Carla Neri:");
		System.out.println(universita.elencoCorsi(sB));

		System.out.println();
		System.out.println("Elenco corsi del docente Lamberti:");
		System.out.println(universita.elencoCorsiDocente("Lamberti"));

		System.out.println();
		System.out.println("Ore complessive dei corsi cui Carla Neri è assegnata:");
		System.out.println(universita.oreCorsiStudente(sB));
	
	}
	
}
