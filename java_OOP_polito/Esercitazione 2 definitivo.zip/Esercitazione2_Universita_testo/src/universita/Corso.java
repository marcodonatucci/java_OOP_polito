package universita;

public class Corso {

	private String titolo;
	private String descrizione;
	private String cognomeDocente;
	private int numeroOre;
	private int codice = 0;
	private Studente studenti[] = new Studente[200];
	private int k = 0;
	
	public Corso(String titolo, String descrizione, String cognomeDocente, int numeroOre) {
		this.titolo = titolo;
		this.descrizione = descrizione;
		this.cognomeDocente = cognomeDocente;
		this.numeroOre = numeroOre;
	}

	public String getTitolo() {
		return titolo;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public String getCognomeDocente() {
		return cognomeDocente;
	}

	public int getNumeroOre() {
		return numeroOre;
	}

	public Studente getStudente(int i) {
		return studenti[i];
	}

	public void setStudente(Studente studenti) {
		this.studenti[k] = studenti;
		k++;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public void setCognomeDocente(String cognomeDocente) {
		this.cognomeDocente = cognomeDocente;
	}

	public void setNumeroOre(int numeroOre) {
		this.numeroOre = numeroOre;
	}

	public Studente[] getStudenti() {
		return studenti;
	}

	public void setStudenti(Studente[] studenti) {
		this.studenti = studenti;
	}

	public int getCodice() {
		return codice;
	}

	public void setCodice(int codice) {
		this.codice = codice;
	}
	
	
}
