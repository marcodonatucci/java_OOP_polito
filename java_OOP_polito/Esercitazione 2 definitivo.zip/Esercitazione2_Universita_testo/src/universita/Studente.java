package universita;

public class Studente {
	
	private String nome;
	private String cognome;
	private double mediaVoti;
	private int codice = 0;
	private Corso corsi[] = new Corso[10];
	private int k = 0;
	
	
	public Studente(String nome, String cognome, double mediaVoti) {
		this.nome = nome;
		this.cognome = cognome;
		this.mediaVoti = mediaVoti;
	}
	public String getNome() {
		return nome;
	}

	public String getCognome() {
		return cognome;
	}
	
	public double getMediaVoti() {
		return mediaVoti;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public void setMediaVoti(double mediaVoti) {
		this.mediaVoti = mediaVoti;
	}
	public Corso[] getCorsi() {
		return corsi;
	}
	public void setCorsi(Corso[] corsi) {
		this.corsi = corsi;
	}
	public int getCodice() {
		return codice;
	}
	public void setCodice(int codice) {
		this.codice = codice;
	}
	
	public void setCorso(Corso corsi) {
		this.corsi[k] = corsi;
		k++;
	}
	
}
