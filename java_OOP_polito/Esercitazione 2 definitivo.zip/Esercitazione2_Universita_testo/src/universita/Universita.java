package universita;

public class Universita {
	private String nome;
	private String indirizzo;
	private String cap;
	private String citta;
	private Rettore r = new Rettore();
	private Studente[] studenti = new Studente[1000];
	private Corso corsi[] = new Corso[50];
	private int s = 0;
	private int c = 0;

	public Universita(String nome, String indirizzo, String cap, String citta){
		this.nome = nome;
		this.indirizzo = indirizzo;
		this.cap = cap;
		this.citta = citta;
		//this.rettore = ""; il costruttore deve inizializzare tutto
		//this.studenti = new Studente[1000]; new è un istruzione, non va nella parte di dichiarazione delle variabili
	}
	
	public String getNome(){
		return nome;
	}

	public String getIndirizzo(){
		return indirizzo;
	}
	
	public String getCap() {
		return cap;
	}

	public String getCitta() {
		return citta;
	}

	public void definisciRettore(String nome, String cognome){
		r.setNome(nome);
		r.setCognome(cognome);
	}
	
	public String rettore(){
		return r.getNome() + " " + r.getCognome();
	}
	
	public int aggiungiStudente(String nome, String cognome, double mediaVoti){
		studenti[s] = new Studente(nome, cognome, mediaVoti);
		studenti[s].setCodice(s+100);//potevi usare un costruttore con il codice e una variabile temporanea prima 
		s++;//potevi fare tutto in una istruzione così: studenti[s++].setCodice();
		return s+99;
	}
	
	public String studente(int codice){
		return codice + "-" + studenti[codice-100].getNome() + "-" + studenti[codice-100].getCognome() + "-" + studenti[codice-100].getMediaVoti();
	}//potevi usare un metodo descriviti() creato nella classe studente (DELEGA)
	
	public int aggiungiCorso(String titolo, String descrizione, String cognomeDocente, int numeroOre){
		corsi[c] = new Corso(titolo, descrizione, cognomeDocente, numeroOre);
		corsi[c].setCodice(c+1);
		c++;
		return c;
	}
	
	public String corso(int codiceCorso){
		return codiceCorso + "-" + corsi[codiceCorso-1].getTitolo() + "-" + corsi[codiceCorso-1].getDescrizione() + "-" + corsi[codiceCorso-1].getCognomeDocente() + "-"+corsi[codiceCorso-1].getNumeroOre();
	}
	
	public void assegna(int codiceStudente, int codiceCorso){
		corsi[codiceCorso-1].setStudente(studenti[codiceStudente-100]);
		studenti[codiceStudente-100].setCorso(corsi[codiceCorso-1]);
	}
	
	public String elencoStudenti(int codiceCorso){
		String s = "";
		for(int i = 0; i<corsi[codiceCorso-1].getStudenti().length; i++) {
			if(corsi[codiceCorso-1].getStudenti()[i]!=null) { 
				s = s + corsi[codiceCorso-1].getStudenti()[i].getCodice() + "-" + corsi[codiceCorso-1].getStudenti()[i].getNome() + "-"+ corsi[codiceCorso-1].getStudenti()[i].getCognome() + "-"+ corsi[codiceCorso-1].getStudenti()[i].getMediaVoti()+"\n";
			}
		}
		return s.substring(0, s.length()-1);
	}

	public String elencoCorsi(int codiceStudente){
		String s = "";
		for(int i = 0; i<studenti[codiceStudente-100].getCorsi().length; i++) {
			if(studenti[codiceStudente-100].getCorsi()[i]!= null) {
				//if(s!="") //controllo che la stringa non sia vuota
				//s += "\n"; //aggiungo il carattere alla fine della riga
				s = s + studenti[codiceStudente-100].getCorsi()[i].getCodice() + "-" + studenti[codiceStudente-100].getCorsi()[i].getTitolo() + "-"+ studenti[codiceStudente-100].getCorsi()[i].getDescrizione() + "-"+ studenti[codiceStudente-100].getCorsi()[i].getCognomeDocente() + "-"+ studenti[codiceStudente-100].getCorsi()[i].getNumeroOre()+"\n";
			}//solo dopo aggiungo la nuova riga così non mi mette \n all'ultima
			
		}
		return s.substring(0, s.length()-1);
	}

	public int numeroStudenti(int codiceCorso){
		int s = 0;
		for(int i = 0; i<corsi[codiceCorso-1].getStudenti().length; i++) {
			if(corsi[codiceCorso-1].getStudenti()[i]!=null) {
				s++;
				}
			}
		return s;
	}

	public int numeroCorsi(int codiceStudente){
		int c = 0;
		for(int i = 0; i<studenti[codiceStudente-100].getCorsi().length; i++) {
			if(studenti[codiceStudente-100].getCorsi()[i]!= null) {
				c++;
				}
			}
		return c;
	}
	
	public String elencoCorsiDocente(String cognomeDocente){
		String s = "";
		for(int i = 0; i<corsi.length; i++) {
			if(corsi[i]!= null && corsi[i].getCognomeDocente()==cognomeDocente) {
				s = s + corsi[i].getCodice() + "-" + corsi[i].getTitolo() + "-"+ corsi[i].getDescrizione() + "-"+ corsi[i].getCognomeDocente() + "-"+ corsi[i].getNumeroOre()+"\n";
		    }
		}
		return s.substring(0, s.length()-1);
	}
	
	public int oreCorsiStudente(int codiceStudente){
		int c = 0;
		for(int i = 0; i<studenti[codiceStudente-100].getCorsi().length; i++) {
			if(studenti[codiceStudente-100].getCorsi()[i] != null) {
				c = c + studenti[codiceStudente-100].getCorsi()[i].getNumeroOre();
			}
		}
		return c;
	}
//puoi crearti metodi utili e renderli privati così puoi usarli spesso nell'esercitazione
}
