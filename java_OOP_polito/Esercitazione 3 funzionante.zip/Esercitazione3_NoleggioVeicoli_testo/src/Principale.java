
import societa.Cliente;
import societa.Societa;
import societa.Veicolo;

public class Principale {
		
	public static void main(String[] args) {

		Societa s = new Societa(500);

		//R1. Societa
		System.out.println("R1. Societa");
		
		System.out.println("Creato primo Veicolo");
		Veicolo v1 = s.nuovoVeicolo("V1", "Veicolo compatto progettato per la guida in città", 7, 15);

		System.out.println("Codice veicolo: "+v1.getCodiceVeicolo());
		System.out.println("Descrizione veicolo: "+v1.getDescrizione());
		System.out.println("Costo giornaliero: "+v1.getCostoGiornaliero());
		System.out.println("Numero di unita: "+v1.getNumeroUnita());
		

		System.out.println("\nCreato secondo Veicolo");
		Veicolo v2 = s.nuovoVeicolo("V2", "Veicolo utile per il trasporto di merci o attrezzature", 10, 10);

		System.out.println("Codice veicolo: "+v2.getCodiceVeicolo());
		System.out.println("Descrizione: "+v2.getDescrizione());
		System.out.println("Costo giornaliero: "+v2.getCostoGiornaliero());
		System.out.println("Numero di unita: "+v2.getNumeroUnita());

		System.out.println("\nRicerca veicolo V1");
		Veicolo veicoloTrovato = s.cercaVeicolo("V1");

		System.out.println("\nInformazioni veicolo trovato");
		System.out.println("Codice veicolo: "+veicoloTrovato.getCodiceVeicolo());
		System.out.println("Descrizione: "+veicoloTrovato.getDescrizione());
		System.out.println("Costo giornaliero: "+veicoloTrovato.getCostoGiornaliero());
		System.out.println("Numero di unita: "+veicoloTrovato.getNumeroUnita());
		
		System.out.println("\nRicerca veicoli contenenti 'cit'");
		
		Veicolo veicoliTrovati[] = s.cercaVeicoli("cit");

		System.out.println("\nInformazioni veicoli trovati");
		for(Veicolo v : veicoliTrovati)
			if(v!=null) {
				System.out.println("Codice veicolo: "+v.getCodiceVeicolo());
				System.out.println("Descrizione: "+v.getDescrizione());
				System.out.println("Costo giornaliero: "+v.getCostoGiornaliero());
				System.out.println("Numero di unita: "+v.getNumeroUnita());
			}
				
		
		
		
		// R2. Cleinti e Noleggi
		System.out.println("\n\nR2. Cleinti e Noleggi");
		
		System.out.println("\nCreato cliente");
		s.nuovoCliente("CDCFSCL1", "Rossi", "Mario", 500.0);

		System.out.println("\nRicerca cliente CDCFSCL1");

		Cliente cTrovato1 = s.cercaCliente("CDCFSCL1");
		System.out.println("Codice Fiscale: "+cTrovato1.getCodiceFiscale());
		System.out.println("Cognome: "+cTrovato1.getCognome());
		System.out.println("Nome: "+cTrovato1.getNome());
		System.out.println("Disponibilita: "+cTrovato1.getDisponibilitaEconomica());

		System.out.println("\nDefinito i noleggi del cliente con codice CDCFSCL1");
		
		String[] noleggi = {"V1;2;4", "V2;3;4", "V1;4;2"};
		String[] noleggi2 = {"V1;6;2", "V2;3;4", "V1;3;1"};
		
		s.noleggio("CDCFSCL1", noleggi);
		s.noleggio("CDCFSCL1", noleggi2);
		
		
		
		System.out.println("\nUltimo noleggio del cliente CDCFSCL1");
		String ultimoNoleggio = s.ultimoNoleggio("CDCFSCL1");
		System.out.println(ultimoNoleggio);
		
		System.out.println("\nNoleggi cliente CDCFSCL1");
		String noleggiUtente = s.noleggiCliente("CDCFSCL1");
		System.out.println(noleggiUtente);
		
		System.out.println("\nClienti che hanno noleggiato il veicolo V1");
		String utentiProdotto = s.clientiVeicolo("V1");
		System.out.println(utentiProdotto);
		
		
		// R3. Ritiri
		System.out.println("\n\nR3. Ritiri");
		
		System.out.println("\nNuovo ritiro per noleggio 1");
		s.nuovoRitiro(1, "20231110");
		s.nuovoRitiro(1, "20231110", "Corso duca degli abruzzi");
		s.nuovoRitiro(2, "20245678", "Via valdieri 28");
		s.nuovoRitiro(7, "123456");
		
		System.out.println("\nRicerca ritiri S1");
		String ritiroTrovato = s.descriviRitiro("D2");
		System.out.println(ritiroTrovato);
		String ritiroTrovato1 = s.descriviRitiro("S1");
		System.out.println(ritiroTrovato1);
		
		System.out.println(s.ritiri()[0]);
		System.out.println(s.ritiri()[1]);
	
	}
	
}
