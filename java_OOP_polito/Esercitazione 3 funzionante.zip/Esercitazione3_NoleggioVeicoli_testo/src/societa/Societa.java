package societa;


public class Societa {
	
	private Veicolo veicoli[];
	private int numeroMassimoVeicoli;
	private Cliente clienti[];
	private int codiceNoleggio;
	private int codiceRitiro;
	
	public Societa(int numeroMassimoVeicoli) {
		this.numeroMassimoVeicoli = numeroMassimoVeicoli;
		this.veicoli = new Veicolo[numeroMassimoVeicoli];
		this.clienti = new Cliente[100];
		this.codiceNoleggio = 0;
		this.codiceRitiro = 0;
	}
	
	
	public Veicolo nuovoVeicolo(String codiceVeicolo, String descrizione, double costoGiornaliero, int numeroUnitaDisponibili) {
		int count = 0;
		for(Veicolo v: veicoli) {
			if(v!=null)
				count+=v.getNumeroUnita();
		}
		if(count < numeroMassimoVeicoli) {
			for(Veicolo v: veicoli) {
				if(v!=null && v.getCodiceVeicolo()==codiceVeicolo && count+numeroUnitaDisponibili<=numeroMassimoVeicoli) {
					v.setNumeroUnita(v.getNumeroUnita()+numeroUnitaDisponibili);
					return v;
				}
			}	
			for(int i = 0; i<veicoli.length; i++) {
				if(veicoli[i] == null) {
					veicoli[i] = new Veicolo(codiceVeicolo, descrizione, costoGiornaliero, numeroUnitaDisponibili);
					return veicoli[i];
				}
			}
		}
		return null;
	}	

	public Veicolo cercaVeicolo(String codiceVeicolo) {
		for(Veicolo v: veicoli) {
			if(v!= null && v.getCodiceVeicolo().equals(codiceVeicolo))
				return v;
		}
		return null;
	}
	
	public Veicolo[] cercaVeicoli(String stringaDaCercare) {
		int vTemp = 0;
		int vTemp2 = 0;
		for(Veicolo v: veicoli) {
			if(v!= null) {
				if(v.getCodiceVeicolo().toLowerCase().contains(stringaDaCercare.toLowerCase())||v.getDescrizione().toLowerCase().contains(stringaDaCercare.toLowerCase())) 
					vTemp++;
			}
		}
		Veicolo veicoliTrovati[] = new Veicolo[vTemp];
		for(Veicolo v: veicoli) {
			if(v!= null) {	
				if(v.getCodiceVeicolo().toLowerCase().contains(stringaDaCercare.toLowerCase())||v.getDescrizione().toLowerCase().contains(stringaDaCercare.toLowerCase())) {
					veicoliTrovati[vTemp2] = v;
					vTemp2++;
				}
			}
		}
		return veicoliTrovati;
	}
	
	public Cliente nuovoCliente(String codiceFiscale, String cognome, String nome, double disponibilitaEconomica) {
		for(Cliente c: clienti) {
			if(c!=null && c.getCodiceFiscale()==codiceFiscale) {
				c.setCognome(cognome);
				c.setNome(nome);
				c.setDisponibilitaEconomica(disponibilitaEconomica);
				return c;
			}
		}
		for(int i = 0; i<clienti.length; i++) {
			if(clienti[i]==null) {
				clienti[i] = new Cliente(codiceFiscale, cognome, nome, disponibilitaEconomica);
				return clienti[i];
			}
		}
		return null;
	}
	
	public Cliente cercaCliente(String codiceFiscale) {
		for(Cliente c: clienti) {
			if(c!=null && c.getCodiceFiscale()==codiceFiscale)
				return c;
		}
		return null;
	}
	
	public boolean noleggio(String codiceFiscale, String[] noleggi) {
		if(cercaCliente(codiceFiscale)!=null) {
			for(String noleggio: noleggi) {
				String[] infoNoleggio = noleggio.split(";");
				String codiceVeicolo = infoNoleggio[0];
				int numeroUnita = Integer.parseInt(infoNoleggio[1]);
				int giorni = Integer.parseInt(infoNoleggio[2]);
				if(cercaVeicolo(codiceVeicolo)!=null) {
					Veicolo vTemp = cercaVeicolo(codiceVeicolo);
					double costoComplessivo = vTemp.getCostoGiornaliero()*numeroUnita*giorni;
					if(numeroUnita <= vTemp.getNumeroUnita() && costoComplessivo <= cercaCliente(codiceFiscale).getDisponibilitaEconomica()) {
						continue;
					}
					else {
						return false;
					}
				}
				else {
					return false;
				}
			}
			for(String noleggio: noleggi) {
				String[] infoNoleggio = noleggio.split(";");
				String codiceVeicolo = infoNoleggio[0];
				int numeroUnita = Integer.parseInt(infoNoleggio[1]);
				int giorni = Integer.parseInt(infoNoleggio[2]);
				Veicolo vTemp = cercaVeicolo(codiceVeicolo);
				double costoComplessivo = vTemp.getCostoGiornaliero()*numeroUnita*giorni;
				vTemp.setNumeroUnita(vTemp.getNumeroUnita()-numeroUnita);
				cercaCliente(codiceFiscale).setDisponibilitaEconomica(cercaCliente(codiceFiscale).getDisponibilitaEconomica()-costoComplessivo);
				codiceNoleggio++;
				Noleggio n = new Noleggio(codiceNoleggio, codiceFiscale, codiceVeicolo, giorni, costoComplessivo);
				cercaCliente(codiceFiscale).setNoleggi(n);
			}
		}
		else {
			return false;
		}
		return true;
	}
	
	public String ultimoNoleggio(String codiceFiscale) {
		if(cercaCliente(codiceFiscale)!=null && cercaCliente(codiceFiscale).getNoleggi() !=null) {
			Noleggio[] nTemps = cercaCliente(codiceFiscale).getNoleggi();
			int count = 0;
			for(Noleggio nTemp: nTemps) {
				if(nTemp!=null)
					count++;
			}
			return nTemps[count-1].toString();
		}
		return null;
	}

	public String noleggiCliente(String codiceFiscale) {
		String sTemp = "";
		if(cercaCliente(codiceFiscale)!=null && cercaCliente(codiceFiscale).getNoleggi() !=null) {
			for(Noleggio noleggio: cercaCliente(codiceFiscale).getNoleggi()) {
				if(noleggio!=null) {
					sTemp += noleggio.toString() + "\n";
				}
			}
			return sTemp.substring(0, sTemp.length()-1);
		}
		else {
			return null;
		}
	}

	public String clientiVeicolo(String codiceVeicolo) {
		if(cercaVeicolo(codiceVeicolo)!=null) {
			String s = "";
			for(Cliente c: clienti) {
				if(c!=null) {
					for(Noleggio n: c.getNoleggi()) {
						if(n!= null && n.getCodiceVeicolo().equals(codiceVeicolo)) {
							s += c.getCodiceFiscale() + "\n";
							break;
						}
					}
				}
			}
		return s.substring(0, s.length()-1);
		}
		else {
			return null;
		}
	}
	
	public Standard nuovoRitiro(int codiceNoleggio, String dataRitiro) {
		for(Cliente c: clienti) {
			if(c!=null) {
				for(Noleggio n: c.getNoleggi()) {
					if(n!=null && codiceNoleggio == n.getCodiceNoleggio()) {
						Standard s = new Standard(codiceNoleggio, dataRitiro, "S"+(codiceRitiro + 1), n);
						codiceRitiro++;
						n.setRitiro(s);
						return s;
					}
				}	
			}
		}
		return null;
	}
	
	public Deluxe nuovoRitiro(int codiceNoleggio, String dataRitiro, String indirizzoRitiro) {
		for(Cliente c: clienti) {
			if(c!=null) {
				for(Noleggio n: c.getNoleggi()) {
					if(n!=null && codiceNoleggio == n.getCodiceNoleggio() && n.getCostoComplessivo()/10.0 <= c.getDisponibilitaEconomica()) {
						Deluxe d = new Deluxe(codiceNoleggio, dataRitiro, indirizzoRitiro, "D"+(codiceRitiro +1), n.getCostoComplessivo()/10.0, n);
						codiceRitiro++;
						n.setRitiro(d);
						c.setDisponibilitaEconomica(c.getDisponibilitaEconomica()-(n.getCostoComplessivo()/10.0));
						return d;
					}
				}
			}
		}
		return null;
	}
	
	public String descriviRitiro(String codiceRitiro) {
		for(Cliente c: clienti) {
			if(c!=null) {
				for(Noleggio n: c.getNoleggi()) {
					if(n !=null && n.getRitiro()!= null && n.getRitiro().getCodiceRitiro().equals(codiceRitiro)) {
						return n.getRitiro().toString();
					}
				}
			}
		}
		return null;
	}

	public Ritiro[] ritiri() {		
		Ritiro ritiri[] = new Ritiro[codiceRitiro];
		int count=0;
		for(Cliente c:clienti) {
			if(c!=null) {
				for(Noleggio n: c.getNoleggi()) {
					if(n!=null && count < codiceRitiro) {
						ritiri[count]=n.getRitiro();
						count++;
					}
				}
			}
		}
		return ritiri;
	}
	
}
