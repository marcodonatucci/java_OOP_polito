package societa;

public class Ritiro {
	
	private int codiceNoleggio;
	private String dataRitiro;
	private String codiceRitiro;
	private Noleggio noleggio;
	
	public Ritiro(int codiceNoleggio, String dataRitiro, String codiceRitiro, Noleggio noleggio) {
		this.codiceNoleggio = codiceNoleggio;
		this.dataRitiro = dataRitiro;
		this.codiceRitiro = codiceRitiro;
		this.noleggio=noleggio;
	}

	public int getCodiceNoleggio() {
		return codiceNoleggio;
	}

	public void setCodiceNoleggio(int codiceNoleggio) {
		this.codiceNoleggio = codiceNoleggio;
	}

	public String getDataRitiro() {
		return dataRitiro;
	}

	public void setDataRitiro(String dataRitiro) {
		this.dataRitiro = dataRitiro;
	}

	public String getCodiceRitiro() {
		return codiceRitiro;
	}

	public void setCodiceRitiro(String codiceRitiro) {
		this.codiceRitiro = codiceRitiro;
	}
	

	public Noleggio getNoleggio() {
		return noleggio;
	}

	public void setNoleggio(Noleggio noleggio) {
		this.noleggio = noleggio;
	}

	public String toString() {
		return codiceNoleggio+";"+noleggio.getCodiceFiscale()+";"+codiceRitiro.charAt(0)+";"+dataRitiro+";"+noleggio.getCostoComplessivo();
	}
	
}
