package societa;

public class Cliente {
	
	private String codiceFiscale;
	private String cognome;
	private String nome;
	private double disponibilitaEconomica;
	private Noleggio noleggi[];
	
	
	public Cliente(String codiceFiscale, String cognome, String nome, double disponibilitaEconomica) {
		this.codiceFiscale = codiceFiscale;
		this.cognome = cognome;
		this.nome = nome;
		this.disponibilitaEconomica = disponibilitaEconomica;
		this.noleggi = new Noleggio[10000];
	}

	public String getCodiceFiscale() {
		return codiceFiscale;
	}

	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getDisponibilitaEconomica() {
		return disponibilitaEconomica;
	}

	public void setDisponibilitaEconomica(double disponibilitaEconomica) {
		this.disponibilitaEconomica = disponibilitaEconomica;
	}

	public Noleggio[] getNoleggi() {
		return noleggi;
	}

	public void setNoleggi(Noleggio noleggio) {
		for(int i = 0; i<noleggi.length; i++) {
			if(noleggi[i]==null) {
				noleggi[i] = noleggio;
				break;  
			}
		}
	}
	
	
}
	
	

