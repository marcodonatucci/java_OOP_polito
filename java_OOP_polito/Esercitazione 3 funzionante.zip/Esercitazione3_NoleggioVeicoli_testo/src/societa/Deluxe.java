package societa;

public class Deluxe extends Ritiro {
	
	private String indirizzoRitiro;
	private double costoRitiro;

	public Deluxe(int codiceNoleggio, String dataRitiro, String indirizzoRitiro, String codiceRitiro, double costoRitiro, Noleggio noleggio) {
		super(codiceNoleggio, dataRitiro, codiceRitiro, noleggio);
		this.indirizzoRitiro=indirizzoRitiro;
		this.costoRitiro=costoRitiro;
	}
	
	public String getIndirizzoRitiro() {
		return indirizzoRitiro;
	}

	public void setIndirizzoRitiro(String indirizzoRitiro) {
		this.indirizzoRitiro = indirizzoRitiro;
	}

	public double getCostoRitiro() {
		return costoRitiro;
	}

	public void setCostoRitiro(double costoRitiro) {
		this.costoRitiro = costoRitiro;
	}
	
	public String toString() {
		return getCodiceNoleggio()+";"+getNoleggio().getCodiceFiscale()+";"+getCodiceRitiro().charAt(0)+";"+getDataRitiro()+";"+(getNoleggio().getCostoComplessivo()+costoRitiro)+";"+indirizzoRitiro;
	}
	

}
