package societa;

public class Noleggio {
	
	private int codiceNoleggio;
	private String codiceFiscale;
	private String codiceVeicolo;
	private int giorni;
	private double costoComplessivo;
	private Ritiro ritiro;
	
	public Noleggio(int codiceNoleggio, String codiceFiscale, String codiceVeicolo, int giorni,
			double costoComplessivo) {
		this.codiceNoleggio = codiceNoleggio;
		this.codiceFiscale = codiceFiscale;
		this.codiceVeicolo = codiceVeicolo;
		this.giorni = giorni;
		this.costoComplessivo = costoComplessivo;
		this.setRitiro(null);
	}


	public String toString() {
		return codiceNoleggio + ";" + codiceFiscale + ";" + codiceVeicolo + ";" + giorni + ";" + costoComplessivo;
	}


	public int getCodiceNoleggio() {
		return codiceNoleggio;
	}


	public void setCodiceNoleggio(int codiceNoleggio) {
		this.codiceNoleggio = codiceNoleggio;
	}


	public String getCodiceFiscale() {
		return codiceFiscale;
	}


	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}


	public String getCodiceVeicolo() {
		return codiceVeicolo;
	}


	public void setCodiceVeicolo(String codiceVeicolo) {
		this.codiceVeicolo = codiceVeicolo;
	}


	public int getGiorni() {
		return giorni;
	}


	public void setGiorni(int giorni) {
		this.giorni = giorni;
	}


	public double getCostoComplessivo() {
		return costoComplessivo;
	}


	public void setCostoComplessivo(double costoComplessivo) {
		this.costoComplessivo = costoComplessivo;
	}


	public Ritiro getRitiro() {
		return ritiro;
	}


	public void setRitiro(Ritiro ritiro) {
		this.ritiro = ritiro;
	}
	
	
	
}
