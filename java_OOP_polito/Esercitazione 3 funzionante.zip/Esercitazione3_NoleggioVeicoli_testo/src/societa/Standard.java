package societa;

public class Standard extends Ritiro{

	public Standard(int codiceNoleggio, String dataRitiro, String codiceRitiro, Noleggio noleggio) {
		super(codiceNoleggio, dataRitiro, codiceRitiro, noleggio);

	}
}
