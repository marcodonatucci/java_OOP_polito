package societa;

public class Veicolo {
	
	private String codiceVeicolo;
	private String descrizione;
	private double costoGiornaliero;
	private int numeroUnita;
	
	
	public Veicolo(String codiceVeicolo, String descrizione, double costoGiornaliero, int numeroUnitaDisponibili) {
		this.codiceVeicolo = codiceVeicolo;
		this.descrizione = descrizione;
		this.costoGiornaliero = costoGiornaliero;
		this.numeroUnita = numeroUnitaDisponibili;
	}


	public String getCodiceVeicolo() {
		return codiceVeicolo;
	}


	public void setCodiceVeicolo(String codiceVeicolo) {
		this.codiceVeicolo = codiceVeicolo;
	}


	public String getDescrizione() {
		return descrizione;
	}


	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}


	public double getCostoGiornaliero() {
		return costoGiornaliero;
	}


	public void setCostoGiornaliero(double costoGiornaliero) {
		this.costoGiornaliero = costoGiornaliero;
	}


	public int getNumeroUnita() {
		return numeroUnita;
	}


	public void setNumeroUnita(int numeroUnita) {
		this.numeroUnita = numeroUnita;
	}
	
	


}
