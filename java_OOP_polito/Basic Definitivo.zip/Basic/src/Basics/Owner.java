package Basics;

public class Owner {
	
	private int id;
	private String firstName;
	private String lastName;
	private	Car c;
	//ora uso i wizard! (ho scritto 3 righe di codice e java me ne ha scritte 40...)
	
	public Owner(int id, String firstName, String lastName) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public Car getC() {
		return c;
	}
	public void setC(Car c) {
		this.c = c;
	}
	
	
	public String descriviti() {
		return id+"; "+firstName+"; "+ lastName;
	}
	
	
}
