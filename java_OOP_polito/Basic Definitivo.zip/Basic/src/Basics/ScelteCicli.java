package Basics;

public class ScelteCicli {

	public static void main(String[] args) {
		
		//COSTRUTTI DI SCELTA O SELEZIONE
		
		int x = 7; 
		
		if(x == 5) {//le parentesi tonde sono necessarie, contengono la condizione, entro nel blocco con le {} se la condizione è verificata
			System.out.println("La variabile vale 5"); 
		    //Eventuali altre istruzioni
		} 
		
		else if(x < 5) //posso anche inserire operatori booleani
			{
			System.out.println("La variabile è minore di 5");
		}
		else {
			System.out.println("La variabile è maggiore di 5"); //il ; va messo dopo le istruzioni non dopo i costrutti senno chiudi il codice in quel punto
			
		}
		
		
		
		//COSTRUTTI DI ITERAZIONE O CICLI
		
		int i = 1; //1)inizializzo la condizione
		
		while (i <= 10) //condizione di permanenza nel ciclo (2)verifico la condizione)
			//se il ciclo è infinito rimane sempre il bottone rosso nella console, femralo e correggi l'errore
		{
			//qui scrivo tutto quello che deve essere ripetuto
			System.out.println(i);
			
			i = i+1; //3) aggiorno la condizione
		}//stampa numeri da 1 a 10
		
		
		//stampa  i numeri da 1 a 10 con do-while: prima entro nel ciclo poi verifico la condizione
		int j = 1;
		do {
			System.out.println(j);
			j = j+1;
				
		}while(j<=10);//verifica la condizione in fondo al ciclo
		
		
		//stampa i numeri da 1 a 10 con il for
		//int k; //posso scrivere int k = 1; direttamente nella parentesi del ciclo for!
		for(int k = 1; k <= 10; k++) //nel for si mette nella parentesi tonda 1)inizializzazione della condizione, 2) verifica, 3) aggiornamento!!
									 //incrementa di 1 la variabile, esiste anche k--
		{
			System.out.println(k);
			
		}
		//posso realizzare la stessa cosa con tutti e tre i cicli 
		//spesso è utile il for quando c'è un operazione di conteggio
		
		
	
		
		
		
		
	}

}
