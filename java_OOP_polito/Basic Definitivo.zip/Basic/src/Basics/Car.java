package Basics;
//cose da fare: creare attributi privati, creare costruttori pubblici e creare getter e setter pubblici
public class Car {
	//ATTRIBUTES (FIELDS)
	private String licensePlate;//gli attributi dovrebbero essere privati
	private String brand;//classi e metodi generalmente più pubblici, di solito si fa così
	private String color;
			Owner o;//la car ha anche un owner, che è un oggetto di classe diversa
	
	//METHODS
	
	//tasto destro>source oppure option-command-S, generate construcotr with fields
	public Car(String licensePlate, String brand, String color) {
		//super();//toglila
		this.licensePlate = licensePlate;//this. vuol dire "questo oggetto"
		this.brand = brand;//Devo disambiguare, quindi vado a capire che quello a sinistra di = è la variabile che ho dichiarato in alto
		this.color = color;// mentre a destra di = c'è il valore passato come parametro
	}
//posso creare costruttori con i parametri che mi servono escludendo gli altri
//gli altri parametri vengono inizializzati ma con null
	public Car(String licensePlate) {
		this.licensePlate = licensePlate;
		//ti conviene sempre inizializzare tutto tu anche se pure java inizializza da solo
		this.brand = "";
		color = "";//è superfluo scrivere this perchè qui non c'è ambiguità
				 //il parametro color non viene uguagliato al parametro color ricevuto dalla funzione
	}
	
	public Car() {
		//vado a definire anche il costruttore vuoto, perchè una volta definiti i costruttori con parametri questo non è più implicito
	}
	
	//definisco i metodi getter che mi leggono gli attributi 
	public String getLicensePlate() {
		return licensePlate;
	}
	
	public String getBrand(){
		return brand;
	}
	
	public String getColor(){
		return color;
	}
	
	public void setLicensePlate(String licensePlate) {//metodo setter per cambiare l'attributo 
		this.licensePlate = licensePlate;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public void setColor(String color) {
		if(color == "Pink")
			System.out.println("Hated color!");// posso controllare nei metodi i valori che vengono dati agli attributi
		this.color = color;//questo vuol dire che posso anche andare a controllare gli errori!
	}
	
	//c'è un wizard che ti permette di creare direttamente i metodi getter e setter per gli attributi della classe
	//source>generate getter and setter
	
	//DELEGA: riorganizzo il codice posizionando le cose "nel punto migliore" limitando gli interventi di modifica
	public String descriviti() {
		return licensePlate+", "+brand+", "+color;
	}
	//i metodi sono l'interfaccia della calsse con il mondo esterno!!
	
	
}
