package Basics;

public class Variabili {

	public static void main(String[] args) {
		
	int x; //DICHIARO una variabile (intero di nome x)
	x = 5; //ASSEGNO un valore alla variabile
	int y = 8; //Tutto in una sola operazione
	
	int z = 0; //Sono OBBLIGATO a inizializzare le variabili prima di usarle!
	
	//x = 5.2; //non si può fare, x è una variabile intera e non puoi assegnarli un valore di un altro tipo
			   //Rischierei di perdere la parte frazionaria!
	
	float f; //valore a virgola mobile su 32 bit
	double d = 5.2; //valore a virgola mobile su 64 bit (ospita più numeri, usa questo)
	
	boolean b = true; //false
	
	byte o; //su 8 bit
			
	short corto; //intero su 16 bit (int è su 32)
	long lungo; //intero su 64 bit
	
	char c = '$'; //caratteri su 16 bit, formato UNICODE, virgolette semplici!
	
	//void è un tipo di dato nullo
	
	String s = "La mia stringa"; //String è un tipo di dato e anche una classe, si usano le doppie virgolette!
								 //JAVA rappresenta le stringhe con un tipo di dato più complesso cioè 
	                             //la classe String, quelli di prima sono tipi "primitivi"
	
	String t = "La variabile d vale: \n\n" + d; //concatenazione con il +, per andare a capo \n
	
	System.out.print(t);
	
	
	
	}

}
