package Basics;
//Questa classe definisce la struttura del "medico"
public class Medico {//non possiede un main quindi non svolgerà funzioni ma sarà un contenitori di dati, quindi una classe vera e propria che contiene gli oggetti

	//Dati del medico = ATTRIBUTI(fields/campi)
	int matricola;
	String nome; 
	String cognome;
	
	
	//operazioni (sui dati) possibili per il medico = METOFDI(funzioni)
	public void visita(){
		
	}
	
	public double opera() {
		return -1;
	}
	
	public Medico() {//Ogni classe è dotata di una funzione speciale con lo stesso nome della classe chiamata "costruttore" (vuoto perchè non ha parametri)
		             //è presente anche se non la scriviamo noi, non ha un valore di ritorno esplicito
		matricola = -1;
		nome = "Sconosciuto";
		cognome = "Sconosciuto";//la funzione costruttore inizializza le variabili in uno stato indefinito 
	                            //tocca a noi cambiare ogni valore scrivendoci dentro
	}
	
	public Medico(int m, String n, String c) {//in questo modo inizializzo i parametri direttamente nella funzione
		                                      //posso chiamare la funzione come l'altra (polimorfismo, anche detto OVERLOADING)
		matricola = m;
		nome = n;
		cognome = c;
	}
	
}
