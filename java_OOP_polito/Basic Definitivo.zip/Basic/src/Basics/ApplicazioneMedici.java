package Basics;

public class ApplicazioneMedici {

	public static void main(String[] args) {
		
		//memorizzazione con un approccio non ad oggetti
		int matricola1 = 12345; //potresti trovare matricole alfanumeriche ma vediamo poi
		String nome1 = "Mario";
		String cognome1 = "Rossi";
		
		int matricola2 = 77777;
		String nome2 = "Gianni";
		String cognome2 = "Verdi";
		
		//memorizzazione dati con approccio object oriented = ISTANZIAZIONE
		Medico m1;//dichiarazione variabile riferimento: finisce nella scatola di memoria delle variabili primitive tipo int x, però si riferisce ad altro (oggetto di una classe)
		m1 = new Medico();//creazione di un oggetto di classe "Medico" con new
		
		m1.matricola = 123456;//inizializzo i campi dell'oggetto (attributi)
		m1.nome = "Mario";//definisco lo stato dell'oggetto m1 valorizzando i suoi campi 
		m1.cognome = "Rossi";//si usa la notazione puntata per accedere al contenuto dell'oggetto di classe medico 
		System.out.println("Matricola: " + m1.matricola + "\n" + "Nome: " + m1.nome + "\n" + "Cognome: " + m1.cognome);//se stampo solo m1 mi viene fuori il riferimento "basics.Medico@1c64627"
		
		Medico m2 = new Medico();//creo un oggetto invocando un metodo detto "costruttore della classe"
		                         //Alloca la memoria e inizializza l'oggetto
		//Se non inizializzo gli attributi mi stampa i valori vuoti per ogni tipo di variabile 
		//(0 per la matricola e null per nome e cognome)
		
		Medico m3 = new Medico(55555, "Anna", "Neri");//Costruisco l'oggetto m3 usando il costruttore con i parametri!
		
		Medico arrayDiMedici[] = new Medico[100];//Ho creato un array di medici
		arrayDiMedici[0] = m1;//Scrivo nell'array i medici
		arrayDiMedici[1] = m2;
		arrayDiMedici[2] = m3;
		
		for(int i = 0; i<arrayDiMedici.length; i++) {//.lenght è un metodo che restituisce la lunghezza dell'array
			Medico m = arrayDiMedici[i];//variabile temporanea
			if(m!=null)//verifico che la variabile sia diversa da null
				System.out.println(m.matricola+", "+m.nome+", "+m.cognome);
		}
	}

}
