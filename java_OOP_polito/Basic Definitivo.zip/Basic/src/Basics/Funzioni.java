package Basics;

public class Funzioni {
	
	public static void main(String args[]) {
		
		laMiaFunzione();
		
		int a = 5;//non è possibile dichiarare una variabile fuori da un blocco di parentesi
		int b = 15;//ogni variabile è visibile solo nel blocco di parentesi in cui è stata creata
		int c = 20;//con le {} si definiscono degli "ambiti di visibilità" (scope)
				   //se dichiari un altra variabile in un blocco diverso anche con lo stesso nome di un altra sono comunque variabili diverse		
		 
		
		double media = (a+b+c)/3.0;//se divido un intero per un frazionario lo ottengo double, senno mi torna un intero (altrimenti dichiari tutto come double)
		
		System.out.println(media);
		
		double media1 = calcolaLaMedia(a,b,c);//parametri attuali della funzione
		System.out.println(media1);           //sono copiati nei parametri formali 
		
		int arr[] = {4, 7, 16, 9, 14}; //dichiaro un array per enumerazione
		
		media = calcolaLaMedia(arr);
		
		System.out.println(media);
		
	}
	
	
	static void laMiaFunzione(){//le funzioni iniziano con la lettera minuscola e si mettono le maiuscole nelle iniziali della altre parole del nome
	//devi dichiarare il tipo di dato che la funzione restituisce, void vuol dire che non restituisce niente
	//nella parentesi tonda scrivi i parametri che prende in input
	//da una funzione statica come il main posso solo chiamare altre funzioni statiche
		System.out.println("Ciao classe :-)");	
	}
	
	//funzione per calcolare la media               //parametri formali della funzione
	static double calcolaLaMedia(int x, int y, int z) {//devo dichiarare il tipo di parametri che entrano nella funzione e del valore di return
		double m = (x + y + z)/3.0;
		return m;//avrei potuto scrivere i calcoli direttamente a return
	}
	
	static double calcolaLaMedia(int[] arr) {//puoi chiamare due funzioni con lo stesso nome e java non si intreccia perchè guarda i parametri che dai in input e capisce quale funzione chiamare
                                             //polimorfismo  		
		double somma = 0;
		for(int i=0; i<arr.length; i++) //premendo . dopo una variabile o un array trovi i metodi per quell'oggetto, lenght ti dice la lunghezza dell'array
			somma += arr[i];//è come dire somma=somma+arr[i];
		double media = somma/arr.length;
		return media;
	}

}
