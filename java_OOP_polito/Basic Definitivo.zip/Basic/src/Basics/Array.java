package Basics;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[] = new int[5]; //DICHIARATO ARRAY, la dimensione è 5 slot di tipo int
		
		int valore = arr[0]; //contenuto della prima cella (si numera da 0!)
		
		System.out.println(valore); //println va a capo dopo aver stampato!
		System.out.print(arr[0] + "\n"); //printo il valore della prima cella
		
		//JAVA inizializza le celle degli array a valori predefiniti, tipo 0 per gli int
		//il suggerimento è sempre inizializzare tu come lo vuoi 
		
		//System.out.println(arr); //non stampa l'array, fa degli errori, si fa in un altro modo
		
		//il calcolatore non riesce a rilevare gli errori concettuali ma quando esegue si ottiene una exception!
		//esempio arr[5] = 72; stai accedendo a una cella fuori dall'array!
		
		
		arr[0]=3;
		arr[1]=6;
		arr[2]=9;
		arr[3]=12;
		arr[4]=15;
		
		for(int i=0; i<5; i++) 
			System.out.println(arr[i]);//se c'è una sola riga di istruzione in for e if si possono togliere le parentesi graffe
		//questo ciclo stampa un array
			
		
		
	}

}
