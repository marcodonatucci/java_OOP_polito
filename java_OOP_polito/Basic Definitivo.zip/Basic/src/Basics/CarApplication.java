package Basics;

public class CarApplication {

	public static void main(String[] args) {
		
		Car c = new Car();//nel momento in cui vado a definire altri costruttori
                          //il costruttore vuoto non è più implicito e devo scriverlo
		Car c0 = new Car("CV666AM","Audi","White");
		Car c1 = new Car("GG123VX","BMW","Red");
		
		/*Car c2 = new Car();
		c2.licensePlate = "FF333BB";
		c2.brand = "Fiat";
		c2.color = "Blue";*/
	/* queste istruzioni diventano sbagliate percgè i dati a cui sto cercando di accedere
	non sono visibili visto che le ho messe private e non posso più accederci direttamente*/
	/*per inizializzare gli attributi si dovrebbero utilizzare i costruttori*/
		Car c2 = new Car("FF123BB","Fiat","Blue");
		Car c3 = new Car("HH111GG");//Java riconosce quale costruttore chiamare
	//non posso accedere agli attributi private neanche in lettura
		
		System.out.println("License plate: "+c0.getLicensePlate());
		System.out.println("Brand: "+c0.getBrand());
		System.out.println("Color: "+c0.getColor());
		//per leggere gli attributi creo dei metodi get e set che mi leggano gli attributi
	
	
		Car cars[] = new Car[100];
		cars[0] = c0;
		cars[1] = c1;
		cars[2] = c2;
		cars[3] = c3;
		
		for(int i = 0; i<cars.length; i++) {
			if(cars[i]!=null)//puoi stampare le celle vuote (null) ma non puoi invocarci metodi senno ti da un eccezione!
				System.out.println(cars[i].getLicensePlate()+", "+cars[i].getBrand()+", "+cars[i].getColor());
		}
		
		for(int i = 0; i<cars.length; i++) {
			if(cars[i]!=null)
				System.out.println(cars[i].descriviti());
		//ho delegato alla classe car il compito di descriversi!
		//ora è facilissimo modificare la descrizione perchè mi basta cambiarla nella classe
		}
		
		Owner o1 = new Owner(111, "Jhon", "Doe");//ALIASING l'oggetto ora ha due nomi
		c0.o = o1; //assegno alla car c0 il suo owner o1 
				//owner non è ancora private e non c'è un costruttore quindi posso farlo 
		
		System.out.println(c0.o.descriviti());
		//vado ad applicare un metodo della classe Owner a un oggetto che si trova come attributo della classe car
	    //CHAINING
		
		// dato l'owner o1 qual'è la car posseduta?
		o1.setC(c0);//assegno la car all'owner
		System.out.println(o1.getC().descriviti());
		
		//posso anche creare un array di cars nella classe owner e invocare i metodi per gli oggetti dell'array
		
		
	
	
	
	
	}   

}
