package ecommerce;

public class Prodotto implements Comparable<Prodotto>{
	
	String codice;
	String nomeCategoria;
	String nomeProdotto; 
	String descrizione;
	double prezzo;
	
	public Prodotto(String codice, String nomeCategoria, String nomeProdotto, String descrizione, double prezzo) {
		this.codice = codice;
		this.nomeCategoria = nomeCategoria;
		this.nomeProdotto = nomeProdotto;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
	}

	public String getCodice() {
		return this.codice;
	}

	public String getNome() {
		return this.nomeProdotto;
	}

	public String getDescrizione() {
		return this.descrizione;
	}

	public double getPrezzo() {
		return this.prezzo;
	}

	@Override
	public int compareTo(Prodotto o) {
		return (int) (this.prezzo-o.prezzo);
	}

	
}


