package ecommerce;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Sito {
	
	TreeMap<String, String> categoriaMap;
	int codiceProdotto;
	TreeMap<String, Prodotto> prodottiMap;
	int codiceUtente;
	TreeMap<String, Utente> utentiMap;
	
	public Sito() {
		this.categoriaMap = new TreeMap<String, String>();
		this.codiceProdotto = 100;
		this.prodottiMap = new TreeMap<String, Prodotto>();
		this.codiceUtente = 1;
		this.utentiMap = new TreeMap<String, Utente>();
	}

	public void nuovaCategoria(String nomeCategoria){
		this.categoriaMap.put(nomeCategoria, nomeCategoria);
	}

	public Collection<String> elencoCategorie(){
		return categoriaMap.values();
	}
	
	public String nuovoProdotto(String nomeCategoria, String nomeProdotto, String descrizione, double prezzo){
		if(categoriaMap.get(nomeCategoria)==null) {
			nuovaCategoria(nomeCategoria);
			String codice = nomeCategoria.toUpperCase().charAt(0) + ("00"+codiceProdotto).substring(("00"+codiceProdotto).length()-5);
			Prodotto prodotto = new Prodotto(codice, nomeCategoria, nomeProdotto, descrizione, prezzo);
			codiceProdotto ++;
			prodottiMap.put(nomeProdotto, prodotto);
			return codice;
		}else{
			String codice = nomeCategoria.toUpperCase().charAt(0) + ("00"+codiceProdotto).substring(("00"+codiceProdotto).length()-5);
			Prodotto prodotto = new Prodotto(codice, nomeCategoria, nomeProdotto, descrizione, prezzo);
			codiceProdotto ++;
			prodottiMap.put(nomeProdotto, prodotto);
			return codice;
		}
	}
	
	public Prodotto cercaProdotto(String stringaRicerca){
		for(Prodotto p: prodottiMap.values()) {
			if(p.codice.toLowerCase().contains(stringaRicerca.toLowerCase())||p.nomeProdotto.toLowerCase().contains(stringaRicerca.toLowerCase())||p.descrizione.toLowerCase().contains(stringaRicerca.toLowerCase())) {
				return p;
			}
		}
		return null;
	}
	
	public Collection<Prodotto> elencoProdottiPerNome(){
		return prodottiMap.values();
	}

	public Collection<Prodotto> elencoProdottiPerPrezzo(){
		LinkedList<Prodotto> copia = new LinkedList<Prodotto>(prodottiMap.values());
		Collections.sort(copia);
		return copia;
	}
	
	public Collection<Prodotto> elencoProdottiPerNome(String nomeCategoria){
		LinkedList<Prodotto> copia = new LinkedList<Prodotto>();
		for(Prodotto p: prodottiMap.values()) {
			if(p.nomeCategoria.equals(nomeCategoria))
				copia.add(p);
		}
		return copia;
	}

	public Collection<Prodotto> elencoProdottiPerPrezzo(String nomeCategoria){
		LinkedList<Prodotto> copia = new LinkedList<Prodotto>();
		for(Prodotto p: prodottiMap.values()) {
			if(p.nomeCategoria.equals(nomeCategoria))
				copia.add(p);
		}
		Collections.sort(copia);
		return copia;
	}
	
	public void nuovoUtente(String nome, String cognome, String email, String indirizzo){
		if(utentiMap.containsKey(email)) {
		}else {
			Utente utente = new Utente(nome, cognome, email, indirizzo, codiceUtente);
			codiceUtente++;
			utentiMap.put(email, utente);
		}
	}
	
	public void nuovoUtente(String nome, String cognome, String email, String indirizzo, String username, String password){
		if(utentiMap.containsKey(email)) {
		}else {
			Utente utente = new UtenteRegistrato(nome, cognome, email, indirizzo, codiceUtente, username, password);
			codiceUtente++;
			utentiMap.put(email, utente);
		}
	}
	
	public Utente cercaUtente(int codiceUtente) throws EccezioneUtenteInesistente{
		for(Utente u: utentiMap.values()) {
			if(u.codice==codiceUtente) {
				return u;
			}
		}
		throw new EccezioneUtenteInesistente();
	}
	
	public String dettagliCarrello(int codiceUtente) throws EccezioneUtenteInesistente{
		String sTemp = "";
		for(Prodotto p: cercaUtente(codiceUtente).carrello.keySet()) {
			sTemp = sTemp + p.codice + " " + p.prezzo + " " + cercaUtente(codiceUtente).carrello.get(p) + "\n";
		}
		if(sTemp.length()>0)
			return sTemp.substring(0, sTemp.length()-1);
		return sTemp;
	}
	
    public void leggiFile(String file){
    	FileReader fr;
		try {
			fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String riga;
			while((riga= br.readLine())!=null) {
				String campi[]=riga.split(";");
				String tipoRiga = campi[0];
				if(tipoRiga.equals("P")) {
					String categoria = campi[1];
					String nome = campi[2];
					String descrizione = campi[3];
					double prezzo = Double.parseDouble(campi[4]);
					try {
						nuovoProdotto(categoria, nome, descrizione, prezzo);
					}catch(Exception e) {
						System.out.println("Formato non valido, riga scartata");
						continue;
					}
				}else if(tipoRiga.equals("U")){
					String nome = campi[1];
					String cognome = campi[2];
					String email = campi[3];
					String indirizzo = campi[4];
					if(campi.length==7) {
						try {
							String username = campi[5];
							String password = campi[6];
							nuovoUtente(nome, cognome, email, indirizzo, username, password);
						}catch(Exception e) {
							System.out.println("Formato non valido, riga scartata");
							continue;
						}
					}else{
						try {
							nuovoUtente(nome, cognome, email, indirizzo);
						}catch(Exception e) {
							System.out.println("Formato non valido, riga scartata");
							continue;
						}
					}
				}else {
					continue;
				}
			}
			br.close();
			fr.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
  
	
}
