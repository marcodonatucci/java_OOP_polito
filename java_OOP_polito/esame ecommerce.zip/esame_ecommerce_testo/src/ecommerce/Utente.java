package ecommerce;

import java.util.*;

public class Utente {
	
	String nome;
	String cognome;
	String email;
	String indirizzo;
	int codice;
	TreeMap<Prodotto, Integer> carrello;
	
	
	
	public Utente(String nome, String cognome, String email, String indirizzo, int codice) {
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;
		this.indirizzo = indirizzo;
		this.codice = codice;
		this.carrello = new TreeMap<Prodotto, Integer>();
		
	}

	public int getCodice() {
		return this.codice;
	}

	public String getNome() {
		return this.nome;
	}

	public String getCognome() {
		return this.cognome;
	}

	public String getEmail() {
		return this.email;
	}

	public String getIndirizzo() {
		return this.indirizzo;
	}

	public void selezionaProdotto(Prodotto prodotto){
		if(carrello.containsKey(prodotto)) {
			carrello.replace(prodotto, carrello.get(prodotto)+1);
		}else {
			carrello.put(prodotto, 1);
		}
	}
	
	public double paga(String data){
		double value = 0.0;
		for(Prodotto p: carrello.keySet()) {
			value += p.prezzo*(carrello.get(p));
		}
		carrello.clear();
		return value;
	}

}
