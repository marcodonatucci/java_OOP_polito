package ecommerce;

import java.util.*;

public class UtenteRegistrato extends Utente{
	
	String username;
	String password;
	boolean log = false;
	LinkedList<String> pagamenti;
	
	

	public UtenteRegistrato(String nome, String cognome, String email, String indirizzo, int codice, String username,
			String password) {
		super(nome, cognome, email, indirizzo, codice);
		this.username = username;
		this.password = password;
		this.pagamenti = new LinkedList<String>();
	}

	public String getUsername() {
		return this.username;
	}

	public String getPassword() {
		return this.password;
	}

	public void login(String username, String password) throws EccezioneLoginFallito{
		if(username.equals(this.username) && password.equals(this.password))
			log = true;
		else{
			throw new EccezioneLoginFallito();
		}
	}

	public void logout(){
		log = false;
	}
	
	public boolean isLoggato() {
		return log;
	}
	
	public double paga(String data){
		double value = 0.0;
		for(Prodotto p: carrello.keySet()) {
			value += p.prezzo*(carrello.get(p));
		}
		carrello.clear();
		if(log)
			pagamenti.add(data + " " + value);
		return value;
	}
	
	public String storicoAcquisti(){
		String s = "";
		for(String sTemp: pagamenti) {
			s += sTemp + ";"+"\n";
		}
		return s.substring(0, s.length()-1);
	}
	
}
