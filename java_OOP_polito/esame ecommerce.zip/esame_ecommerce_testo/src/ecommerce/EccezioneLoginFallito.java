package ecommerce;

@SuppressWarnings("serial")
public class EccezioneLoginFallito extends Exception{
	
}
