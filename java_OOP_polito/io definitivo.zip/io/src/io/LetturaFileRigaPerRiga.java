package io;

import java.io.*;

public class LetturaFileRigaPerRiga {

	public static void main(String[] args) {
		
		try {
			FileReader fr = new FileReader("automobili.txt");
			//il file reader legge dai file e il buffered legge da automobili.txt
			BufferedReader br = new BufferedReader(fr);
			
			String riga;//br può fare la lettura di una riga finchè non trova null
			while((riga= br.readLine())!=null)
				System.out.println(riga);
			
			br.close();
			fr.close();//si chiudono i lettori in ordine inverso di come sono stati aperti!
			
		} catch (Exception e) {//prendo un eccezione generale
			System.out.println("ERRORE!");
		}

	}

}
