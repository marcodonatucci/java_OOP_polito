package io;

import java.io.*;//libreria per input uotput

public class LetturaDaFile {

	public static void main(String[] args) {
		
		try {
			FileReader fr = new FileReader("inputtt.txt");
			//il metodo scatena un eccezione e il wizard ti suggerisce già di metterci try catch
			
			//int i = fr.read();//i metodi di input output possono generare delle eccezioni e java se ne accorge
			//System.out.println((char)i);//devi fare casting a char senno ti printa il codice unicode del carattere (un numero)
			
			int i;
			while((i=fr.read())!=1) {
				System.out.print((char)i);//printa il file un carattere alla volta
			}
			fr.close();//chiudi sempre gli stream!!
		} catch (FileNotFoundException fnfe) {
			System.out.println("ERRORE, FILE NON TROVATO");
		} catch (IOException ioe) {
			System.out.println("ERRORE GENERICO");
		}
			
		
		
	}

}
