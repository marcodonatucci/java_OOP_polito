package jcf;

import java.util.*;

public class ProvaListaApplicazione {

	public static void main(String[] args) {
		
		LinkedList<Car> ll = new LinkedList<Car>();//specifico il tipo di oggetto contenuto nella lista con il simbolo diamond
		//è utile farlo ma non indispensabile
		
		ll.add(new Car("AB123CD", "Alfa Romeo"));
		ll.add(new Car("ZZ999ZZ", "VW"));
		ll.add(new Car("CC444DD", "BMW"));
		
		for(Car o:ll) {//Object
			System.out.println(o);
		}
		
		LinkedList copia = new LinkedList(ll);//in questo modo creo una copia della lista di partenza
		
		//Collections.sort(ll);//dopo il sort cambia l'ordine della lista, quindi anche l'inserimento
		
		Collections.sort(copia);//copiando una lista sto creando una struttura di riferimenti non una copia di ogni oggetto
		//ordinandola ho a disposizione due tipi di ordinamento dei riferimenti degli oggetti della lista
		
		for(Object o:ll) {
			System.out.println(o);
		}//ristampo la lista dopo l'ordinamento
		
		
	}

}
