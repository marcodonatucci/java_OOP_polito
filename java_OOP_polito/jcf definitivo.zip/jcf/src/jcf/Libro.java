package jcf;

public class Libro implements Comparable {
	
	String codice;
	String titolo;
	String autore;
	int numPagine;
	public Libro(String codice, String titolo, String autore, int numPagine) {
		this.codice = codice;
		this.titolo = titolo;
		this.autore = autore;
		this.numPagine = numPagine;
	}
	@Override
	public boolean equals(Object obj) {
		Libro altro = (Libro)obj;
		if(this.codice.equals(altro.codice))
			return true;
		else
			return false;
	}
	@Override
	public String toString() {
		return codice+";"+autore+";"+titolo+";"+numPagine;
	}
	@Override
	public int compareTo(Object o) {
		Libro altro = (Libro)o;
		return this.numPagine-altro.numPagine;//ordino in base al numero di pagine
	}
	
	

}
