package jcf;

import java.util.*;

public class ProvaMappaApplicazione {

	public static void main(String[] args) {
		
		TreeMap tm = new TreeMap();
		
		Car c1 = new Car("AB123CD", "Alfa Romeo");
		
		tm.put("AB123CD", c1);//(key, value)
		
		System.out.println(tm.size());
		
		
		if(tm.containsKey("AB123CD"))
			System.out.println("Trovata");
		else
			System.out.println("Non Trovata");
		
		Car c2 = new Car("FF666ZZ", "Audi");
		tm.put("FF666ZZ", c2);
		tm.put("DD333AA", new Car("DD333AA", "Ferrari"));//posso crearlo diretammente dentro l'oggetto
		
		Car cCercata = (Car) tm.get("FF666ZZ");//faccio downcasting perchè get returna un object
		
		System.out.println("Colonna chiavi:");
		for(Object o: tm.keySet()) {
			System.out.println(o);//la mappa è mantenuta in ordine di chiave, quindi le chiavi sono in ordine 
			//la struttura dati è un albero che parte dal valore medio e ordina a seconda del valore minore o maggiore i nuovi elementi rispetto a quelli già esistenti
		}
		
		
		

	}

}
