package jcf;
//posso parametrizzare anche l'interfaccia per farla lavorare con valori Car
public class Car implements Comparable<Car> {//comparable è un interfaccia che mi permette di comparare gli oggetti
	
	String licensePlate;
	String brand;
	
	public Car(String licensePlate, String brand) {
		this.licensePlate = licensePlate;
		this.brand = brand;
	}

	@Override
	public boolean equals(Object obj) {
		Car other = (Car) obj;
		if(this.licensePlate.equals(other.licensePlate))
			return true;
		else
			return false;
	}

	@Override
	public String toString() {
		return this.licensePlate+" "+this.brand;
	}

	@Override
	public int compareTo(Car o) {
		//qua devo scrivere il codice per comparare il parametro obj con l'oggetto  corrente
		//Car other = (Car)o; //1)down cast da object a car
		
		return this.licensePlate.compareTo(o.licensePlate);//2)scrivi algoritmo di confronto
	}//posso aggiungere un - all'inizio del return per cambiare l'ordinamento (decrescente)
	
	
	
	
	
}
