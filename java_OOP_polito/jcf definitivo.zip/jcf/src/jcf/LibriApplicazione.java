package jcf;

import java.util.*;

public class LibriApplicazione {

	public static void main(String[] args) {
		
		Libro l1 = new Libro("ABC", "Il nome della rosa", "Umberto Eco", 700);
		
		LinkedList ll = new LinkedList();
		ll.add(l1);
		Libro l3 = new Libro("AAA", "Titolo", "A.Autore", 1000);
		ll.add(l3);
		Libro l2 = new Libro("ZZZ", "Titolo libro noioso", "Z.zzz", 500);
		ll.add(l2);
		
		TreeMap tm = new TreeMap();
		tm.put("ABC", l1);
		tm.put("AAA", l3);
		tm.put("ZZZ", l2);
		
		for(Object o: ll) {//sono strutture dati generiche quindi uso Object
			System.out.println(o.toString());
		}
		
		Libro trovato = null;
		for(Object o:ll) {
			if(((Libro)o).codice.equals("AAA")) {
				trovato = (Libro)o;
			}
		}
		
		trovato = (Libro)tm.get("AAA"); //ricerca molto più easy
		
		LinkedList copiaLibri = new LinkedList(ll);//stampiamo i libri in ordine
		
		Collections.sort(copiaLibri);
		for(Object o:copiaLibri) {
			System.out.println(o);
		}
		
		for(Object o: tm.values()) {//printo in ordine di codice 
			System.out.println(o);
		}
		
		//ordinamento per autore usando la classe comparator
		Collections.sort(copiaLibri, new ComparatoreDiLibriPerAutore());//creo un oggetto comparatore
		for(Object o:copiaLibri) {
			System.out.println(o);
		}
		//se voglio ordinare con un altro parametro creo un altra classe con interfaccia comparator e scrivo il codice di ordinamento
		
		
		
		
	}

}