package catering;

import java.util.Comparator;

public class ComparatoreData implements Comparator<Servizio>{

	@Override
	public int compare(Servizio arg0, Servizio arg1) {
		if(arg0.data.equals(arg1.data))
			return arg0.ora.compareTo(arg1.ora);
		return arg0.data.compareTo(arg1.data);
	}

}
