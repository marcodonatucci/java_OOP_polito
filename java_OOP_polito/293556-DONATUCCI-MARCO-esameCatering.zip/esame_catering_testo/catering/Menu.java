package catering;

import java.util.*;

public class Menu implements Comparable<Menu>{
	
	String nomeMenu;
	String descrizione;
	double prezzoPerPersona;
	LinkedList<String> voci;
	
	public Menu(String nomeMenu, String descrizione, double prezzoPerPersona) {
		super();
		this.nomeMenu = nomeMenu;
		this.descrizione = descrizione;
		this.prezzoPerPersona = prezzoPerPersona;
		this.voci = new LinkedList<String>();
	}

	public String getNome() {
		return this.nomeMenu;
	}

	public String getDescrizione() {
		return this.descrizione;
	}

	public double getPrezzoPerPersona() {
		return this.prezzoPerPersona;
	}

	@Override
	public int compareTo(Menu o) {
		return (int) (o.prezzoPerPersona-this.prezzoPerPersona);
	}
	
	public String cercaVoce(String daCercare){
		for(String s: this.voci){
			if(s.equals(daCercare))
				return s;
		}
		return null;
	}

}
