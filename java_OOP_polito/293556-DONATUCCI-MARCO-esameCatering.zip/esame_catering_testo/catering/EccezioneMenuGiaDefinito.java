package catering;

@SuppressWarnings("serial")
public class EccezioneMenuGiaDefinito extends Exception{

}
