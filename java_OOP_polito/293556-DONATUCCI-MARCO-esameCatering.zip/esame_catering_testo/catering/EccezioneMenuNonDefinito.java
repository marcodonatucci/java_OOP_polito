package catering;

@SuppressWarnings("serial")
public class EccezioneMenuNonDefinito extends Exception{

}
