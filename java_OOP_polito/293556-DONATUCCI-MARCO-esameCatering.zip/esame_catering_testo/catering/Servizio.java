package catering;

public class Servizio {
	
	String codice;
	String codiceCliente;
	String nomeMenu;
	String data;
	String ora;
	int numeroPersone;
	double incasso;
	
	public Servizio(String codice, String codiceCliente, String nomeMenu,
			String data, String ora, int numeroPersone, double incasso) {
		super();
		this.codice = codice;
		this.codiceCliente = codiceCliente;
		this.nomeMenu = nomeMenu;
		this.data = data;
		this.ora = ora;
		this.numeroPersone = numeroPersone;
		this.incasso = incasso;
	}
	
}
