package catering;

import java.util.LinkedList;

public class Cliente{
	
	String codice;
	String ragioneSociale;
	String indirizzo;
	String contatto;
	LinkedList<Servizio> servizi;
	
	public Cliente(String codice, String ragioneSociale, String indirizzo,
			String contatto) {
		super();
		this.codice = codice;
		this.ragioneSociale = ragioneSociale;
		this.indirizzo = indirizzo;
		this.contatto = contatto;
		this.servizi = new LinkedList<Servizio>();
	}

	public String getCodice() {
		return this.codice;
	}

	public String getRagioneSociale() {
		return this.ragioneSociale;
	}

	public String getIndirizzo() {
		return this.indirizzo;
	}

	public String getContatto() {
		return this.contatto;
	}
}
