package catering;

import java.util.*;

public class Azienda {
	
	TreeMap<String, Cliente> clientiMapCodice;
	TreeMap<String, Cliente> clientiMapRagione;
	LinkedList<Cliente> clienti;
	int codiceCliente;
	TreeMap<String, Menu> menuMap;
	TreeMap<String, Servizio> servizi;
	LinkedList<Menu> menuList;
	LinkedList<Servizio> serviziList;

	public Azienda() {
		super();
		this.clientiMapCodice = new TreeMap<String, Cliente>();
		this.clientiMapRagione = new TreeMap<String, Cliente>();
		this.clienti = new LinkedList<Cliente>();
		this.codiceCliente = 1;
		this.menuMap = new TreeMap<String, Menu>();
		this.servizi = new TreeMap<String, Servizio>();
		this.menuList = new LinkedList<Menu>();
		this.serviziList = new LinkedList<Servizio>();
	}

	public Cliente registraCliente(String ragioneSociale, String indirizzo, String contatto) {
		Cliente cTemp = cercaClientePerRagioneSociale(ragioneSociale);
		if(cTemp!=null){
			cTemp.contatto = contatto;
			cTemp.indirizzo = indirizzo;
			return cTemp;
		}else{
			if(codiceCliente<1000){
				String codice = "C"+("00"+codiceCliente).substring(("00"+codiceCliente).length()-3);
				codiceCliente++;
				Cliente c = new Cliente(codice, ragioneSociale, indirizzo, contatto);
				clienti.add(c);
				clientiMapCodice.put(codice, c);
				clientiMapRagione.put(ragioneSociale, c);
				return c;
			}
		}
			
		return null;
	}
	
	public Cliente cercaClientePerRagioneSociale(String ragioneSociale) {
		if(clientiMapRagione.containsKey(ragioneSociale))
			return clientiMapRagione.get(ragioneSociale);
		return null;
	}

	public Cliente cercaClientePerCodice(String codiceCliente) {
		if(clientiMapCodice.containsKey(codiceCliente))
			return clientiMapCodice.get(codiceCliente);
		return null;
	}

	public Collection<Cliente> cercaClienti(String daCercare) {
		LinkedList<Cliente> copia = new LinkedList<Cliente>();
		for(Cliente c: clienti){
			if(c.ragioneSociale.toLowerCase().contains(daCercare.toLowerCase()) || c.indirizzo.toLowerCase().contains(daCercare.toLowerCase()) || c.contatto.toLowerCase().contains(daCercare.toLowerCase()))
				copia.add(c);
		}
		return copia;
	}
	
	public Collection<Cliente> elencoClienti() {
		return clientiMapRagione.values();
	}
	
	public Menu definisciMenu(String nomeMenu, String descrizione, double prezzoPerPersona) throws EccezioneMenuGiaDefinito{
		if(menuMap.get(nomeMenu)!=null)
			throw new EccezioneMenuGiaDefinito();
		Menu m = new Menu(nomeMenu, descrizione, prezzoPerPersona);
		menuMap.put(nomeMenu, m);
		menuList.add(m);
		return m;
	}
	
	public MenuLeggero definisciMenu(String nomeMenu, String descrizione, double prezzoPerPersona, int calorie) throws EccezioneMenuGiaDefinito{
		if(menuMap.get(nomeMenu)!=null)
			throw new EccezioneMenuGiaDefinito();
		MenuLeggero m = new MenuLeggero(nomeMenu, descrizione, prezzoPerPersona, calorie);
		menuMap.put(nomeMenu, m);
		menuList.add(m);
		return m;
	}
	
	public Collection<Menu> elencoMenuPerPrezzo(){
		LinkedList<Menu> copia = new LinkedList<Menu>(menuMap.values());
		Collections.sort(copia);
		return copia;
	}

	public boolean aggiungiVoceMenu(String nomeMenu, String voce) throws EccezioneMenuNonDefinito{
		Menu mTemp = menuMap.get(nomeMenu);
		if(mTemp==null)
			throw new EccezioneMenuNonDefinito();
		if(mTemp.cercaVoce(voce)!=null)
			return false;
		mTemp.voci.add(voce);
		return true;
	}
	
	public String stampaMenu(String nomeMenu) throws EccezioneMenuNonDefinito{
		String s = "";
		Menu mTemp = menuMap.get(nomeMenu);
		for(String v: mTemp.voci){
			s += v + "\n";
		}
		if(s.length()>0)
			return s.substring(0, s.length()-1);
		return s;
	}
	
	public String prenotaServizio(String codiceCliente, String nomeMenu, String data, String ora, int numeroPersone) throws EccezioneMenuNonDefinito {
		if(clientiMapCodice.get(codiceCliente)==null)
			return null;
		if(menuMap.get(nomeMenu)==null)
			throw new EccezioneMenuNonDefinito();
		int i = 1;
		String codice = codiceCliente + "-" + data + "-";
		for(Servizio s: servizi.values()){
			if(s.codice.substring(0, 14).equals(codice))
				i++;
		}
		codice += i;
		double incasso = numeroPersone * menuMap.get(nomeMenu).prezzoPerPersona;
		Servizio sTemp = new Servizio(codice, codiceCliente, nomeMenu, data, ora, numeroPersone, incasso);
		servizi.put(codice, sTemp);
		serviziList.add(sTemp);
		clientiMapCodice.get(codiceCliente).servizi.add(sTemp);
		return codice;
	}
	
	public Cliente cercaClienteServizio(String codiceServizio) {
		if(servizi.containsKey(codiceServizio))
			return clientiMapCodice.get(servizi.get(codiceServizio).codiceCliente);
		return null;
	}
	
	public String stampaServiziPerIncasso(){
		LinkedList<Servizio> copia = new LinkedList<Servizio>(servizi.values());
		Collections.sort(copia, new ComparatoreIncassi());
		String s = "";
		for(Servizio sTemp: copia){
			s+= sTemp.codice + " " + sTemp.nomeMenu + " " + sTemp.incasso + "\n";
		}
		if(s.length()>0)
			return s.substring(0, s.length()-1);
		return s;
	}
	
	public String stampaServiziPerDataOra() {
		LinkedList<Servizio> copia = new LinkedList<Servizio>(servizi.values());
		Collections.sort(copia, new ComparatoreData());
		String s = "";
		for(Servizio sTemp: copia){
			s+= sTemp.codice + " " + sTemp.nomeMenu + " " + sTemp.data + " " + sTemp.ora + "\n";
		}
		if(s.length()>0)
			return s.substring(0, s.length()-1);
		return s;
	}

	public double determinaIncassoMedioPerServizio() {
		double i = 0;
		double d = 0.0;
		for(Servizio s: servizi.values()){
			i++;
			d += s.incasso;
		}
		return d/i;
	}

	public double determinaNumeroDiServiziMedioPerCliente() {
		double serviziClienti = 0;
		double clientiTot = 0;
		for(Cliente c: clienti){
			clientiTot++;
		}
		for(Servizio s: servizi.values()){
			serviziClienti++;
		}
		return serviziClienti/clientiTot;
	}
	
	public Collection<Menu> determinaMenuPiuRichiesto() {
		LinkedList<Menu> copia = new LinkedList<Menu>();
		int j = 0;
		for(Menu m: menuList){
			int i = 0;
			for(Servizio s: serviziList){
				if(s.nomeMenu.equals(m.nomeMenu)){
					i = i+1;
				}
			}
			if(i>j){
				j = i;
			}
		}
		for(Menu m: menuList){
			int k = 0;
			for(Servizio s: serviziList){
				if(s.nomeMenu.equals(m.nomeMenu)){
					k = k+1;
				}
			}
			if(k==j){
				copia.add(m);
			}
		}
		if(copia.get(0)!=null){
			return copia;
		}
		return null;
	}
	
}
