package catering;

public class MenuLeggero extends Menu {
	
	int calorie;

	public MenuLeggero(String nomeMenu, String descrizione,
			double prezzoPerPersona, int calorie) {
		super(nomeMenu, descrizione, prezzoPerPersona);
		this.calorie = calorie;
	}


	public int getCalorie() {
		return this.calorie;
	} 
	
}
