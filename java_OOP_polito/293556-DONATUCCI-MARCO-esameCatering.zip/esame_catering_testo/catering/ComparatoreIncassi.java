package catering;

import java.util.Comparator;

public class ComparatoreIncassi implements Comparator<Servizio>{

	@Override
	public int compare(Servizio o1, Servizio o2) {
		return (int)(o1.incasso-o2.incasso);
	}

}
