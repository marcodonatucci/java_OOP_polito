import java.util.*;

import catering.*;

public class Esempio {

	public static void main(String[] args) throws EccezioneMenuGiaDefinito, EccezioneMenuNonDefinito {
		
		
		System.out.println("/******************************/");
		System.out.println("/**        R1. CLIENTI       **/");
		System.out.println("/******************************/\n");

		Azienda a = new Azienda();
		
		System.out.println("Registrato cliente 'Politecnico di Torino - DAUIN' ");
		Cliente c1 = a.registraCliente("Politecnico di Torino - DAUIN", "Corso Duca degli Abruzzi, 24 - Torino", "segreteria.dauin@polito.it");

		System.out.println("\nCodice assegnato al cliente 'Politecnico di Torino - DAUIN':");
		System.out.println(c1.getCodice());
		
		
		System.out.println("\nCerca cliente con ragione sociale 'Politecnico di Torino - DAUIN'\n");
		Cliente cTrovato = a.cercaClientePerRagioneSociale("Politecnico di Torino - DAUIN");

		System.out.println("Informazioni cliente trovato:");
		System.out.println(""+cTrovato.getRagioneSociale());
		System.out.println(""+cTrovato.getIndirizzo());
		System.out.println(""+cTrovato.getContatto());

		System.out.println("\nRegistrati altri clienti");
		            a.registraCliente("Università degli Studi di Milano", "Via Festa del Perdono 7 - Milano", "amministrazione@unimi.it");
		            a.registraCliente("Politecnico di Torino - DET", "Corso Duca degli Abruzzi, 24 - Torino", "segreteria.det@polito.it");
		            a.registraCliente("Galleria degli Uffizi", "Piazzale degli Uffizi, 6 - Firenze", "ANNA.MILANESIO@UFFIZI.IT");
		            a.registraCliente("Fiera Milano", "Largo Metropolitana, 5 - Milano", "ristorazione@fieramilano.it");
		
		
		System.out.println("\nCerca clienti che contengono 'mil' (in ordine di registrazione)\n");
		LinkedList<Cliente> listaClientiTemp = new LinkedList<Cliente>(a.cercaClienti("mil"));

		System.out.println("Clienti trovati:");
		for(Cliente c : listaClientiTemp)
			System.out.println(c.getRagioneSociale()+" "+c.getIndirizzo()+" "+c.getContatto());

		System.out.println("\nElenco clienti (ordinati per ragione sociale):");
		                    listaClientiTemp = new LinkedList<Cliente>(a.elencoClienti());
		for(Cliente c : listaClientiTemp)
			System.out.println(c.getRagioneSociale());

		
		System.out.println("\n\n/******************************/");
		System.out.println("/**         R2. MENU         **/");
		System.out.println("/******************************/\n");

		System.out.println("Definito menu 'Tramezzini'\n");
		Menu m1 = a.definisciMenu("Tramezzini", "Alta gastronomia tra due fette di pane. I nostri tramezzini artigianali sono perfetti per ogni evento.", 8.00);

		System.out.println("Informazioni menu:");
		System.out.println(m1.getNome());
		System.out.println(m1.getDescrizione());
		System.out.println(m1.getPrezzoPerPersona());
		
		System.out.println("\nDefiniti altri menu (anche ipocalorici)");
                  a.definisciMenu("Insalate e poke", "Gusto e freschezza al servizio del benessere. ", 6.00, 500);
		          a.definisciMenu("Terra e mare", "Combina carne e pesce, con sapori invitanti per tutti i tuoi ospiti.", 15.00);
		
		System.out.println("\nElenco menu per prezzo decrescente:");
		LinkedList<Menu> listaMenuTemp = new LinkedList<Menu>(a.elencoMenuPerPrezzo());
		for(Menu m : listaMenuTemp)
			if(m instanceof MenuLeggero)
				System.out.println(m.getNome()+" "+m.getPrezzoPerPersona()+" (ipocalorico)");
			else
				System.out.println(m.getNome()+" "+m.getPrezzoPerPersona());
				
		System.out.println("\nAggiunta di una voce al menu 'Terra e mare'\n");
		boolean esito = a.aggiungiVoceMenu("Terra e mare", "Risotto con gamberi e zucchine");
		
		if(esito==true)
			System.out.println("Voce aggiunta");
		else
			System.out.println("Voce non aggiunta");

		System.out.println("\nAggiunte di altre voci al menu 'Terra e mare'");
                        a.aggiungiVoceMenu("Terra e mare", "Scamone di vitello al forno con funghi porcini");
		                a.aggiungiVoceMenu("Terra e mare", "Dolci di frutta");
		
		System.out.println("\nStampa del menu 'Terra e mare' (voci in ordine di aggiunta):");
		String stringaStampaMenu = a.stampaMenu("Terra e mare");
		System.out.println(stringaStampaMenu);
		
		
		System.out.println("\n\n/******************************/");
		System.out.println("/**       R3. SERVIZI        **/");
		System.out.println("/******************************/\n");

		System.out.println("Prenotazione servizio cliente 'C001' il 20240208 ore 12:00 per 50 persone");
		String codiceServizio = a.prenotaServizio("C001", "Terra e mare", "20240208", "12:00", 50);
		
		System.out.println("\nCodice assegnato al servizio:");
		System.out.println(codiceServizio);

		System.out.println("\nPrenotazione altro servizio cliente 'C001' il 20240208 ore 19:00 per 100 persone");
		       codiceServizio = a.prenotaServizio("C001", "Terra e mare", "20240208", "19:00", 100);

		System.out.println("\nCodice assegnato al servizio:");
		System.out.println(codiceServizio);

		System.out.println("\nPrenotazione di altri servizi");
                                a.prenotaServizio("C003", "Tramezzini", "20240207", "12:00", 10);
	                            a.prenotaServizio("C002", "Insalate e poke", "20240207", "12:00", 10);
	                            a.prenotaServizio("C003", "Terra e mare", "20240209", "15:00", 20);
		
		
		System.out.println("\nStampa servizi per incasso e codice servizio crescenti:");
		String stringaStampaServizi = a.stampaServiziPerIncasso();
        System.out.println(stringaStampaServizi);

		System.out.println("\nStampa servizi per data, ora  e codice servizio crescenti:");
		       stringaStampaServizi = a.stampaServiziPerDataOra();
        System.out.println(stringaStampaServizi);

        
		System.out.println("\n\n/******************************/");
		System.out.println("/**     R4. STATISTICHE      **/");
		System.out.println("/******************************/\n");

        System.out.println("Incasso medio per servizio:");
        double incassoMedioPerServizio = a.determinaIncassoMedioPerServizio();
		System.out.println(incassoMedioPerServizio);

        System.out.println("\nNumero di servizi medio per cliente:");
        double numeroDiServiziMedioPerCliente = a.determinaNumeroDiServiziMedioPerCliente();
		System.out.println(numeroDiServiziMedioPerCliente);

        System.out.println("\nMenu piu' richiesto:");
                          listaMenuTemp = new LinkedList<Menu>(a.determinaMenuPiuRichiesto());
		for(Menu m : listaMenuTemp)
			System.out.println(m.getNome());        
        
	}
}

