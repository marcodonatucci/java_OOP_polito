package Advanced;

public class Intero {
	
	int valore;

	public Intero(int valore) {
		this.valore = valore;
	}

	public int getValore() {
		return valore;
	}

	public void setValore(int valore) {
		this.valore = valore;
	}
	
}
