package Advanced;

public class Car {
	
	String licensePlate;
	static int numCars;//static vuol dire che di questo attributo ce n'è una cola copia condivisa da tutti gli oggetti della classe
	
	public Car(String licensePlate) {
		this.licensePlate = licensePlate;
		//this.numCars = 0;
	}
	
	
}
