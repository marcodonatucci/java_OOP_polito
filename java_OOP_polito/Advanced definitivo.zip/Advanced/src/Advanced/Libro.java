package Advanced;

//import shoes.String;

public class Libro {
	
	private String titolo;
	private String autore;
	private int numPagine;
	
	public Libro() {
		titolo = "N/D";
		autore = "N/D";
		numPagine = -1;	
	}

	public Libro(String titolo, String autore, int numPagine) {
		this.titolo = titolo;
		this.autore = autore;
		this.numPagine = numPagine;
	}//ho creato due costruttori con lo stesso nome: OVERLOADING

	public Libro(String titolo) {
		this.titolo = titolo;
		this.autore = "N/D";
		this.numPagine = -1; 
	}//dovrei inizializzare anche gli altri attributi 
     //Java avrebbe comunque inizializzato ma se lo fai tu meglio!	

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getAutore() {
		return autore;
	}

	public void setAutore(String autore) {
		this.autore = autore;
	}

	public int getNumPagine() {
		return numPagine;
	}

	public void setNumPagine(int numPagine) {
		//posso inserire del codice per il controllo errori:
		if(numPagine >= 1 && numPagine<5000)
			this.numPagine = numPagine;
		else
			System.err.println("ERRORE!");//err scrive in rosso, però appare in righe diverse
	}

	//metodo che descrive la classe sottoforma di stringa nel formato preferito
	public String toString() {
		String s;
		s = "Titolo: "+this.titolo+"\nAutore: "+this.autore+"\nNumero di pagine: "+this.numPagine;
		return s;
	}
	
	
	
}
