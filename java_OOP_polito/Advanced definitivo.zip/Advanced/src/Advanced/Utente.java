package Advanced;

//import shoes.String;

public class Utente {
	
	private int codice;
	private String nome;
	private String telefono;
	
	private Libro libriPresiInPrestito[];
	private int numLibriPresiInPrestito = 0;
	
	public Utente(int codice, String nome, String telefono) {
		this.codice = codice;
		this.nome = nome;
		this.telefono = telefono;
	}

	public void setNumLibriPresiInPrestito(int numLibriPresiInPrestito) {
		this.numLibriPresiInPrestito = numLibriPresiInPrestito;
	}

	public void prendeInPrestito(Libro l2) {
		this.libriPresiInPrestito[this.numLibriPresiInPrestito] = l2;
		numLibriPresiInPrestito++;
		
	}

	
	
	
}
