package Advanced;

public class ApplicazioneMedici {

	public static void main(String[] args) {
	
		Medico m1 = new Medico();
		
		m1.nome="Mario";
		m1.cognome="Verdi";
		m1.matricola=123;
		
		Cardiologo c1 = new Cardiologo();
		
		c1.nome="Luisa";
		c1.cognome="Neri";
		c1.matricola=777;
		c1.specializzazione="Cardiologia sportiva";
		
		System.out.println(m1.describeYourself());//delega
		System.out.println(c1.describeYourself());//il metodo lo può usare anche l'oggetto della classe figlia
		
		Medico m = c1;//posso assegnare a un oggetto di classe padre un oggetto di classe figlia
		Medico medici[] = new Medico[10];
		medici[0]=m1;
		medici[1]=c1;//c1 è anche un medico...
		
		for(int i = 0; i<medici.length; i++) {
			if(medici[i]!=null)
				System.out.println(medici[i].describeYourself());
		}
	
	}

}
