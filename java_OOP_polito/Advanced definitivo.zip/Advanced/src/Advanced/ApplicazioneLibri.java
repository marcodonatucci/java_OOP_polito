package Advanced;

import shoes.Shoe; //importa la classe per poterla usare

//import shoes.String; //è stata inserita da java per poter usare la classe String di un altro package (shoes)

//import shoes.*; //importa tutte le classi che sono nel package shoes

public class ApplicazioneLibri {

	public static void main(String[] args) {
		
		Libro l1 = new Libro();
		
		System.out.println("----Libro 1----");
		System.out.println("Titolo: " + l1.getTitolo());
		System.out.println("Autore: " + l1.getAutore());
		System.out.println("Numero di pagine: " + l1.getNumPagine());
	
		Libro l2 = new Libro("Il signore degli anelli", "Tolkien", 10000);
		
		System.out.println("----Libro 2----");
		System.out.println("Titolo: " + l2.getTitolo());
		System.out.println("Autore: " + l2.getAutore());
		System.out.println("Numero di pagine: " + l2.getNumPagine());
		//al posto di un accesso diretto agli attributi attraverso i metodi getter
		//avrei fatto meglio a usare la delega e lasciare al libro la descrizione
		
		
		//l2.descriviti();//io lo scrivo prima qua e poi eclipse se passo sull'errore mi dice 
		//"il metodo non esiste, vuoi che te lo creo io?" tu ci premi e ti crea nella classe il nuovo metodo
		System.out.println(l2); //==System.out.println(l2.toString());
		//se cerchi di stampare un oggetto con il print java capisce che vuoi stampare una stringa in console
		//se è presente il metodo toString() eclipse lo chiama in automatico quando serve 
		
		l2.setNumPagine(123600);
		
		Libro l3 = new Libro("Il mio libro", "Autore", 100);
		Libro l4 = new Libro("Il mio libro", "Autore", 100);
		
		if(l3 == l4)
			System.out.println("Libri UGUALI");
		else
			System.out.println("Libri DIVERSI");
		//viene printato diversi quando il contenuto è diverso, mentre quando il contenuto è uguale comunque viene printato diversi
		//l'operatore == confronta il riferimento (posizione in memoria) e non il contenuto!!
		//anche le stringhe non andrebbero confrontate con ==
		//usa .equalse() o .compareTo()

		String s1 = "ABC";
		String s2 = "DEF";
		if (s1.compareTo(s2) == 0) //== 0 se uguali
			System.out.println("Stringhe uguali");
		else 
			System.out.println("Stringhe diverse");
		
		//costruiamo un array di oggetti libro
		
		Libro libri[] = new Libro[10];
		libri[0] = l1;
		libri[1] = l2;
		libri[2] = l3;
		
		for(int i = 0; i<libri.length; i++) {
			Libro lTemp = libri[i]; //variabile temporanea 
			if(lTemp!=null)
				System.out.println(lTemp.toString());
		}
		
		//stampo l'array con un ciclo for each:
		
		for(Libro l: libri) {//per ogni Libro l, che prendiamo dall'array libri...
			if(l!=null)
				System.out.println(l.toString());
		}//se ti serve un indice usa il for i, però se ti serve solo l'oggetto conviene for each
			
		
		Utente u1 = new Utente(123, "Mario Rossi", "011 556677");
	
		u1.prendeInPrestito(l2);
		
		Shoe scarpa;
		
		shoes.Shoe scarpetta; //creo un oggetto con una classe da un altro package
		
		
		
		
		
	}
	
}
