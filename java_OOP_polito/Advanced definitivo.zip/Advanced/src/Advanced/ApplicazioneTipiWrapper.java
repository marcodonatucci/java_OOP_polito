package Advanced;

public class ApplicazioneTipiWrapper {//i tipi wrapper sono tipi di dati pensati per dare un imprinting a oggetti ai tipi primitivi

	public static void main(String[] args) {
		/*
		Intero i = new Intero(5);
		System.out.println(i.getValore());
		i.setValore(2);
*/
		
		Integer i = 5;  //new Integer(5); non usare il costruttore
		
		int j = i +23; //puoi combinare tra loro tipi primitivi e wrapped (autoboxing o unboxing)
		
		String s = "33";
		
		int k = Integer.parseInt(s); //converto String in un valore numerico
		
		
	}

}
