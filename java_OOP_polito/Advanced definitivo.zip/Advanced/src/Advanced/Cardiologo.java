package Advanced;

public class Cardiologo extends Medico {//la classe cardiologo deriva dal medico, quindi eredita gli attributi

	//puoi aggiungere ciò che manca
	
	String specializzazione; //attributo specifico solo del cardiologo
	
	public void aggiornaSpecializzazione(String specializzazione) {//puoi creare metodi specifici per la classe figlia 
		this.specializzazione=specializzazione;
	}
	
	//puoi anche cambiare ciò che "non va bene"
	public String describeYourself() {
		return matricola+" "+nome+" "+cognome+" "+specializzazione;//hai esteso il metodo della classe padre
	}
	
}
