package Advanced;

public class Medico {
	
	String nome;
	String cognome;
	int matricola;
	
	public String describeYourself() {
		return matricola+" "+nome+" "+cognome;
	}
	
	
	
}
