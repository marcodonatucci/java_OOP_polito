package Advanced;
import java.math.*;
public class ApplicazioneCars {

	public static void main(String[] args) {//le cose più utili da dichiarare static sono i metodi (puoi usarlo per dire che ce n'è una copia soltanto comune a tutti)
		
		//int numCars = 0;
		
		Car c1 = new Car("AB567JK");
		c1.numCars++;
		
		Car c2 = new Car("DD777ZZ");
		c2.numCars++;
		
		System.out.println(c2.numCars);
		
		double d = Math.pow(4, 15); //il metodo pow è static nella classe Math quindi non devo creare un pggetto di classe Math per invocare il metodo pow
									//il metodo ha una S rossa che vuol dire che è statico
		
		final double PI_GRECO = 3.14; //final vuol dire che il valore non può essere cambiato (COSTANTE)
		
		
		
		
	}

}
