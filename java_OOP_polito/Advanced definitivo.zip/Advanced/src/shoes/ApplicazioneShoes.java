package shoes;

public class ApplicazioneShoes {

	public static void main(String[] args) {
		
		java.lang.String laMiaStringa = "ABC"; //uso il fully qualifier name cioè il nome completo della classe String di java, che non è la classe String che ho creato io
		
		shoes.String iMieiLacci = new shoes.String(); //Advanced è il package della classe string 
		
		
		
		
	}

}
