package shoes;

public class Shoe {

}
