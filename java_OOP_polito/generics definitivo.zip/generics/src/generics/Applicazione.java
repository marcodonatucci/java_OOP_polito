package generics;

public class Applicazione {

	public static void main(String[] args) {
		
		//int identificativo = 5;//decido che id è un intero
		String identificativo = "5";
		
		//la classe persona è raw type cioè generica, java ti consente di esserlo ma poi
		//devi usare il diamond per dichiarare il tipo di valore che vai ad usare
		Persona<String> p = new Persona<String>(identificativo, "Mario", "Rossi");
		
		String id = (String)p.getId();
		
		System.out.println(id);
		
		//<E> element <T> type <V> value <K> key: tipi generici
		
	}

}
