package generics;

public class Persona<T> {//posso parametrizzare la classe e utilizzare valori di tipo T (sta per type)
	
	//Object id;//dichiari una variabile di tipo generico
	T id;
	String nome;
	String cognome;
	
	public Persona(T id, String nome, String cognome) {
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
	}

	public T getId() {
		return id;
	}

	public void setId(T id) {
		this.id = id;
	}
	
	
	
}
