package exceptions;

public class CalcoloMediaException extends Exception{//è una eccezione 
	
	

}
