package exceptions;

public class CalcoloMediaApproccioAllOrNothing {

	public static void main(String[] args) throws CalcoloMediaException {
		
		try {
		//qui inizia il codice funzionale, che esegue qualche operazione
			String array[] = {"1", "5", "24", "sette"};//faccio verificare un eccezione (NumberFormatException)
		
			double somma = 0.0;
		
			for(int i = 0; i<array.length;i++) {
				double d = Double.parseDouble(array[i]);
				somma += d;
			}
		
			System.out.println("Media: " + somma/array.length);
		}catch(NumberFormatException nfe) {//scrivi nel catch il nome dell'eccezione e gli dai un nome che convenzionalmente sono le lettere iniziali del nome 
			//nfe.printStackTrace(); //ristampa esattamente la traccia dell'errore e blocca il programma!!
			throw new CalcoloMediaException();
		}
		
	}

}
