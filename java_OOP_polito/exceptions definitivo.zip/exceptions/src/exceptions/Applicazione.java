package exceptions;

public class Applicazione {

	public static void main(String[] args) {
		
		String s = null;
		System.out.println(s.toString());//nullPointerException
		
		int array[] = {10, 20, 30};
		for(int i = 0; i<4; i++) {
			System.out.println(array[i]);//ArrayIndexOutOfBoundException
		}
		
		Object o = new String("abcde");
		int i = (int) o;//ClassCastException
		
		
		//quando si verifica un errore java scatena un eccezione che è rappresentata da una classe!
		//quando hai un oggetto che segnala un errore puoi gestirlo 
		
		
		
		
	}

}
