package exceptions;

public class CalcoloMediaApproccioChirurgico {

	public static void main(String[] args) {
		
			String array[] = {"1", "5", "24", "sette"};//faccio verificare un eccezione (NumberFormatException)
		
			double somma = 0.0;
			
			int num = 0;
		
			for(int i = 0; i<array.length;i++) {
				double d = 0;
				
				try {//metto il blocco try solo intorno alla riga che mi da problemi
					 d = Double.parseDouble(array[i]);
					 num++;
				}catch(NumberFormatException nfe) {
					System.out.println("ERRORE");
				}//uscirà il messaggio di errore però il programma andrà avanti e calcolerà la media delle celle che andavano bene
				 //se mi metto intorno alla singola istruzione critica posso usare un approccio chirurgico
				somma += d;
			}
		
			System.out.println("Media: " + somma/num);
		
	}

}
