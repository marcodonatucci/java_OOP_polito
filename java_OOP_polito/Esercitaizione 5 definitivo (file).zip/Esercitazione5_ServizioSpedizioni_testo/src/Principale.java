import java.util.LinkedList;

import spedizioni.*;

public class Principale {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) throws AggiornamentoNonEsistenteException, ClienteNonEsistenteException {

		Servizio s = new Servizio();
		
		System.out.println("\n/****** R1 ******/");
		
		System.out.println("Nuove registrazioni");
		Cliente c1 = s.nuovaRegistrazione("andrea.bianchi@gmail.com", "Andrea", "Bianchi");
		Cliente c2 = s.nuovaRegistrazione("luca.blu@gmail.com", "Luca", "Blu");
		Cliente c3 = s.nuovaRegistrazione("martina.rossi@gmail.com", "Martina", "Rossi");
		
		System.out.println("\nClienti Registrati:\n");
		System.out.println(s.descriviCliente(c1.getEmail()));
		System.out.println(s.descriviCliente(c2.getEmail()));
		System.out.println(s.descriviCliente(c3.getEmail()));
		
		System.out.println("\nRicerca cliente:\n");
		Cliente cTrovato = s.cercaClientePerEmail("martina.rossi@gmail.com");
		System.out.println(s.descriviCliente(cTrovato.getEmail()));
		
		System.out.println("\nRicerca cliente/i per nome e cognome:\n");
		
		LinkedList cTrovatiNomeCognome = new LinkedList(s.cercaClientePerNomeCognome("n", "i"));
		for(Object o : cTrovatiNomeCognome) {
			Cliente c = (Cliente) o;
			System.out.println(s.descriviCliente(c.getEmail()));
		}
			
		System.out.println("\nElenco clienti:\n");
		LinkedList elencoClienti = new LinkedList(s.elencoClienti());
		for(Object o : elencoClienti) {
			Cliente c = (Cliente) o;
			System.out.println(s.descriviCliente(c.getEmail()));
		}
		
		System.out.println("\n/****** R2 ******/");
		
		System.out.println("Nuove spedizioni");
		Spedizione sp1 = s.nuovaSpedizione("andrea.bianchi@gmail.com","Porto antico di Genova", "Rinfuso");
		Spedizione sp2 = s.nuovaSpedizione("andrea.bianchi@gmail.com", "Luigi Lavazza S.p.A. Stabilimento", 1);
		Spedizione sp3 = s.nuovaSpedizione("andrea.bianchi@gmail.com", "Orlando International Airport", 57.3);
		Spedizione sp4 = s.nuovaSpedizione("luca.blu@gmail.com", "Europoort & Merseyweg", "Unitarizzato");
		Spedizione sp5 = s.nuovaSpedizione("luca.blu@gmail.com", "Hamburger Hafen", "Unitarizzato");
		Spedizione sp6 = s.nuovaSpedizione("martina.rossi@gmail.com","Ferrero Spa Stabilimento", 2);
		Spedizione sp7 = s.nuovaSpedizione("luca.blu@gmail.com", "Beijing Capital International Airpor", 50.5);
		
		System.out.println("\nSpedizioni create:\n");
		System.out.println(s.descriviSpedizione(sp1.getCodiceSpedizione()));
		System.out.println(s.descriviSpedizione(sp2.getCodiceSpedizione()));
		System.out.println(s.descriviSpedizione(sp3.getCodiceSpedizione()));
		System.out.println(s.descriviSpedizione(sp4.getCodiceSpedizione()));
		System.out.println(s.descriviSpedizione(sp5.getCodiceSpedizione()));
		System.out.println(s.descriviSpedizione(sp6.getCodiceSpedizione()));
		System.out.println(s.descriviSpedizione(sp7.getCodiceSpedizione()));
		
		System.out.println("\nRicerca spedizione:\n");
		Spedizione spedTrovata = s.cercaSpedizione(2);
		System.out.println(s.descriviSpedizione(spedTrovata.getCodiceSpedizione()));
		
		System.out.println("\nElenchi spedizioni");
		System.out.println("\nCodice, crescente:\n");
		LinkedList<Spedizione> elenco1 = new LinkedList<Spedizione>(s.elencoSpedizioniPerCodice());
		for(Spedizione sp : elenco1)
			System.out.println(s.descriviSpedizione(sp.getCodiceSpedizione()));
		
		
		System.out.println("\nCategoria:\n");
		LinkedList<Spedizione> elenco2 = new LinkedList<Spedizione>(s.elencoSpedizioniPerCategoria());
		for(Spedizione sp : elenco2)
			System.out.println(s.descriviSpedizione(sp.getCodiceSpedizione()));
		
		System.out.println("\nSpedizioni aeree per peso carico:\n");
		System.out.println(s.elencoSpedizioniPerPesoCarico());
		
		System.out.println("\n/****** R3 ******/");
		
		System.out.println("Nuovi aggiornamenti");
		LinkedList<String> aggiornamenti1 = new LinkedList<String>();
		aggiornamenti1.add("1;La spedizione sta procedendo senza ritardi;20231202 11:30:00");
		aggiornamenti1.add("2;La spedizione ha riscontrato dei ritardi a causa del traffico;20231202 12:35:00");
		LinkedList<Aggiornamento> aggiornamentiUtente1 = new LinkedList<Aggiornamento>(s.nuoviAggiornamenti("andrea.bianchi@gmail.com", aggiornamenti1));
		
		System.out.println("\nAggiornamenti creati:\n");
		for(Aggiornamento ag : aggiornamentiUtente1)
			System.out.println(ag.getDescrizione() + " " + ag.getTimestamp());
		
		System.out.println("\nAltri aggiornamenti");
		LinkedList<String> aggiornamenti2 = new LinkedList<String>();
		aggiornamenti2.add("1;La spedizione ha riscontrato dei ritardi a causa di problemi tecnici;20231202 11:45:00");
		aggiornamenti2.add("2;La spedizione è in partenza;20231202 11:30:00");
		aggiornamenti2.add("7;La spedizione sta procedendo senza ritardi;20231202 11:30:00");
		//aggiornamenti2.add("8;La spedizione sta arrivando a destinazione;20231202 11:30:00");
		LinkedList<Aggiornamento> aggiornamentiUtente2 = new LinkedList<Aggiornamento>(s.nuoviAggiornamenti("andrea.bianchi@gmail.com", aggiornamenti2));
		
		System.out.println("\nAggiornamenti creati:\n");
		for(Aggiornamento ag : aggiornamentiUtente2)
			System.out.println(ag.getDescrizione() + " " + ag.getTimestamp());
		
		System.out.println("\nAggiornamenti di una spedizione:\n");
		for(Aggiornamento ag : s.aggiornamentiSpedizione(2))
			System.out.println(ag.getDescrizione() + " " + ag.getTimestamp());
		
		System.out.println("\nRicerca aggiornamento:\n");
		Aggiornamento aTrovato = s.cercaAggiornamentoPerCodice(1);
		System.out.println(aTrovato.getDescrizione() + " " + aTrovato.getTimestamp());
		
		System.out.println("\nElenco aggiornamenti per cliente\n");
		LinkedList<Aggiornamento> aggiornamentiTrovati = new LinkedList<Aggiornamento>(s.elencoAggiornamentiPerEmailCliente("andrea.bianchi@gmail.com"));
		
		for (Aggiornamento agTemp : aggiornamentiTrovati) {
			System.out.println("Aggiornamento:" + agTemp.getCodice());
			System.out.println(agTemp.getDescrizione() + " " + agTemp.getTimestamp());
		}
		
		System.out.println("\n/****** R4 ******/");
		
		System.out.println("\nLettura da file:\n");
		Servizio s2 = new Servizio();
		
		s2.leggiDatiSpedizioni("input.txt");
		
		System.out.println("\nElenco clienti:\n");
		LinkedList elencoClienti2 = new LinkedList(s2.elencoClienti());
		for(Object o : elencoClienti2) {
			Cliente c = (Cliente) o;
			System.out.println(s2.descriviCliente(c.getEmail()));
		}			
		
		System.out.println("\nElenco spedizioni:\n");
		LinkedList<Spedizione> elencoSpedizioni2 = new LinkedList<Spedizione>(s2.elencoSpedizioniPerCodice());
		for(Spedizione c : elencoSpedizioni2)
			System.out.println(s2.descriviSpedizione(c.getCodiceSpedizione()));
	}

}