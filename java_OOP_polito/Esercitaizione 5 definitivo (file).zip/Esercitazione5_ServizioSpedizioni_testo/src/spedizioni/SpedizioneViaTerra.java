package spedizioni;


public class SpedizioneViaTerra extends Spedizione{
	
	private int numeAutocarriRichiesti;
	
	public SpedizioneViaTerra(String emailCliente, String destinazione, int codiceSpedizione, int numeAutocarriRichiesti) {
		super(emailCliente, destinazione, codiceSpedizione);
		this.numeAutocarriRichiesti=numeAutocarriRichiesti;
	}

	
	public int getNumeAutocarriRichiesti() {
		return this.numeAutocarriRichiesti;
	}


	@Override
	public String toString() {
		return super.toString()+" "+"TER"+" "+numeAutocarriRichiesti;

	}


	@Override
	public int compareTo(Spedizione o) {
		if(o instanceof SpedizioneViaTerra) 
			return -this.numeAutocarriRichiesti-((SpedizioneViaTerra)o).numeAutocarriRichiesti;
		else
			return super.compareTo(o);
		
	}
	
	
		


	
	
	
}
