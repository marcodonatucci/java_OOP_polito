package spedizioni;

@SuppressWarnings("serial") // Inserito per evitare che Java segnali warning per il fatto che manca un identificativo per l'eccezione
public class ClienteNonEsistenteException extends Exception {

}
