package spedizioni;

public class Aggiornamento implements Comparable<Aggiornamento>{
	
	private int codice;
	private String codiceSpedizione;
	private String descrizione;
	private String timeStamp;

	public Aggiornamento(int codiceAggiornamento, String codiceSpedizione, String descrizione, String timeStamp) {
		this.codice = codiceAggiornamento;
		this.codiceSpedizione = codiceSpedizione;
		this.descrizione = descrizione;
		this.timeStamp = timeStamp;
	}

	public int getCodice() {
		return codice;
	}
	
	public String getDescrizione() {
		return descrizione;
	}
	
	public String getTimestamp() {
		return timeStamp;
	}
	
	public String getCodiceSpedizione() {
		return codiceSpedizione;
	}

	@Override
	public int compareTo(Aggiornamento o) {
		return this.timeStamp.compareTo(o.timeStamp);
	}
	
	

}
