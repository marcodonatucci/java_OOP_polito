package spedizioni;


public class SpedizioneViaAerea extends Spedizione{
	
	private double pesoCarico;

	
	public SpedizioneViaAerea(String emailCliente, String destinazione, int codiceSpedizione, double pesoCarico) {
		super(emailCliente, destinazione, codiceSpedizione);
		this.pesoCarico = pesoCarico;
	}



	public double getPesoCarico() {
		return this.pesoCarico;
	}



	@Override
	public String toString() {
		return super.toString()+" "+"AER" +" "+ pesoCarico;
	}



	@Override
	public int compareTo(Spedizione o) {
		if(o instanceof SpedizioneViaAerea)
			return (int) Math.round(this.pesoCarico-((SpedizioneViaAerea)o).pesoCarico);
		else 
			return super.compareTo(o);
	}
	
	

}

