package spedizioni;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Servizio {
	
	private LinkedList<Cliente> clienti;
	private LinkedList<Spedizione> spedizioni;
	private int codiceSpedizione;
	private int codiceAggiornamento;
	private TreeMap<Integer, Spedizione> mappaSpedizioni;
	
	public Servizio() {
		this.clienti = new LinkedList<Cliente>();
		this.spedizioni = new LinkedList<Spedizione>();
		this.codiceSpedizione = 1;
		this.codiceAggiornamento = 1;
		this.mappaSpedizioni = new TreeMap<Integer, Spedizione>();
	}	
	
	public Cliente nuovaRegistrazione(String email,  String nome, String cognome) {
		if(cercaClientePerEmail(email)!=null) 
			return cercaClientePerEmail(email);
		else {
			Cliente c = new Cliente(email, nome, cognome);
			clienti.add(c);
			return c;
		}
		
	}
	
	public String descriviCliente(String email) {
		Cliente cTemp = cercaClientePerEmail(email);
		if(cTemp!=null)
			return cTemp.toString();
		else
			return null;
	}
	
	public Cliente cercaClientePerEmail(String email) {
		for(Cliente cliente: clienti) {
			if(cliente.getEmail().equals(email)) 
				return cliente;
		}
		return null;
	}
	
	@SuppressWarnings("rawtypes") // Inserito per evitare che Java segnali warning per il fatto che non sono (ancora) utilizzati i Generics < >
	public Collection cercaClientePerNomeCognome(String nome, String cognome){
		LinkedList<Cliente> elencoClienti = new LinkedList<Cliente>();
		for(Cliente c: clienti) {
			if(c.getNome().contains(nome)&&c.getCognome().contains(cognome)) {
				elencoClienti.add(c);
			}
		}
		Collections.sort(elencoClienti);
		return elencoClienti;
	}
	
	@SuppressWarnings("rawtypes") // Inserito per evitare che Java segnali warning per il fatto che non sono (ancora) utilizzati i Generics < >
	public Collection elencoClienti(){
		LinkedList<Cliente> elencoClienti = new LinkedList<Cliente>(clienti);
		Collections.sort(elencoClienti);
		return elencoClienti;
	}
	
	public SpedizioneViaTerra nuovaSpedizione(String emailCliente, String destinazione, int numeAutocarriRichiesti) {
		if(cercaClientePerEmail(emailCliente)!=null) {
			SpedizioneViaTerra s = new SpedizioneViaTerra(emailCliente, destinazione, codiceSpedizione, numeAutocarriRichiesti);
			spedizioni.add(s);
			mappaSpedizioni.put(codiceSpedizione, s);
			codiceSpedizione ++;
			cercaClientePerEmail(emailCliente).setSpedizioni(s);
			return s;
		}
		return null;
	}
	
	public SpedizioneViaMare nuovaSpedizione(String emailCliente, String destinazione, String tipologiaCarico) {
		if(cercaClientePerEmail(emailCliente)!=null) {
			SpedizioneViaMare s = new SpedizioneViaMare(emailCliente, destinazione, codiceSpedizione, tipologiaCarico);
			spedizioni.add(s);
			mappaSpedizioni.put(codiceSpedizione, s);
			codiceSpedizione ++;
			cercaClientePerEmail(emailCliente).setSpedizioni(s);
			return s;
		}
		return null;
	}
	
	public SpedizioneViaAerea nuovaSpedizione(String emailCliente, String destinazione, double pesoCarico) {
		if(cercaClientePerEmail(emailCliente)!=null) {
			SpedizioneViaAerea s = new SpedizioneViaAerea(emailCliente, destinazione, codiceSpedizione, pesoCarico);
			spedizioni.add(s);
			mappaSpedizioni.put(codiceSpedizione, s);
			codiceSpedizione ++;
			cercaClientePerEmail(emailCliente).setSpedizioni(s);
			return s;
		}
		return null;
	}
	
	public String descriviSpedizione(int codiceSpedizione) {
		Spedizione sTemp = cercaSpedizione(codiceSpedizione);
		if(sTemp!=null) {
			return sTemp.toString();
		}
		return null;
	}
	
	public Spedizione cercaSpedizione(int codiceSpedizione) {
		for(Spedizione s: spedizioni) {
			if(s.getCodiceSpedizione()==codiceSpedizione)
				return s;
		}
		return null;
	}
	
	public Collection<Spedizione> elencoSpedizioniPerCodice() {
		return mappaSpedizioni.values();
	}
	
	public Collection<Spedizione> elencoSpedizioniPerCategoria() {
		LinkedList<Spedizione> elencoSpedizioni = new LinkedList<Spedizione>();
		LinkedList<Spedizione> spedizioniMare = new LinkedList<Spedizione>();
		LinkedList<Spedizione> spedizioniAereo = new LinkedList<Spedizione>();
		for(Spedizione s: spedizioni) {
			if(s instanceof SpedizioneViaTerra)
				elencoSpedizioni.add(s);
			else if(s instanceof SpedizioneViaMare)
				spedizioniMare.add(s);
			else if(s instanceof SpedizioneViaAerea)
				spedizioniAereo.add(s);
				
		}
		Collections.sort(elencoSpedizioni);
		elencoSpedizioni.addAll(spedizioniMare);
		elencoSpedizioni.addAll(spedizioniAereo);
		return elencoSpedizioni;
	}
	
	public String elencoSpedizioniPerPesoCarico() {
		LinkedList<Spedizione> spedizioniAereo = new LinkedList<Spedizione>();
		for(Spedizione s: spedizioni) {
			if(s instanceof SpedizioneViaAerea)
				spedizioniAereo.add(s);
		}
		Collections.sort(spedizioniAereo);
		String risultato = "";
		for(Spedizione s: spedizioniAereo) {
			risultato += s.toString()+"\n";
		}
		return risultato.substring(0, risultato.length()-1);
	}
	
	public Collection<Aggiornamento> nuoviAggiornamenti(String emailCliente, Collection<String> aggiornamenti) {
		Cliente cTemp = cercaClientePerEmail(emailCliente);
		if(cTemp!=null) {
			LinkedList<Aggiornamento> aggiornamentiCreati = new LinkedList<Aggiornamento>();
			for(String aggiornamento: aggiornamenti) {
				String campi[] = aggiornamento.split(";");
				String codiceSpedizione = campi[0];
				String descrizione = campi[1];
				String timeStamp = campi[2];
				if(cercaSpedizione(Integer.parseInt(codiceSpedizione))!=null) {
					Aggiornamento a = new Aggiornamento(codiceAggiornamento, codiceSpedizione, descrizione, timeStamp);
					codiceAggiornamento++;
					cercaSpedizione(Integer.parseInt(codiceSpedizione)).setAggiornamenti(a);
					aggiornamentiCreati.add(a);
				}else
					return null;
			}
			return aggiornamentiCreati;
		}
		return null;
	}
	
	public Collection<Aggiornamento> aggiornamentiSpedizione(int codiceSpedizione){
		if(cercaSpedizione(codiceSpedizione)!=null) {
			LinkedList<Aggiornamento> aggiornamentiCopia = new LinkedList<Aggiornamento>(cercaSpedizione(codiceSpedizione).getAggiornamenti());
			Collections.sort(aggiornamentiCopia);
			return aggiornamentiCopia;
		}
		return null;
	}
	
	public Aggiornamento cercaAggiornamentoPerCodice(int codiceAggiornamento) throws AggiornamentoNonEsistenteException{
			for(Spedizione s: spedizioni) {
				for(Aggiornamento a: s.getAggiornamenti()) {
					if(a.getCodice()==codiceAggiornamento) {
						return a;
					}
				}
			}
			throw new AggiornamentoNonEsistenteException();

	}
	
	public Collection<Aggiornamento> elencoAggiornamentiPerEmailCliente(String emailCliente) throws ClienteNonEsistenteException{
			if(cercaClientePerEmail(emailCliente)!=null) {
				LinkedList<Aggiornamento> aggiornamentiTrovati = new LinkedList<Aggiornamento>();
				for(Spedizione s: spedizioni) {
					if(s.getEmailCliente().equals(emailCliente)) {
						aggiornamentiTrovati.addAll(s.getAggiornamenti());
					}
				}
				Collections.sort(aggiornamentiTrovati);
				return aggiornamentiTrovati;
			}
		throw new ClienteNonEsistenteException();
	}
	
	public void leggiDatiSpedizioni(String nomeFile) {	
		
		FileReader fr;
		try {
			fr = new FileReader(nomeFile);
			BufferedReader br = new BufferedReader(fr);
			String riga;
			while((riga= br.readLine())!=null) {
				String campi[]=riga.split(";");
				String tipoRiga = campi[0];
				String email = campi[1];
				if(tipoRiga.equals("CLI")) {
					String nome = campi [2];
					String cognome = campi[3];
					try {
						nuovaRegistrazione(email, nome, cognome);
					}catch(Exception e) {
						System.out.println("Formato non valido, riga scartata");
						continue;
					}
				}else if(tipoRiga.equals("SPED")){
					String destinazione = campi[2];
					String tipologia = campi[3];
					if(tipologia.equals("TER")) {
						try {
							int autocarri = Integer.parseInt(campi[4]);
							nuovaSpedizione(email, destinazione, autocarri);
						}catch(Exception e) {
							System.out.println("Formato non valido, riga scartata");
							continue;
						}
					}else if(tipologia.equals("MAR")) {
						try {
							String carico = campi[4];
							nuovaSpedizione(email, destinazione, carico);
						}catch(Exception e) {
							System.out.println("Formato non valido, riga scartata");
							continue;
						}
					}else if(tipologia.equals("AER")) {
						try {
							double peso = Double.parseDouble(campi[4]);
							nuovaSpedizione(email, destinazione, peso);
						}catch(Exception e) {
							System.out.println("Formato non valido, riga scartata");
							continue;
						}
					}
				}else {
					continue;
				}
			}
			br.close();
			fr.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
