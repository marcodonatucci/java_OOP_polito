package spedizioni;

import java.util.*;

public class Cliente implements Comparable<Cliente> {
	
	private String email;
	private String nome;
	private String cognome;
	private LinkedList<Spedizione> spedizioni;
	
	
	
	public Cliente(String email, String nome, String cognome) {
		this.email = email;
		this.nome = nome;
		this.cognome = cognome;
		this.spedizioni = new LinkedList<Spedizione>();
	}



	public LinkedList<Spedizione> getSpedizioni() {
		return spedizioni;
	}



	public void setSpedizioni(Spedizione spedizione) {
		spedizioni.add(spedizione);
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getCognome() {
		return cognome;
	}



	public void setCognome(String cognome) {
		this.cognome = cognome;
	}



	@Override
	public String toString() {
		return email+" "+nome+" "+cognome;
	}



	@Override
	public int compareTo(Cliente o) {
		if(this.nome.equals(o.nome))
			return this.cognome.compareTo(o.cognome);
		else
			return this.nome.compareTo(o.nome);
	}
	
	
	
}
