package spedizioni;


public class SpedizioneViaMare extends Spedizione{
	
	private String tipologiaCarico;
	
	
	
	public SpedizioneViaMare(String emailCliente, String destinazione, int codiceSpedizione, String tipologiaCarico) {
		super(emailCliente, destinazione, codiceSpedizione);
		this.tipologiaCarico = tipologiaCarico;
	}



	public String getTipologiaCarico() {
		return this.tipologiaCarico;
	}



	@Override
	public String toString() {
		return super.toString()+" "+"MAR" +" "+ tipologiaCarico;
	}
	
	
	
}

