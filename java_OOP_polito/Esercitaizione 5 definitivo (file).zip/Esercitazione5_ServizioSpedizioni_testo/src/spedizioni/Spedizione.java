package spedizioni;

import java.util.*;

public class Spedizione implements Comparable<Spedizione>{
	
	protected String emailCliente;
	protected String destinazione;
	protected int codiceSpedizione;
	protected LinkedList<Aggiornamento> aggiornamenti;
	
	public Spedizione(String emailCliente, String destinazione, int codiceSpedizione) {
		this.emailCliente = emailCliente;
		this.destinazione = destinazione;
		this.codiceSpedizione = codiceSpedizione;
		this.aggiornamenti=new LinkedList<Aggiornamento>();
	}
	
	
	
	public LinkedList<Aggiornamento> getAggiornamenti() {
		return aggiornamenti;
	}



	public void setAggiornamenti(Aggiornamento aggiornamento) {
		aggiornamenti.add(aggiornamento);
	}



	public String getEmailCliente() {
		return emailCliente;
	}
	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}
	public String getDestinazione() {
		return destinazione;
	}
	public void setDestinazione(String destinazione) {
		this.destinazione = destinazione;
	}

	public int getCodiceSpedizione() {
		return codiceSpedizione;
	}

	public void setCodiceSpedizione(int codiceSpedizione) {
		this.codiceSpedizione = codiceSpedizione;
	}

	@Override
	public String toString() {
		return codiceSpedizione+" "+emailCliente+" "+destinazione;
	}

	@Override
	public int compareTo(Spedizione o) {
		return this.codiceSpedizione-o.codiceSpedizione;
	}
	
	

	

}
