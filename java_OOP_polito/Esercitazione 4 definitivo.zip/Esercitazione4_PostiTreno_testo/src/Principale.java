import prenotazioni.*;

public class Principale {

	public static void main(String[] args) {

		Treno t = new Treno();

		// R1. Utenti
		
		System.out.println("Aggiunto utente");

		Utente u1 = t.registraUtente("mario.rossi@gmail.com", "Rossi", "Mario", 25);
		
		System.out.println("\nInformazioni utente aggiunto");

		System.out.println("Email: "+u1.getEmail());
		System.out.println("Cognome: "+u1.getCognome());
		System.out.println("Nome: "+u1.getNome());
		System.out.println("Eta': "+u1.getEta());
		
		System.out.println("\nAggiunto altro utente");

		Utente u2 = t.registraUtente("andrea.bianchi@gmail.com", "Bianchi", "Andrea", 31);
		
		System.out.println("\nInformazioni utente aggiunto");

		System.out.println("Email: "+u2.getEmail());
		System.out.println("Cognome: "+u2.getCognome());
		System.out.println("Nome: "+u2.getNome());
		System.out.println("Eta': "+u2.getEta());
		
		System.out.println("\nRicerca utente: mario.rossi@gmail.com");
		
		Utente uTrovato = t.cercaUtente("mario.rossi@gmail.com");
		
		System.out.println("\nInformazioni utente trovato");
		
		System.out.println("Email: "+uTrovato.getEmail());
		System.out.println("Cognome: "+uTrovato.getCognome());
		System.out.println("Nome: "+uTrovato.getNome());
		System.out.println("Eta': "+uTrovato.getEta());
		
		System.out.println("\nElenco utenti");
		Utente[] utentiRegistrati = t.utenti();
		
		if (utentiRegistrati != null) {
			for (Utente ui: utentiRegistrati) {
				System.out.println(ui.getEmail());
			}			
		}
		else {
			System.out.println("Nessun utente registrato");
		}
		
		// R2. Posti a sedere
		
		System.out.println("\nCreazione posto a sedere di tipo Economy");

		System.out.println("\nAggiunto posto a sedere");
		
		Posto p1 = t.aggiungiPosto('E', 3, 30);
		
		if(p1 instanceof Economy)
			System.out.println("Tipologia: Economy");
		else if(p1 instanceof Business)
			System.out.println("Tipologia: Business");
		else 
			System.out.println("Tipologia: N/D");

		System.out.println("\nInformazioni posto a sedere aggiunto");
		
		System.out.println("Codice posto a sedere: "+p1.getCodicePosto());
		System.out.println("Carrozza numero: "+ p1.getCarrozza());
		System.out.println("Costo posto a sedere: "+ p1.getCosto());
		
		System.out.println("\nCreazione posto a sedere di tipo Business");
		
		Posto p2 = t.aggiungiPosto('B', 1, 30);

		System.out.println("\nInformazioni posto a sedere aggiunte");
		
		if(p2 instanceof Economy)
			System.out.println("Tipologia: Standard");
		else if(p2 instanceof Business)
			System.out.println("Tipologia: Business");
		else 
			System.out.println("Tipologia: N/D");

		System.out.println("\nInformazioni posto a sedere aggiunto");
		
		System.out.println("Codice posto a sedere: "+p2.getCodicePosto());
		System.out.println("Carrozza numero: "+ p2.getCarrozza());
		System.out.println("Costo posto a sedere: "+ p2.getCosto());
		
		System.out.println("\nRicerca posto a sedere: B_1_1");
		
		Posto pTrovato = t.cercaPosto("B_1_1");
		
		System.out.println("\nInformazioni posto a sedere trovato");
		
		System.out.println("Codice posto a sedere: "+pTrovato.getCodicePosto());
		System.out.println("Carrozza numero: "+ pTrovato.getCarrozza());
		System.out.println("Costo posto a sedere: "+ pTrovato.getCosto());
		
		System.out.println("\nElenco posti a sedere");
		String elencoPosti = t.elencoPosti();
		System.out.println(elencoPosti);
	
		// R3. Prenotazioni e costi
		
		System.out.println("Ricerca di posti a sedere disponibili di tipo Business 20231124");
		Posto[] postiDisponibili = t.cercaPostiDisponibili('B', "20231124");
		
		if (postiDisponibili == null) {
			System.out.println("\nPosti a sedere di tipologia Business non disponibili per i parametri usati");
		}
		else {
			System.out.println("\nCodici posti a sedere disponibili di tipologia Business");
			for (Posto pi : postiDisponibili) {
				System.out.println(pi.getCodicePosto());
			}
		}
		
		System.out.println("\nPrenotazione posto a sedere B_1_1 da parte di mario.rossi@gmail.com");
		Posto postoPrenotato= t.nuovaPrenotazione("mario.rossi@gmail.com", "B_1_1", "20231124");
		
		System.out.println("\nCodice posto a sedere prenotato");
		
		System.out.println("Codice posto a sedere: "+postoPrenotato.getCodicePosto());
		System.out.println("Carrozza numero: "+ postoPrenotato.getCarrozza());
		System.out.println("Costo posto a sedere: "+ postoPrenotato.getCosto());
		
		System.out.println("\nAltra prenotazione di un posto a sedere E_3_1 da parte di mario.rossi@gmail.com");
		t.nuovaPrenotazione("mario.rossi@gmail.com", "E_3_1", "20231125");
		
		System.out.println("\nAltra prenotazione di un posto a sedere B_1_1 da parte di andrea.bianchi@gmail.com");
		t.nuovaPrenotazione("andrea.bianchi@gmail.com", "B_1_1", "20231123");
		
		System.out.println("\nCalcolo della somma dei costi delle prenotazioni dell'utente mario.rossi@gmail.com");
		double costoTotaleUtente = t.calcolaCostoPrenotazioniUtente("mario.rossi@gmail.com");
		System.out.println(costoTotaleUtente+" euro");
		
		System.out.println("\nCalcolo della somma dei costi delle prenotazioni effettuate");
		double costoTotalePrenotazioni = t.calcolaCostoPrenotazioni();
		System.out.println(costoTotalePrenotazioni+" euro");
		
		// R3. Elenchi
		
		System.out.println("\nElenco prenotazioni dell'utente mario.rossi@gmail.com");
		String prenotazioniUtente = t.elencoPrenotazioniUtente("mario.rossi@gmail.com");
		System.out.println(prenotazioniUtente);
		
		System.out.println("Elenco prenotazioni per il posto a sedere B_1_1 in ordine di data");
		String prenotazioniPosto = t.elencoPrenotazioniPostoOrdinatePerData("B_1_1");
		System.out.println(prenotazioniPosto);
			
				
	}

}