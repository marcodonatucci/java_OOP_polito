package prenotazioni;

public class Carrozza {
	
	private int postiE;
	private int postiB;
	private int numeroCarrozza;
	
	public Carrozza(int numeroCarrozza) {
		this.numeroCarrozza=numeroCarrozza;
		this.postiE = 0;
		this.postiB = 0;
	}
	
	public int nuovoPostoE() {
		postiE++;
		return postiE;
	}
	
	public int nuovoPostoB() {
		postiB++;
		return postiB;
	}

	public int getPostiE() {
		return postiE;
	}

	public int getPostiB() {
		return postiB;
	}

	public int getNumeroCarrozza() {
		return numeroCarrozza;
	}
	
	
	
	
	

}
