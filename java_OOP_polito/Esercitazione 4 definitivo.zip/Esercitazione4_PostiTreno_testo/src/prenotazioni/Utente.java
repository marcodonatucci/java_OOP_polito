package prenotazioni;

import java.util.LinkedList;

public class Utente {
	private String email;
	private String cognome;
	private String nome;
	private int eta;
	private LinkedList<Prenotazione> prenotazioni;
	
	public Utente(String email, String cognome, String nome, int eta) {
		this.email = email;
		this.cognome = cognome;
		this.nome = nome;
		this.eta = eta;
		this.prenotazioni=new LinkedList();
	}

	public String getEmail() {
		return this.email;
	}

	public String getCognome() {
		return this.cognome;
	}

	public String getNome() {
		return this.nome;
	}

	public int getEta() {
		return this.eta;
	}
	
	public LinkedList<Prenotazione> getPrenotazioni() {
		return prenotazioni;
	}

	public void setPrenotazioni(Prenotazione prenotazione) {
		prenotazioni.add(prenotazione);
	}

	public void setParameters(String cognome, String nome, int eta) {
		this.cognome=cognome;
		this.nome=nome;
		this.eta=eta;
	}
}
