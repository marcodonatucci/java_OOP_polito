package prenotazioni;

import java.util.LinkedList;

public class Prenotazione {
	
	private Posto posto;
	private String data;
	private Utente utente;
	
	public Prenotazione(Posto posto, String data, Utente utente) {
		this.posto = posto;
		this.data = data;
		this.utente = utente;
	}

	public Posto getPosto() {
		return posto;
	}

	public String getData() {
		return data;
	}

	public Utente getUtente() {
		return utente;
	}

	@Override
	public String toString() {
		return posto.getCodicePosto() + " " + data;
	}

	public String toStringPosto() {
		return utente.getEmail() + " " + data;
	}
	
	
	
	
	
}
