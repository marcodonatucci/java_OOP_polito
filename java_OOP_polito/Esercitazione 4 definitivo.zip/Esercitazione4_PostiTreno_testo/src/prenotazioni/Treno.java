package prenotazioni;

import java.util.*;

public class Treno {
	
	private LinkedList<Utente> utenti;
	private LinkedList<Posto> posti;
	private LinkedList<Carrozza> carrozze;
	private LinkedList<Prenotazione> prenotazioni;
	
	public Treno(){	
		this.utenti= new LinkedList();
		this.posti = new LinkedList();
		this.carrozze=new LinkedList();
		this.prenotazioni=new LinkedList();
	}
	
	public Utente registraUtente(String email, String cognome, String nome, int eta) {
		if(eta>=18) {
			Utente uTemp = cercaUtente(email);
			if(uTemp==null) {
				utenti.add(new Utente(email, cognome, nome, eta));
				return utenti.getLast();
			}
			else {
				uTemp.setParameters(cognome, nome, eta);
				return uTemp;
			}
		}
		return null;
	}
	
	public Utente cercaUtente(String email) {
		for(Utente u: utenti) {
			if(u.getEmail().equals(email))
				return u;
		}
		return null;
	}
	
	public Utente[] utenti() {
		int size = utenti.size();
		if(size>0) {
			Utente utentiTrovati[] = new Utente[size];
			int i = 0;
			for(Utente u: utenti) {
				utentiTrovati[i] = u;
				i++;
			}
			return utentiTrovati;
		}
		return null;//potevi creare l'array di dimensione utenti.size, poi usare il metodo utenti.toArray(utentiTrovati);
					//ovviamente dopo aver controllato che la size sia >0. (riempi l'array creato con il contenuto della lista)
	}

	public Posto aggiungiPosto(char tipologia, int carrozza, double prezzo) {
		if(tipologia=='E') {
			if(cercaCarrozza(carrozza)!=null) {
				String codicePosto = tipologia + "_" + carrozza + "_" + cercaCarrozza(carrozza).nuovoPostoE();
				posti.add(new Economy(tipologia, carrozza, prezzo, codicePosto));
				return posti.getLast();
			}
			else {
				Carrozza c = new Carrozza(carrozza);
				String codicePosto = tipologia + "_" + carrozza + "_" + c.nuovoPostoE();
				posti.add(new Economy(tipologia, carrozza, prezzo, codicePosto));
				carrozze.add(c);
				return posti.getLast();
			}
		}
		else {
			if(cercaCarrozza(carrozza)!=null) {
				String codicePosto = tipologia + "_" + carrozza + "_" + cercaCarrozza(carrozza).nuovoPostoB();
				posti.add(new Business(tipologia, carrozza, (prezzo + (prezzo*0.3)), codicePosto));
				return posti.getLast();
			}
			else {
				Carrozza c = new Carrozza(carrozza);
				String codicePosto = tipologia + "_" + carrozza + "_" + c.nuovoPostoB();
				posti.add(new Business(tipologia, carrozza, (prezzo + (prezzo*0.3)), codicePosto));
				carrozze.add(c);
				return posti.getLast();
			}
		}
	}
	
	public Posto cercaPosto(String codicePosto) {
		for(Posto p: posti) {
			if(p.getCodicePosto().equals(codicePosto))
				return p;
		}
		return null;
	}
	
	public String elencoPosti() {
		String description = "";
		for(Posto p: posti) {
			description = description + p.toString() + "\n";
			
		}
		return description.substring(0, description.length()-1);
	}
	
	public Posto[] cercaPostiDisponibili(char tipologia, String data) {
		LinkedList<Posto> postiTipologia = new LinkedList();
		LinkedList<Posto> prenotazioniData = new LinkedList();
		for(Posto posto: posti) {
			if(posto.getTipologia()==tipologia) {
				postiTipologia.add(posto);
			}
		}
		for(Prenotazione prenotazione: prenotazioni) {
			if(prenotazione.getData().equals(data)) {
				prenotazioniData.add(prenotazione.getPosto());
			}
		}
		for(Posto p: postiTipologia) {
			if(prenotazioniData.contains(p)) {
				postiTipologia.remove(p);
			}
		}
		if(postiTipologia.size()==0)
			return null;
		else {
			Posto postiTrovati[] = new Posto[postiTipologia.size()];
			int i = 0;
			for(Posto p: postiTipologia) {
				postiTrovati[i]=p;
				i++;
			}
			return postiTrovati;
		}
	}
	
	public Posto nuovaPrenotazione(String email, String codicePosto, String data) {
		if(cercaPosto(codicePosto)!=null&&cercaUtente(email)!=null) {
			Posto postoPrenotare = cercaPosto(codicePosto);
			Utente utenteP = cercaUtente(email);
			Posto postiDisponibili[] = cercaPostiDisponibili(postoPrenotare.getTipologia(), data);
			if(postiDisponibili!=null) {
				for(Posto p: postiDisponibili) {
					if(p.getCodicePosto().equals(codicePosto)) {
						Prenotazione nuovaP = new Prenotazione(postoPrenotare, data, utenteP);
						prenotazioni.add(nuovaP);
						utenteP.setPrenotazioni(nuovaP);
						postoPrenotare.setPrenotazioni(nuovaP);
						return postoPrenotare;
					}
				}
				return null;
			}
			return null;
		}
		return null;
	}
	
	public double calcolaCostoPrenotazioniUtente(String email) {
		Utente utente = cercaUtente(email);
		double totale = 0.0;
		for(Prenotazione p: utente.getPrenotazioni()) {
			totale += p.getPosto().getCosto();
		}
		return totale;
	}
	
	public double calcolaCostoPrenotazioni() {
		double totale = 0.0;
		for(Utente u: utenti) {
			totale += calcolaCostoPrenotazioniUtente(u.getEmail());
		}
		return totale;
	}

	public String elencoPrenotazioniUtente(String email) {
		Utente utente = cercaUtente(email);
		String risultato = "";
		if(utente != null) {
			if(utente.getPrenotazioni().size()>0) {
				for(Prenotazione p: utente.getPrenotazioni()) {
					risultato += p.toString() + "\n";
				}
				return risultato.substring(0, risultato.length()-1);
			}
			return risultato;
		}
		return null;
	}
	
	public String elencoPrenotazioniPostoOrdinatePerData(String codicePosto) {
		Posto posto = cercaPosto(codicePosto);
		String risultato = "";
		if(posto != null) {
			if(posto.getPrenotazioni().size()>0) {
				posto.bubbleSortData();
				for(Prenotazione p: posto.getPrenotazioni()) {
					risultato += p.toStringPosto() + "\n";
				}
				return risultato.substring(0, risultato.length()-1);
			}
			return risultato;
		}
		return null;
	}
	
	public Carrozza cercaCarrozza(int carrozza) {
		for(Carrozza c: carrozze) {
			if(carrozza == c.getNumeroCarrozza()) {
				return c;
			}
		}
		return null;
	}
	
}


