package prenotazioni;

public class Economy extends Posto {

	public Economy(char tipologia, int carrozza, double prezzo, String codicePosto) {
		super(tipologia, carrozza, prezzo, codicePosto);
	}
	
	
}
