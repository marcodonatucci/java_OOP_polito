package prenotazioni;

import java.util.LinkedList;

public class Posto{
	protected char tipologia;
	protected int carrozza;
	protected double prezzo;
	protected String codicePosto;
	protected LinkedList<Prenotazione> prenotazioni;
	
	public Posto(char tipologia, int carrozza, double prezzo, String codicePosto) {
		this.tipologia = tipologia;
		this.carrozza = carrozza;
		this.prezzo = prezzo;
		this.codicePosto = codicePosto;
		this.prenotazioni = new LinkedList();
	}

	public String getCodicePosto() {
		return this.codicePosto;
	}

	public int getCarrozza() {
		return this.carrozza;
	}

	public double getCosto() {
		return this.prezzo;
	}

	public char getTipologia() {
		return tipologia;
	}
	
	

	public LinkedList<Prenotazione> getPrenotazioni() {
		return prenotazioni;
	}

	public void setPrenotazioni(Prenotazione prenotazione) {
		prenotazioni.add(prenotazione);
	}

	@Override
	public String toString() {
		String infoPosto[] = codicePosto.split("_");
		String numeroPosto = infoPosto[2];
		return tipologia + " " + carrozza + " " + numeroPosto;
	}
	
	public void bubbleSortData() {
		for(int i = 0; i<this.prenotazioni.size()-1; i++) {
			for(int j = 0; j<this.prenotazioni.size()-1-i; j++) {
				if(this.prenotazioni.get(j).getData().compareTo(this.prenotazioni.get(j+1).getData())>0){
					Prenotazione pTemp = this.prenotazioni.get(j);
					this.prenotazioni.set(j, this.prenotazioni.get(j+1));
					this.prenotazioni.set(j+1, pTemp);
				}
			}
				
		}
	}//per ordine decrescente inverti > nell'if
	
}
