package prenotazioni;

public class Business extends Posto{

	public Business(char tipologia, int carrozza, double prezzo, String codicePosto) {
		super(tipologia, carrozza, prezzo, codicePosto);

	}
	

}

