package musei;

public class Museo {
	
	// Inserire tutti gli attributi necessari, eventualmente creare altre classi
	String nomeMuseoClasse;
	int numeroVisitatoriClasse;
	String arrayCodici[] = new String[100];
	int arrayEta[] = new int[100];
	double arrayDimensioni[] = new double[100];
	/**
	 * Imposta il nome del museo
	 */
	public void setNome(String nomeMuseo) {
		nomeMuseoClasse = nomeMuseo;
	}
	
	/**
	 * Restituisce il nome del museo
	 */
	public String getNome() {
		return nomeMuseoClasse;
	}

	/**
	 * Imposta il numero massimo di visitatori del museo
	 */
	public void setNumeroVisitatori(int numeroVisitatori) {
		numeroVisitatoriClasse = numeroVisitatori;
	}

	/**
	 * Restituisce il numero massimo di visitatori del museo
	*/
	public int getNumeroVisitatori() {
		return numeroVisitatoriClasse;
	}

	/**
	 * Gestisce la creazione / registrazione di un artefatto
	*/  
	public void nuovoArtefatto(String codiceArtefatto, int etaArtefatto, double dimensioneArtefatto) {
		for (int i=0; i<100; i++) {
			if(arrayCodici[i] == null && arrayEta[i] == 0 && arrayDimensioni[i] == 0.0) {
				arrayCodici[i] = codiceArtefatto;
				arrayEta[i] = etaArtefatto;
				arrayDimensioni[i] = dimensioneArtefatto;
				break;
			}
		}
	}

 	/**
 	 * Restituisce le informazioni relative all'ultimo artefatto
	 */  
	public String ultimoArtefatto() {
		String s = null;
		for (int i=99; i>=0; i--) {
			if(arrayCodici[i] != null && arrayEta[i] != 0 && arrayDimensioni[i] != 0.0) {
				s = arrayCodici[i] + ", " + arrayEta[i] + ", " + arrayDimensioni[i];
				break;
			}
		}
		return s;
	}

	/**
	* Restituisce le informazioni relative all'artefatto il cui codice è passato come parametro 
	*/  
	public String cercaArtefatto(String codiceArtefatto) {
		String s = null;
		for (int i=0; i<100; i++) {
			if(arrayCodici[i] == codiceArtefatto) {
				s = arrayCodici[i] + ", " + arrayEta[i] + ", " + arrayDimensioni[i];
				break;
			}
		}
		return s;
	}

	/**
	 * Restituisce la media delle età degli artefatti nel museo la cui dimensione è superiore a quella passata come parametro
	 */  
	public double mediaEtaArtefattiMuseo(double sogliaDimensioneArtefatto) {
		double k = 0.0;
		int j = 0;
		for (int i=0; i<100; i++) {
			if(arrayDimensioni[i] > sogliaDimensioneArtefatto) {
				j += arrayEta[i];
				k++;
			}
		}
		return j/k;	
	}

}
