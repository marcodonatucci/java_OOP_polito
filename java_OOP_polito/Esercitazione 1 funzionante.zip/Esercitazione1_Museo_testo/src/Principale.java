
import musei.Museo;

public class Principale {
		
	public static void main(String[] args) {

		
		System.out.println("*************************************************************************************");
		System.out.println("*                           Prima parte (prima settimana)                           *");
		System.out.println("*                 Stampare le informazioni sui singoli artefatti                    *");
	    System.out.println("*                    interagendo solo con la classe Principale                      *");
		System.out.println("*************************************************************************************\n");
		
		// Prendere confidenza con Eclipse e le basi della programmazione in Java 
		
		// Inserire il codice di qui in avanti
		
		String nomeMuseo1 = "Museo Egizio";
		String codiceArtefatto = "AZ1893LL";
		int etaArtefatto = 5000;
		double dimensioneArtefatto = 30.3;
		
		String nomeMuseo2 = "GAM";
		String codiceArtefatto1 = "AK444TH";
		int etaArtefatto1 = 10;
		double dimensioneArtefatto1 = 15.2;
		
		System.out.println(nomeMuseo1 + ", " + codiceArtefatto + ", " + etaArtefatto + ", " + dimensioneArtefatto);
		System.out.println(nomeMuseo2 + ", " + codiceArtefatto1 + ", " + etaArtefatto1 + ", " + dimensioneArtefatto1);
		
		printEtaArtefatto(5678);//Prova funzione creata fuori dal main
		
		//struttura di array esercizio 1
		
		String[] arrayArtefatti = new String[100];
		
		arrayArtefatti[0] = "Uffizi, AB1234CD, 6578, 76.4";
		arrayArtefatti[1] = "Louvre, GH7890JK, 5423, 90.2";
		arrayArtefatti[2] = "British museum, ER9876OP, 4537, 65.5";
		arrayArtefatti[3] = "Musei vaticani, YU9836NM, 1342, 87,1";
		arrayArtefatti[4] = "Ermitage, XC7382QW, 174, 13,9";
		
		//ciclo che stampa l'array senza stampare i valori vuoti
		for(int i=0; i<100 && arrayArtefatti[i] != null; i++) 
			System.out.println(arrayArtefatti[i]);
		
		
		
		
		System.out.println("");
		System.out.println("*************************************************************************************");
		System.out.println("*                        Seconda parte (seconda settimana)                          *");
		System.out.println("*   Modificando la classe Museo (ed eventualmente aggiungendo altre classi),        *");
		System.out.println("*    di seguito verranno mostrate le altre informazioni memorizzate dal sistema     *");
		System.out.println("*************************************************************************************\n");

		// Iniziare a ragionare in termini di classi e oggetti

		// Viene creato un oggetto di classe Museo, e se ne impostano il nome e il numero di massimo di visitatori 
		
		Museo m = new Museo();
		m.setNome("MAO: Museo di Arte Orientale");
		m.setNumeroVisitatori(125);
		
		// Il nome e il numero di visitatori sono accessibil attraverso i metodi getNome() e getNumeroVisitatori()

		String nomeMuseo = m.getNome();
		int numeroVisitatori = m.getNumeroVisitatori();
		
		System.out.println("Creato museo '"+ nomeMuseo +"', numero massimo di visitatori "+ numeroVisitatori);
		
		// La registrazione di un nuovo artefatto viene gestita dal metodo nuovoArtefatto()
		
		m.nuovoArtefatto("AK439JJ", 80, 24.5);
		m.nuovoArtefatto("QG876GH", 30, 5.7);
		m.nuovoArtefatto("AF654GG", 20, 2.5);
		
		// Per accedere alle informazioni relative all'ultimo artefatto si utilizza il metodo ultimoArtefatto()

		System.out.println("\nUltimo artefatto:");
		String ultimoArtefatto = m.ultimoArtefatto();
		System.out.println(ultimoArtefatto);
		
		// Per accedere alle informazioni relative ad uno qualsiasi degli artefatti si utilizza il metodo cercaArtefatto()

		System.out.println("\nArtefatto con codice AK439JJ");
		String artefattoCercato = m.cercaArtefatto("AK439JJ");
		System.out.println(artefattoCercato);
	
		// restituisce un valore di tipo double relativo alla media dell'eta degli artefatti con un determinato livello di valore

		System.out.println("\nMedia età artefatti nel museo con dimensione superiore a cm^3");
		double mediaAnniArtefatti = m.mediaEtaArtefattiMuseo(5);
		System.out.println(mediaAnniArtefatti);
	
	
	
	}
	
	static void printEtaArtefatto(int eta){
		System.out.println(eta);
		//funzione che printa l'età passata come parametro
	}
	
}
