package Inheritance;

public class Car {
	
	
	protected String licensePlate; //quando usi l'ereditarietà li dichiari protected così sono visibili alle subclasses
	protected String brand;
	protected String color;
	protected boolean turnedOn = false;
	
	public Car(String licensePlate, String brand, String color) {
		this.licensePlate = licensePlate;
		this.brand = brand;
		this.color = color;
		
	 }

	public void turnOn() {
		System.out.println("Car has been turned on");
		turnedOn = true;
	}
	
	public String describeYourself() {
		return licensePlate+";"+brand+";"+color+";"+turnedOn;
	}
	
}
