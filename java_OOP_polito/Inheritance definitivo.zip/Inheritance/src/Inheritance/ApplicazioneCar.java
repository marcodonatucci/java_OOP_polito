package Inheritance;

public class ApplicazioneCar {

	public static void main(String[] args) {
	
		//Car c1 = new Car("AB123CD", "Audi", "Verde");
		
		Car c1 = new Car("AB123CD", "Audi", "Black");
		//c1.licensePlate="AB123CD";
		//c1.brand="Audi";
		//c1.color="Black";
		
		c1.turnOn();
									//POLIMORFISMO
		ElectricCar c2 = new ElectricCar("GG666GG","Tesla","Green",false); //una variabile riferimento più generica (Car) può ospitare una variebile di tipo più specifico (ElectricCar)
		//c2.licensePlate="GG666GG";
		//c2.brand="Tesla";
		//c2.color="Green";
		
		//c2.turnOn();
		
		Car c3 = c2; //polimorfismo che dicevo sopra
		
		c2.recharge();
		
		//c3.recharge(); //noi abbiamo indicato c3 come Car! anche se gli abbiamo dato il valore ElectricCar non ha i suoi metodi e attributi
		
		c2.turnOn();
		
		Car cars[] = new Car[10];
		cars[0]=c1;
		cars[1]=c2;
		
		for(int i = 0; i<10; i++) {
			if(cars[i]!=null) {
				cars[i].turnOn(); //posso chiamare il metodo turnOn su tutte le celle perche sono tutte car
			}					  //java chiama la versione del metodo più appropriata
		}
		
		System.out.println(c1.describeYourself());
		System.out.println(c2.describeYourself());
		
		for(int i = 0; i<10; i++) {
			if(cars[i]!=null) {
				System.out.println(cars[i].describeYourself()); //posso chiamare il metodo turnOn su tutte le celle perche sono tutte car
			}					  //java chiama la versione del metodo più appropriata		
								  //DYNAMIC BINDING
		}
		
		
		
		
		
	}

}
