package Inheritance;//tutte le classi di java derivano da object (è la più generica di tutte)

public class ElectricCar extends Car {
	//eredita senza che io espliciti attributi e metodi di Car
	//aggiunge le specificità
	
	boolean cellsCharged = false;
	
	public ElectricCar(String licensePlate, String brand, String color, boolean cellsCharged) {
		super(licensePlate, brand, color); //super() chiama il costruttore del padre!!
		this.cellsCharged = cellsCharged;  //abbiamo costruito e inizializzato la parte relativa alla car
	}//super va inserita come prima istruzione (costruzione top down)
	
	public void recharge() {
		System.out.println("Batteries recharged");
		cellsCharged=true;
	}
						  //OVERRIDE
	public void turnOn() {//l'ho ereditato ma posso cambiare come si comporta mantenendo la firma e modificando il corpo
		if(cellsCharged==true) {
			System.out.println("Car has been turned on");
			turnedOn = true;
		}
		else {
			System.out.println("Car has not been turned on");
		}
	}
	
	@Override //questo messaggio dice a eclipse che il metodo sotto è in override
	//non serve solo al programmatore ma anche a java.
	public String describeYourself() {
		//return licensePlate+";"+brand+";;"+color+";"+turnedOn+";"+cellsCharged;
		return super.describeYourself() + ";" + cellsCharged;
	}//this. si riferisce a qualcosa in questa classe, super. si riferisce alla superclasse!!
	 //Delega, fattorizzazioe del codice, riuso del codice...
}

//essendo che tutte le classi derivano da object tu puoi creare un array object in cui
//puoi buttare dentro tutti i tipi di oggetti e addirittura stamparli con il metodo toString 
//è una struttura dati ideale cazzo
//