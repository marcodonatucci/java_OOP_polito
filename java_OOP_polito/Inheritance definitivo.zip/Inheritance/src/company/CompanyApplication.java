package company;

public class CompanyApplication {

	public static void main(String[] args) {
		
		Employee e = new Employee("Mario Rossi", 25000);
		System.out.println(e);
		e.incrementWage();
		System.out.println(e);//anche senza toStrig

		Manager m = new Manager("B. Boss", 100000, "HR");
		System.out.println(m);
		m.incrementWage();
		System.out.println(m);
		
		Employee ee = m;//UP-CASTING, porto l'oggetto "verso l'alto" cioè verso una classe più generale
		Manager mm = (Manager)e; //DOWN-CASTING, java si fida del programmatore ma poi potrebbero generarsi delle eccezioni!!
		
		if(e instanceof Employee) {//instanceof va a vedere che tipo di oggetto è e lo confronta con la classe
			System.out.println("Reference e is an Employee");
		}
		else if (e instanceof Manager){
			System.out.println("Reference e is a Manager");
		}
		
		Employee eee = new Employee("Mario Rossi", 26000);
		if(e.equals(eee))
			System.out.println("Uguali");
		else
			System.out.println("Diversi");
		
		
		
		
	}

}
