package company;

public class Employee {
	
	protected String name;
	protected double wage;
	
	public Employee(String name, double wage) {
		this.name = name;
		this.wage = wage;
	}
	
	public void incrementWage( ) {
		this.wage += 1000;
	}

	@Override
	public String toString() {
		return "Employee [" + (name != null ? "name=" + name + ", " : "") + "wage=" + wage + "]";
	}

	@Override             //non cambiare tipo di parametro senno stai cambiando la firma del metodo
	public boolean equals(Object obj) {
		Employee otherEmployee = (Employee)obj;
		if(this.name.compareTo(otherEmployee.name)==0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	

}
