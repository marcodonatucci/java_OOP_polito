package company;

public class Manager extends Employee {
	
	
	protected String managedUnit;
	
	public Manager(String name, double wage, String managedUnit) {
		super(name, wage);
		this.managedUnit=managedUnit;
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		//Delego alla superclasse la parte del metodo relativa a lei
		return super.toString()+managedUnit;
	}

	@Override
	public void incrementWage() {
		// TODO Auto-generated method stub
		super.incrementWage();
	}

	
	

	
	
	
}
