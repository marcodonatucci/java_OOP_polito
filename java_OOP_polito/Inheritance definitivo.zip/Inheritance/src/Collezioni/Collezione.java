package Collezioni;//AbstractDataType ADT, la lista è un adt

//public abstract class Collezione {//è una classe astratta, non serve a niente
public interface Collezione {//posso chiamarla interfaccia
	
	public abstract void aggiungi(Object daAggiungere);
	
	public abstract int dimensione();//anche i metodi possono essere astratti
	
	public abstract boolean contiene(Object daCercare);
	
	public abstract String descriviti();//le sottoclassi definiranno i corpi dei metodi!
	
	//sono superclassi talmente astratte che servono a dare una linea guida alle classi figlie
	//i metodi astratti della classe astratta rappresentano la sua interfaccia cioè il modo in cui posso interagire
	//le classi che estendono possono aggiungere o cambiare i metodi della superclasse (ovverride)
	//le classi che implementano un interfaccia DEVONO fornire un implementazione per tutti i metodi 
	//una classe può estendere solo un'altra classe, ma può implementare tutte le interfacce che ti pare (e fare contemporaneamente tutti e due)
	//un framework è un insieme di interfacce e implementazioni
}