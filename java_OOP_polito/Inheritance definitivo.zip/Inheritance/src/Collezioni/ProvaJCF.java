package Collezioni;

import java.util.*;//stanno qua tutte le classi lista

public class ProvaJCF {
//ci sono due classi principali: ArrayList e LinkedList
//tutte e due senza dimensione prestabilita
	public static void main(String[] args) {
		
		LinkedList l = new LinkedList();
		
		Medico m = new Medico(12345, "Alberto", "Gialli");
		
		l.add(m);
		
		System.out.println(l.size());
		
		l.add(new Medico(77777, "Adalberto", "Azzurri"));
		
		System.out.println(l.size());
		
		System.out.println(l.toString());
		
		l.get(0);
		
		l.contains(m); //boolean
		
		Collections.sort(l);//ordina la lista passata come parametro
		
		Iterator iter = l.iterator();//l'iteratore è un oggetto con cui puoi muoverti in una collezione
		
		do {
			Object o = iter.next();//lui restituisce il prossimo oggetto
			System.out.println(o);
		}while(iter.hasNext());//lui verifica che ci sia il prossimo oggetto
		
		
	}

}
