package Collezioni;

public class ElementoLista {
	
	Object dato;
	ElementoLista prossimo;

}
