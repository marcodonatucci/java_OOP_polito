package Collezioni;

public class Medico {
	
	int matricola;
	String nome;
	String cognome;
	
	public Medico(int matricola, String nome, String cognome) {
		this.matricola = matricola;
		this.nome = nome;
		this.cognome = cognome;
	}

	@Override
	public String toString() {
		return "Medico [matricola=" + matricola + ", nome=" + nome + ", cognome=" + cognome + "]";
	}
	
	
	

}
