package Collezioni;

public class CollezioniApplicazione {

	public static void main(String[] args) {
		
		//Collezione c = new Collezione();//non puoi instanziare una classe astratta
		
		CollezioneArray cs = new CollezioneArray();
		
		cs.aggiungi("La mia prima stringa");
		
		System.out.println("Dimensione: " +cs.dimensione());
		
		cs.aggiungi("Seconda stringa");
		
		System.out.println("Dimensione: " +cs.dimensione());
		
		System.out.println("Contenuto: " +cs.descriviti());
		
		if(cs.contiene("La mia bella stringa"))
			System.out.println("trovata");
		else
			System.out.println("non trovata");
		
		Medico m0 = new Medico(12345, "Michela", "Neri");
		
		CollezioneArray cm = new CollezioneArray();
		cm.aggiungi(m0);
		cm.aggiungi(new Medico(67890, "Alberto", "Verdi"));
		
		System.out.println("Dimensione: "+cm.dimensione());
		
		System.out.println("Contenuto: " +cs.descriviti());
		
		
		
		
	}

}
