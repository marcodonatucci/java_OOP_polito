package Collezioni;

//public class CollezioneArray extends Collezione{//quando la classe è un interfaccia non si scrive extends perchè non è una classe
public class CollezioneArray implements Collezione{//si scrive implements!!
	Object array[] = new Object[100];
	
	int num = 0;

	@Override
	public void aggiungi(Object daAggiungere) {
		array[num] = daAggiungere;
		num++;
	}

	@Override
	public int dimensione() {
		return num;
	}

	@Override
	public boolean contiene(Object daCercare) {
		for(Object o: array) {
			if(o!=null && o.equals(daCercare))
				return true;
		}
		return false;
	}
		

	@Override
	public String descriviti() {
		String risultato = "";
		for(int i = 0; i<num; i++)
			risultato+=array[i].toString()+"\n";
		return risultato;
	}
	 
	
	
	
	
	
}
