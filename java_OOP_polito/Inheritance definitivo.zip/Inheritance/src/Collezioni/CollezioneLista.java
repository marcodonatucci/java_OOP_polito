package Collezioni;

public class CollezioneLista implements Collezione {
	
	ElementoLista testa = null;
	int num = 0;

	@Override
	public void aggiungi(Object daAggiungere) {
		ElementoLista nuovo = new ElementoLista();
		nuovo.dato = daAggiungere;
		nuovo.prossimo = testa;
		testa = nuovo;
		num++;
	}

	@Override
	public int dimensione() {
		return num;
	}

	@Override
	public boolean contiene(Object daCercare) {
		ElementoLista elementoCorrente = testa;
		while(elementoCorrente != null) {
			if(elementoCorrente.dato.equals(daCercare)) {
				return true;
			}
			elementoCorrente = elementoCorrente.prossimo;
		}
		return false;
	}

	@Override
	public String descriviti() {
		String risultato = "";
		ElementoLista elementoCorrente = testa;
		while(elementoCorrente != null) {
			risultato += elementoCorrente.dato.toString()+"\n";
			elementoCorrente = elementoCorrente.prossimo;
		}
		return risultato;
	}

	
	
}
