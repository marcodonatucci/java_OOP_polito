package alimentazione;

@SuppressWarnings("serial")
public class RicettaNonTrovataException extends Exception {

}
