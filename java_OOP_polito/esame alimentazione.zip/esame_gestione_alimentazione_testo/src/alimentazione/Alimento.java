package alimentazione;

public class Alimento {
	
	String nome;
	double calorie;
	double proteine;
	double carboidrati;
	double grassi;
	
	
	
	public Alimento(String nome, double calorie, double proteine, double carboidrati, double grassi) {
		this.nome = nome;
		this.calorie = calorie;
		this.proteine = proteine;
		this.carboidrati = carboidrati;
		this.grassi = grassi;
	}

	public String getNome() { 
		return nome; 
	}
	
	public double getCalorie() { 
		return calorie; 
	}
	
	public double getProteine() { 
		return proteine; 
	}
	
	public double getCarboidrati() { 
		return carboidrati; 
	}
	
	public double getGrassi() { 
		return grassi; 
	}
}
