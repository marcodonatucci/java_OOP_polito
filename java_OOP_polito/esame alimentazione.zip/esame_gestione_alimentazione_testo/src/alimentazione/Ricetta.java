package alimentazione;

import java.util.*;

public class Ricetta implements Comparator<Ricetta>{
	
	String nome;
	String descrizione;
	int numeroPorzioni;
	TreeMap<String, Double> ingredienti = new TreeMap<String, Double>();
	
	public Ricetta(String nome, String descrizione, int numeroPorzioni) {
		this.nome = nome;
		this.descrizione = descrizione;
		this.numeroPorzioni = numeroPorzioni;
	}

	public String getNome() { 
		return this.nome; 
	}
	
	public String getDescrizione() { 
		return this.descrizione; 
	}
	
	public int getNumeroPorzioni() { 
		return this.numeroPorzioni; 
	}
	
	public double calcolaCaloriePorzione() {
		double i = 0.0;
		for(String s: ingredienti.keySet()) {
			i += ((Sistema.alimentiMap.get(s).calorie/100)*ingredienti.get(s));
		}
		return i/this.numeroPorzioni;
	}

	public double calcolaCarboidratiPorzione() {
		double i = 0.0;
		for(String s: ingredienti.keySet()) {
			i += ((Sistema.alimentiMap.get(s).carboidrati/100)*ingredienti.get(s));
		}
		return i/this.numeroPorzioni;
	}

	public double calcolaProteinePorzione() {
		double i = 0.0;
		for(String s: ingredienti.keySet()) {
			i += ((Sistema.alimentiMap.get(s).proteine/100)*ingredienti.get(s));
		}
		return i/this.numeroPorzioni;
	}

	public double calcolaGrassiPorzione() {
		double i = 0.0;
		for(String s: ingredienti.keySet()) {
			i += ((Sistema.alimentiMap.get(s).grassi/100)*ingredienti.get(s));
		}
		return i/this.numeroPorzioni;
	}

	@Override
	public int compare(Ricetta o1, Ricetta o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
