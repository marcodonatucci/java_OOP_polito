package alimentazione;

import java.util.Comparator;

public class ComparatoreIngredienti implements Comparator<Ricetta>{

	@Override
	public int compare(Ricetta r1, Ricetta r2) {
		return r1.ingredienti.size()-r2.ingredienti.size();
	}

	
}
