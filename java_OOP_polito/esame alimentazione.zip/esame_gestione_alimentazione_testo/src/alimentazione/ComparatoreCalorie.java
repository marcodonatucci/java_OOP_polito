package alimentazione;

import java.util.Comparator;

public class ComparatoreCalorie implements Comparator<Ricetta>{

	@Override
	public int compare(Ricetta r1, Ricetta r2) {
		int i = (int) r1.calcolaCaloriePorzione();
		int j = (int) r2.calcolaCaloriePorzione();
		return i-j;
	}

}
