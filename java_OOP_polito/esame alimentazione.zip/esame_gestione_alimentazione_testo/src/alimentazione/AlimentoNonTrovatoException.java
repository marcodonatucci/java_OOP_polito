package alimentazione;

@SuppressWarnings("serial")
public class AlimentoNonTrovatoException extends Exception {

}
