package alimentazione;

import java.util.*;

public class Sistema {
	
	LinkedList<Alimento> alimenti = new LinkedList<Alimento>();
	static TreeMap<String, Alimento> alimentiMap = new TreeMap<String, Alimento>();
	LinkedList<Ricetta> ricette = new LinkedList<Ricetta>();
	TreeMap<String, Ricetta> ricetteMap = new TreeMap<String, Ricetta>();
	
	public Alimento aggiungiAlimento(String nome, double calorie, double proteine, double carboidrati, double grassi) {
		if(alimentiMap.containsKey(nome))
			return null;
		else {
			Alimento aTemp = new Alimento(nome, calorie, proteine, carboidrati, grassi);
			alimenti.add(aTemp);
			alimentiMap.put(nome, aTemp);
			return aTemp;
		}
	}

	public Alimento aggiungiAlimentoConfezionato(String nome, double calorie, double proteine, double carboidrati, double grassi, double grammi) {
		if(alimentiMap.containsKey(nome))
			return null;
		else {
			Alimento aTemp = new AlimentoConfezionato(nome, calorie, proteine, carboidrati, grassi, grammi);
			alimenti.add(aTemp);
			alimentiMap.put(nome, aTemp);
			return aTemp;
		}
	}
	
	public Alimento cercaAlimento(String nome) throws AlimentoNonTrovatoException{
		for(Alimento a: alimenti) {
			if(a.nome.toUpperCase().equals(nome.toUpperCase())) 
				return a;
		}
		throw new AlimentoNonTrovatoException();
	}

	public Collection<Alimento> elencoAlimentiInOrdineDiInserimento() {
		return alimenti;
	}
	
	public Ricetta aggiungiRicetta(String nome, String descrizione, int numeroPorzioni) {
		Ricetta rTemp = new Ricetta(nome, descrizione, numeroPorzioni);
		ricette.add(rTemp);
		ricetteMap.put(nome, rTemp);
		return rTemp;
	}

	public void aggiungiIngrediente(String nomeRicetta, String nomeIngrediente, double quantita){
		if(alimentiMap.containsKey(nomeIngrediente)) {
			if(ricetteMap.get(nomeRicetta).ingredienti.containsKey(nomeIngrediente)) {
				ricetteMap.get(nomeRicetta).ingredienti.replace(nomeIngrediente,quantita);
			}else {
				ricetteMap.get(nomeRicetta).ingredienti.put(nomeIngrediente, quantita);
			}
		}
	}
	
	public Ricetta cercaRicetta(String nome) throws RicettaNonTrovataException{
		for(Ricetta r: ricette) {
			if(r.nome.toUpperCase().equals(nome.toUpperCase())) 
				return r;
		}
		throw new RicettaNonTrovataException();
	}

	public Collection<Ricetta> elencoRicetteInOrdineAlfabetico() {
		return ricetteMap.values();
	}

	public Collection<Ricetta> elencoRicetteOrdinatePerCalorieCrescenti() {
		LinkedList<Ricetta> copia = new LinkedList<Ricetta>(ricette);
		Collections.sort(copia, new ComparatoreCalorie());
		return copia;
	}

	public Collection<Ricetta> elencoRicetteOrdinatePerNumeroIngredientiCrescente() {
		LinkedList<Ricetta> copia = new LinkedList<Ricetta>(ricette);
		Collections.sort(copia, new ComparatoreIngredienti());
		return copia;
	}

	public void aggiungiRicettaInData(String nomeRicetta, String giorno){
		
	}
	
	public double calcolaCalorieAssunteInData(String data){
		return -1.0;
	}

	public void setLimiteCalorieGiornaliere(double limiteCalorieGiornaliere){
		
	}
	
	public String elencoDateOltreLimiteCalorie(){
		return null;
	}
	
	public void leggiFile(String file)  {
				
	}
}
