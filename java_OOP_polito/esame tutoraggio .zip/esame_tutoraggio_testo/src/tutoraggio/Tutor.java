package tutoraggio;

public class Tutor extends Utente implements Comparable<Tutor>{
	
	double costoOrario;

	public Tutor(String username, String nome, String cognome, double costoOrario) {
		super(username, nome, cognome);
		this.costoOrario = costoOrario;
	}

	public double getCostoOrario(){
		return this.costoOrario;
	}

	@Override
	public int compareTo(Tutor o) {
		double guadagno1 = 0.0;
		double guadagno2 = 0.0;
		for(Lezione l: this.lezioni) {
			guadagno1 += (this.costoOrario*l.durata);
		}
		for(Lezione l: o.lezioni) {
			guadagno2 += (o.costoOrario*l.durata);
		}
		return (int)(guadagno2-guadagno1);
	}

}
