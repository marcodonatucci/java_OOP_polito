package tutoraggio;

@SuppressWarnings("serial")
public class EccezioneArgomentoInesistente extends Exception{

}
