package tutoraggio;

public class Lezione{
	
	String usernameUtente;
	String usernameTutor;
	String data;
	int oraInizio;
	int oraFine;
	int durata;
	double costo;

	public Lezione(String usernameUtente, String usernameTutor, String data, int oraInizio, int oraFine, double costo) {
		this.usernameUtente = usernameUtente;
		this.usernameTutor = usernameTutor;
		this.data = data;
		this.oraInizio = oraInizio;
		this.oraFine = oraFine;
		this.durata = oraFine-oraInizio;
		this.costo = costo;
	}

	public String getUsernameUtente() {
		return this.usernameUtente;
	}

	public String getUsernameTutor() {
		return this.usernameTutor;
	}

	public String getData() {
		return this.data;
	}

	public int getOraInizio() {
		return this.oraInizio;
	}

	public int getOraFine() {
		return this.oraFine;
	}

	public double getCosto() {
		return this.costo;
	}
}
