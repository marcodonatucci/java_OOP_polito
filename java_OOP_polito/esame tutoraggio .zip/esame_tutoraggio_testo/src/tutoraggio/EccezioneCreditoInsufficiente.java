package tutoraggio;

@SuppressWarnings("serial")
public class EccezioneCreditoInsufficiente extends Exception{

}
