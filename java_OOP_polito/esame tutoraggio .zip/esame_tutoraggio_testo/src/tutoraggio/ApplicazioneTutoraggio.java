package tutoraggio;

import java.util.*;

public class ApplicazioneTutoraggio {
	
	TreeMap<String, Utente> utentiMap;
	LinkedList<Utente> utenti;
	LinkedList<Tutor> tutor;
	LinkedList<Lezione> lezioni;
	
	public ApplicazioneTutoraggio() {
		this.utentiMap = new TreeMap<String, Utente>();
		this.utenti = new LinkedList<Utente>();
		this.tutor = new LinkedList<Tutor>();
		this.lezioni = new LinkedList<Lezione>();
	}

	public Utente aggiungiUtente(String nome, String cognome){
		String username = "";
		if(nome.length()>=4 && cognome.length()>=4) {
			username = nome.substring(0, 4) + "-" + cognome.substring(0,4) + "-";
		}else if(nome.length()>=4 && cognome.length()<4){
			username = nome.substring(0, 4) + "-" + cognome + "-";
		}else if(nome.length()<4 && cognome.length()>=4) {
			username = nome + "-" + cognome.substring(0,4) + "-";
		}else {
			username = nome + "-" + cognome + "-";
		}
		int i = 1;
		for(Utente u: utenti) {
			if(u.nome.equals(nome) && u.cognome.equals(cognome))
				i++;
		}
		username += i;
		Utente u = new Utente(username.toLowerCase(), nome, cognome);
		utenti.add(u);
		utentiMap.put(username.toLowerCase(), u);
		return u;
	}

	public Utente cercaUtente(String username) {
		if(utentiMap.containsKey(username))
			return utentiMap.get(username);
		return null;
	}
	
	public Collection<Utente> elencoUtenti(){
		return utenti;
	}
	
	public void incrementaCredito(String usernameUtente, double credito) {
		if(cercaUtente(usernameUtente)!=null)
			cercaUtente(usernameUtente).credito += credito;
	}
	
	public Tutor aggiungiTutor(String nome, String cognome, double costoOrario) {
		String username = "";
		if(nome.length()>=4 && cognome.length()>=4) {
			username = nome.substring(0, 4) + "-" + cognome.substring(0,4) + "-";
		}else if(nome.length()>=4 && cognome.length()<4){
			username = nome.substring(0, 4) + "-" + cognome + "-";
		}else if(nome.length()<4 && cognome.length()>=4) {
			username = nome + "-" + cognome.substring(0,4) + "-";
		}else {
			username = nome + "-" + cognome + "-";
		}
		int i = 1;
		for(Tutor t: tutor) {
			if(t.nome.equals(nome) && t.cognome.equals(cognome))
				i++;
		}
		username += i;
		Tutor t = new Tutor(username.toLowerCase(), nome, cognome,costoOrario);
		tutor.add(t);
		utentiMap.put(username.toLowerCase(), t);
		return t;
	}
	
	public Collection<Tutor> elencoTutor(){
		return tutor;
	}

	public Collection<String> specificaArgomento(String username, String argomento){
		if(cercaUtente(username)!=null) {
			cercaUtente(username).argomenti.put(argomento, argomento);
			return cercaUtente(username).argomenti.values();
		}
		return null;
	}
	
	public Lezione creaLezione(String usernameUtente, String usernameTutor, String data, int oraInizio, int oraFine) 
			throws EccezioneOrarioNonDisponibile, EccezioneCreditoInsufficiente{
		Utente utente = cercaUtente(usernameUtente);
		Tutor tutor = (Tutor) cercaUtente(usernameTutor);
		if(utente!=null && tutor!=null) {
			for(Lezione l: tutor.lezioni) {
				if(l.data.equals(data) && ((oraInizio>=l.oraInizio && oraInizio<l.oraFine)|| (oraFine>l.oraInizio && oraFine<=l.oraFine))){
					throw new EccezioneOrarioNonDisponibile();
				}
			}
			double costoLezione = tutor.costoOrario*(oraFine-oraInizio);
			if(utente.credito<costoLezione)
				throw new EccezioneCreditoInsufficiente();
			Lezione lezione = new Lezione(usernameUtente, usernameTutor, data, oraInizio, oraFine, costoLezione);
			tutor.lezioni.add(lezione);
			utente.lezioni.add(lezione);
			lezioni.add(lezione);
			utente.credito -= costoLezione;
			return lezione;
		}
		return null;
	}
	
	public Collection<Lezione> elencoLezioniPerDurata(){
		LinkedList<Lezione> copia = new LinkedList<Lezione>(lezioni);
		Collections.sort(copia, new ComparatoreDurata());
		return copia;
	}

	public Collection<Lezione> elencoLezioniPerDataOraInizioFine(){
		LinkedList<Lezione> copia = new LinkedList<Lezione>(lezioni);
		Collections.sort(copia, new ComparatoreData());
		return copia;
	}

	public double calcolaGuadagnoTutor(String usernameTutor) {
		Tutor tutor = (Tutor) cercaUtente(usernameTutor);
		double guadagno = 0.0;
		for(Lezione l: tutor.lezioni) {
			guadagno += (tutor.costoOrario*l.durata);
		}
		return guadagno;
	}

	public double calcolaGuadagnoTutor(String usernameTutor, String dataInizio, String dataFine) {
		Tutor tutor = (Tutor) cercaUtente(usernameTutor);
		double guadagno = 0.0;
		for(Lezione l: tutor.lezioni) {
			if(l.data.compareTo(dataInizio)>=0 && l.data.compareTo(dataFine)<=0)
				guadagno += (tutor.costoOrario*l.durata);
		}
		return guadagno;
	}

	public double calcolaGuadagnoMedio(){
		double guadagnoTot = 0.0;
		int oreTot = 0;
		for(Tutor t: tutor) {
			guadagnoTot += calcolaGuadagnoTutor(t.username);
			for(Lezione l: t.lezioni) {
				oreTot += l.durata;
			}
		}
		Double d = (guadagnoTot/oreTot);
		return d;
	}

	public String stampaGuadagniTutor(){
		LinkedList<Tutor> copia = new LinkedList<Tutor>(tutor);
		Collections.sort(copia);
		String s = "";
		for(Tutor t: copia) {
			s += t.username +" "+ t.nome+" " + t.cognome+" " + calcolaGuadagnoTutor(t.username)+"\n";
		}
		if(s.length()>0)
			return s.substring(0, s.length()-1);
		return s;
	}

	public Tutor suggerisciTutor(String usernameUtente) {
		if(cercaUtente(usernameUtente) instanceof Tutor)
			return null;
		LinkedList<String> argomenti = new LinkedList<String>(cercaUtente(usernameUtente).argomenti.values());
		int i = 0;
		for(Tutor t: tutor) {
			if(t.argomenti.values().containsAll(argomenti))
				return t;
			int j = 0;
			for(String a: argomenti) {
				if(t.argomenti.values().contains(a))
					j++;
			}
			if(j>i)
				i = j;
		}
		for(Tutor t: tutor) {
			int k = 0;
			for(String a: argomenti) {
				if(t.argomenti.values().contains(a))
					k++;
				if(i==k)
					return t;
			}
		}
		return null;
	}
	
}
