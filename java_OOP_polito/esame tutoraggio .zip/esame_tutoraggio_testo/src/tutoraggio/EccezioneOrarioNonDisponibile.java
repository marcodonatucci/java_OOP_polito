package tutoraggio;

@SuppressWarnings("serial")
public class EccezioneOrarioNonDisponibile extends Exception{

}
