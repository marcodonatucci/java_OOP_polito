package tutoraggio;

import java.util.*;

public class Utente {
	
	String username;
	String nome;
	String cognome;
	double credito = 0.0;
	TreeMap<String, String> argomenti;
	LinkedList<Lezione> lezioni;
	
	public Utente(String username, String nome, String cognome) {
		this.username = username;
		this.nome = nome;
		this.cognome = cognome;
		this.argomenti = new TreeMap<String, String>();
		this.lezioni = new LinkedList<Lezione>();
		
	}

	public String getUsername() {
		return this.username;
	}

	public String getNome() {
		return this.nome;
	}

	public String getCognome() {
		return this.cognome;
	}

	public double getCredito() {
		return this.credito;
	}

	
}
