package tutoraggio;

import java.util.Comparator;

public class ComparatoreData implements Comparator<Lezione>{

	@Override
	public int compare(Lezione o1, Lezione o2) {
		if(o1.data.equals(o2.data)){
			return o1.oraInizio-o2.oraInizio;
		}else if(o1.data.equals(o2.data) && o1.oraInizio==o2.oraInizio) {
			return o1.oraFine-o2.oraFine;
		}else{
			return o1.data.compareTo(o2.data);
		}
	}

}
