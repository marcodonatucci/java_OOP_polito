package tutoraggio;

import java.util.Comparator;

public class ComparatoreDurata implements Comparator<Lezione>{

	@Override
	public int compare(Lezione o1, Lezione o2) {
		return o1.durata-o2.durata;
	}

}
