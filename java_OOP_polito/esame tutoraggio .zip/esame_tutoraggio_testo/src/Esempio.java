import tutoraggio.*;

import java.util.*;

public class Esempio {

	public static void main(String[] args) throws EccezioneArgomentoInesistente, 
	EccezioneOrarioNonDisponibile, EccezioneCreditoInsufficiente{
		
		ApplicazioneTutoraggio at = new ApplicazioneTutoraggio();

		System.out.println("/****** R1. UTENTI E TUTOR ******/");

		System.out.println("\nAggiunto utente\n");
		Utente u1 = at.aggiungiUtente("Giovanni", "Neri");

		System.out.println("Informazioni utente:\n");

		System.out.println("Username (assegnato): "+u1.getUsername());
		System.out.println("Nome: "+u1.getNome());
		System.out.println("Cognome: "+u1.getCognome());
		
		System.out.println("\nAggiunti altri utenti");
		Utente u2 = at.aggiungiUtente("Marco", "Gialli");
		Utente u3 = at.aggiungiUtente("Luisa", "Blu");
		Utente u4 = at.aggiungiUtente("Giovanni", "Neri");

		System.out.println("\nElenco utenti (ordine di aggiunta):\n");
		for(Utente u : at.elencoUtenti())
			System.out.println(""+u.getUsername()+" "+u.getNome()+" "+u.getCognome());
		
		System.out.println("\nIncrementato credito utenti\n");

		at.incrementaCredito("giov-neri-1", 60.0);
		at.incrementaCredito("marc-gial-1", 10.0);
		at.incrementaCredito("giov-neri-1", 10.0);
		at.incrementaCredito("luis-blu-1", 20.0); // Utente inesistente
		
		System.out.println("Nuovo credito 'giov-neri-1':");
		double cu1 = u1.getCredito();
		System.out.println(cu1);

		System.out.println("\nAggiunti tutor");

		Tutor t1 = at.aggiungiTutor("Mario", "Rossi", 15.0);
		Tutor t2 = at.aggiungiTutor("Franco", "Bianchi", 10.0);
		Tutor t3 = at.aggiungiTutor("Giorgio", "Verdi", 5.0);

		System.out.println("\nElenco tutor (ordine di aggiunta):\n");
		for(Tutor t : at.elencoTutor())
			System.out.println(""+t.getUsername()+" "+t.getNome()+" "+t.getCognome()+" "+t.getCostoOrario());
		
		System.out.println("\nSpecificati argomenti per i quali l'utente 'giov-neri-1' richiede tutoraggi");
		
		                                            at.specificaArgomento("giov-neri-1", "Fisica");
		Collection<String> elencoArgomentiUtente1 = at.specificaArgomento("giov-neri-1", "Chimica");
		
		System.out.println("\nElenco argomenti specificati da 'giov-neri-1' (ordine alfabetico):");
		for(String a : elencoArgomentiUtente1)
			System.out.println(""+a);
		
		System.out.println("\nSpecificati altri argomenti per i quali sono richiesti ulteriori tutoraggi");
		at.specificaArgomento("marc-gial-1", "Matematica");
		at.specificaArgomento("marc-gial-1", "Programmazione a oggetti");
		at.specificaArgomento("marc-gial-1", "Chimica");
		at.specificaArgomento("marc-gial-1", "Fisica");

		System.out.println("\nSpecificati argomenti per i quali il tutor 'mari-ross-1' offre tutoraggi");
		
		                              at.specificaArgomento("mari-ross-1", "Matematica");
		                              at.specificaArgomento("mari-ross-1", "Fisica");
		Collection<String> elencoArgomentiTutor1 = at.specificaArgomento(t1.getUsername(), "Analisi");

		System.out.println("\nElenco argomenti specificati da 'mari-ross-1' (ordine alfabetico):");
		for(String a : elencoArgomentiTutor1)
			System.out.println(""+a);

		System.out.println("\nSpecificati altri argomenti per i quali sono offerti ulteriori tutoraggi");
		
		at.specificaArgomento("fran-bian-1", "Fisica");
		at.specificaArgomento("gior-verd-1", "Matematica");
		

		System.out.println("\n\n/****** R2. LEZIONI ******/\n");

		
		System.out.println("Creata lezione per 'giov-neri-1' con 'mari-ross-1' il 20230920 ore 11-14");
		Lezione l1 = at.creaLezione("giov-neri-1", "mari-ross-1", "20230920", 11, 14);

		System.out.println("\nInformazioni lezione:\n");
		
		System.out.println("Utente: "+l1.getUsernameUtente());
		System.out.println("Tutor: "+l1.getUsernameTutor());
		System.out.println("Data: "+l1.getData());
		System.out.println("Ora di inizio: "+l1.getOraInizio());
		System.out.println("Ora di fine: "+l1.getOraFine());
		System.out.println("Costo: "+l1.getCosto());

		System.out.println("\nCreate altre lezioni");

		Lezione l2 = at.creaLezione("marc-gial-1", "fran-bian-1", "20230919", 9, 10);
		Lezione l3 = at.creaLezione("giov-neri-1", "fran-bian-1", "20230918", 16, 18);
		Lezione l4 = at.creaLezione("giov-neri-1", "gior-verd-1", "20230921", 18, 19);

		System.out.println("\nElenco lezioni (ordine di durata crescente):");
		Collection<Lezione> ltemp = at.elencoLezioniPerDurata();
		for (Lezione l : ltemp)
			System.out.println(""+l.getData()+ " "+l.getOraInizio()+ " "+l.getOraFine()+" "+l.getUsernameUtente()+" "+l.getUsernameTutor()+" "+l.getCosto());

		System.out.println("\nElenco lezioni (ordine di data, ora inizio e ora fine crescenti):");
		                    ltemp = at.elencoLezioniPerDataOraInizioFine();
		for (Lezione l : ltemp)
			System.out.println(""+l.getData()+ " "+l.getOraInizio()+ " "+l.getOraFine()+" "+l.getUsernameUtente()+" "+l.getUsernameTutor()+" "+l.getCosto());
		
		
		System.out.println("\n\n/****** R3. GUADAGNI ******/");

		System.out.println("\nGuadagno tutor 'mari-ross-1':"); 
		double guadagno = at.calcolaGuadagnoTutor("mari-ross-1");
		System.out.println(guadagno);

		System.out.println("\nGuadagno tutor 'fran-bian-1' nel periodo 20230919 - 20230919:"); 
		       guadagno = at.calcolaGuadagnoTutor("fran-bian-1", "20230919", "20230919");
		System.out.println(guadagno);

		System.out.println("\nGuadagno medio dei tutor:");
		       guadagno = at.calcolaGuadagnoMedio();
		    			System.out.println(guadagno);

		       
		System.out.println("\nInformazioni relative ai guadagni dei tutor (per guadagni decrescente):");
		String stringaGuadagniTutor = at.stampaGuadagniTutor();
		System.out.println(stringaGuadagniTutor);

		System.out.println("\n\n/****** R4. TUTOR SUGGERITI ******/");
		
		System.out.println("\nRicerca tutor per gli argomenti richiesti dall'utente 'giov-neri-1'");
		
		Tutor ts1 = at.suggerisciTutor("giov-neri-1");
		
		System.out.println("\nTutor suggerito:\n");
		System.out.println("Username: "+ts1.getUsername());
		System.out.println("Nome: "+ts1.getNome());
		System.out.println("Cognome: "+ts1.getCognome());
		System.out.println("Costo orario: "+ts1.getCostoOrario());
		
		
		
		
	}

}
